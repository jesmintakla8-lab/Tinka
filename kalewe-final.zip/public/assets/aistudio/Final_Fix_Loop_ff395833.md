# Final Fix Loop (Fix Pack V2)

Version 1.0 · Audience: AI builder · Owner: shop owner · Applies to: the app as it is now (the PRD, Loops 1–8 and Fix Pack V1, "Raymond Loop Fixing") · Build only this loop

## 0. Continue from what exists (read first)

This loop continues one app. Most of the current app is fine. Only the six fixes below are wanted.

- Never create a second copy of a screen or component that already exists. Open the existing one and change it **in place**.
- Keep the existing navigation, layout, colours and wording. Do not restyle, rename or regenerate earlier work.
- Anything new must look like it was always part of the app. Reuse the existing cards, badges, buttons, forms, dialogs, tabs, and empty and loading states.
- The owner recorded a **reference app** (tailorpro) to show how some fixes should **behave**. Copy the behaviour only. Keep the app's own design language, name and menu. Do not copy the reference app's theme, typography or layout.
- If you cannot find an existing screen or component, stop and ask the owner. Do not recreate it.
- Where this document and an earlier document disagree, **this document wins** (section 1).
- If something is not in this document, leave it out and tell the owner what you left out. If something is unclear, ask. Items still waiting for an owner answer are in section 5, each with the default to use until the owner answers.
- Never write the word "optional" anywhere in the screen text. Use blank-friendly fields with no label.

**EXISTING (leave alone):** navigation, Customers and Customer History, Drafts list, Settings (except the items named below), Workers list, month folders, Staff pay and history, numeric keypad behaviour, BD number suggestions, Deleted History, Backup and Restore, the invoice paper, Pay on delivered orders, running years.

**EXTEND (change in place, exactly as listed):**
- **New / Edit Order form, Items area** (Officer and Airman): FIX-18.
- **Airman order form, order card, order details, cutting slip, Settings lists:** remove Trade and Office (FIX-19).
- **Cutting slip:** per-item slips and the combined print (FIX-20). Changes the Cutting Slip page, the buttons on Order Details, the order card icon and the form button.
- **Delivery screen, Order Details, status dropdown:** the delivery flow (FIX-21).
- **Dashboard, Staff Summary, Staff Management month page:** CSV and print buttons become one PDF download button (FIX-22).
- **Orders screen summary cards:** the Pending Cutting Slip card is replaced (FIX-23).

**NEW:** the **Confirm Delivery** page (FIX-21), the **compact cutting slip** layout and its multi-slip print sheet (FIX-20), the PDF report files (FIX-22).

## 1. These changes override earlier documents

| Topic | Earlier documents said | Now |
|---|---|---|
| Item rows (FIX-03) | Row #1 is already present **and already selected**; Add Item adds another row | Row #1 is present but **still being edited**. Add Item **saves** it, then a new editing row appears (FIX-18) |
| Airman Trade and Office (PRD, Loop 6, FIX-16) | Dropdowns on the Airman form; shown on card, details and slip; lists in Settings | **Removed everywhere** (FIX-19). IV-Number per item stays |
| Cutting slip (Loop 3, Loop 6) | One page with every item together | **One slip per item**, shirt and pant slips separate; compact format; a single print for all (FIX-20) |
| Delivery (Loop 2 section 6, Loop 6) | **Deliver** button marks the order Delivered at once with today's date. The status dropdown also saves Delivered at once | Delivered **only after Confirm Delivery** on its own page (FIX-21) |
| Export (Fix Pack V1 FIX-12, 13, 15; Loop 7, 8) | CSV and PDF / Print buttons on the staff pages and Dashboard | **One PDF download button.** The CSV buttons go (FIX-22) |
| Orders summary cards (Loop 2 section 5.1) | Upcoming to Deliver and Due After Delivery | The owner's current app shows a **Pending Cutting Slip** card instead of Due After Delivery. Restore **Due After Delivery** in its place (FIX-23) |

## 2. Fix index and build order

This continues the numbering of Fix Pack V1, which ended at FIX-17.

| Fix | Title |
|---|---|
| FIX-18 | Item rows: edit first, save on Add Item |
| FIX-19 | Airman orders: remove Trade and Office |
| FIX-20 | Cutting slip per item, and one print for all |
| FIX-21 | Delivery: details page, then Confirm Delivery |
| FIX-22 | Reports download as PDF |
| FIX-23 | Due After Delivery card |

Build in this order. FIX-21 feeds the numbers on FIX-23, so test FIX-23 after FIX-21.

## 3. Fix details

### FIX-18 — Item rows: edit first, save on Add Item

**Now:** When the owner opens New Order, row #1 (Battle Uniform) already appears as a finished, saved item. It cannot be set up the way he wants before it becomes part of the order. Pressing Add Item does not give him a fresh row to edit.

**Required (Officer form):**

1. The Items area opens with **one editing row**. It is pre-filled with the **first item of the item list** (for example Battle Uniform), quantity 1, and its price showing. Every part of it can be changed freely: the searchable item dropdown, the quantity dropdown (1 to 10), and the live row price.
2. The editing row is **not part of the order yet**. It is not counted in the item count, Total Amount or Due.
3. **Add Item** (below the editing row) **saves** the row as an item of the order:
   - the row moves into a **saved items list** above the editing row, as a compact line: item name, quantity, line price (Officer) or IV-Number (Airman), a pencil icon (edit) and a red delete icon;
   - Total Amount, Due and the item count update at once;
   - **a new editing row appears automatically below it**, with the same defaults (first item, quantity 1). Press Add Item again for the third item, and so on. There is no limit.
4. **Pencil on a saved line** turns that line back into an editing row in place, with a button reading **Update Item**. The delete icon removes the item (no confirmation needed for a single line).
5. **Save Order and the editing row** (see section 5, question 8 for the default):
   - A saved item always counts.
   - The open editing row counts only if the owner **changed it** (a different item, quantity, or IV-Number). It is then added automatically, exactly as if he had pressed Add Item.
   - An editing row left at its defaults and untouched is ignored.
   - If there are no saved items and the editing row is untouched, show the existing "add at least one item" message and do not save.
6. Everything else in FIX-03 stays: searchable item dropdown with a **Manage Items** link at the bottom, quantity dropdown 1 to 10, live row price, no keyboard needed for items or quantity.

**Required (Airman form):** the same behaviour, with an **IV-Number** field in the editing row and **no price** anywhere.
- IV-Number is required **before an item can be saved** with Add Item. If it is empty, show a clear message in the row and do not save the row.
- The PRD rules stay: one IV-Number belongs to one person; the same person can repeat it across rows.

**Edit Order and drafts:**
- Opening an existing order or a draft shows all its items as **saved lines** and a fresh editing row below.
- A draft stores the saved items. A touched editing row is also kept in the draft.
- The unsaved-changes warning (FIX-08) treats a touched editing row as a change. An untouched default row is not a change.

**Done when:**
- A new order opens with Battle Uniform in an editing row, not yet in the item list.
- The owner changes it to another item and quantity, presses Add Item, and sees it saved in the list, and a new editing row appears.
- A three-item order is built with taps only.

### FIX-19 — Airman orders: remove Trade and Office

**Now:** Airman orders have Trade and Office dropdowns and show them in several places. The owner does not use them.

**Required:** remove **Trade** and **Office** from the Airman side everywhere:

- Airman New / Edit order form (both dropdowns).
- Airman order card (the Trade text) and the Airman Delivery list if it shows them.
- Airman Order Details: the Trade and Office entries in the information section, and the "Trade / Office" summary card (the top cards become Items and Running Year).
- Airman cutting slip header.
- Settings: the **Trade** and **Office** lists (the Lists section keeps Ribbon, Branch and Running Years).
- Search on the Airman page must not look in Trade or Office.
- Drafts: an old Airman draft with Trade or Office values still opens without any error.

**Stays exactly as it is:** BD Number, Name, Phone, Ribbon, Running Year, order date, and the **IV-Number on every item** (the owner confirmed it works).

**Old data:** existing Airman orders keep any Trade or Office values in storage so nothing is lost, but they are **never shown, printed or searched**. They are left out of new exports (the PDFs in FIX-22 never had them).

**Done when:** a search of the Airman screens, slips and Settings finds no Trade or Office.

### FIX-20 — Cutting slip per item, and one print for all

**Now:** Pressing Cutting Slip creates **every slip together** as one page. The owner wants each item to have its own slip, and shirt and pant slips to be separate.

The format below follows the reference app's slip sheet in the owner's recording. The measurement order was read from a low-resolution recording and is listed so the builder can check it against the app's own measurement fields (section 5, question 4).

**A. Which slips an order makes**

- One slip is one small card.
- An order makes **one slip per item line**. An item that is a Shirt item makes a **Shirt slip**. An item that is a Pant item makes a **Pant slip**. A **set** item (a shirt and a pant together, for example Meskit or Summer Ceremonial) makes **two separate slips**: a Shirt slip and a Pant slip.
- Example: three single-part items make three slips. Two single-part items plus one set item make four slips.
- Which kind each item is comes from a new setting, **Slip type**, on every item in Settings → Items & Prices and Settings → Airman Items. Values: **Shirt**, **Pant**, **Shirt + Pant**. The default for each item is decided by name (section 5, question 1) and the owner can change it.
- Quantity: one slip per item line. When the quantity is above 1, the slip also shows "Qty 2" (section 5, question 2).

**B. What one slip shows** (compact, black on white)

- **Top line, bold:** order number, customer name, BD number, in this form: `#546 ~ S/L ERFAN ~ 10133`.
- **Top right:** `R - 3` (the ribbon). Under it, for **Officer** orders, the **Branch** (for example GDP) when one is chosen. Airman slips show no Branch.
- **Item line:** `Item: Meskit Shirt`. On Airman slips the line also shows the **IV-Number** of that item.
- A thin rule.
- **Measurement line:** only the values that were filled in, in the fixed order below, joined with ` ~ `, with no labels.
  - Shirt order: Length, Chest, Belly, Hip, Shoulder, Sleeve, Collar, **Front shown as `F-` plus the value**, **Back shown as `B-` plus the value**. Example from the recording: `28/28.5 ~ 38.5 ~ 34 ~ 38.5 ~ 18 ~ 24 ~ 15.5 ~ F-16 ~ B-15`.
  - Pant order: Length, Waist, Hip, High, Thai, Leg Open. Example: `40.5 ~ 34 ~ 38.5 ~ 27.5 ~ 26 ~ 14.5`.
  - Empty fields are skipped. If a slip has no measurements at all, the line shows `—`.
- **Notes:** the **Hand Written Notes** and **Extra Notes** that belong to that part (shirt notes on the Shirt slip, pant notes on the Pant slip), in bold, in the words the owner typed.
- **Bottom row:** the part name (**Shirt** or **Pant**) on the left, and the **delivery date** on the right (for example `2026-09-05`). Airman orders have no delivery date, so they show the order date (section 5, question 5).
- **No prices and no money anywhere.**

**C. Where the buttons are**

1. **Order Details → Items section:** every item line gets its own **Cutting Slip** button at the right end of the line (print icon and the words "Cutting Slip"). Tapping it opens the Cutting Slip page for **that item only**. For a set item, the page shows its Shirt slip and its Pant slip as two separate cards (section 5, question 3).
2. **Order Details → bottom button Print Slip:** opens the Cutting Slip page with **every slip of the order together**, ready for **one single print**.
3. **Order card icon (Cutting Slip):** same as the bottom button: all slips of the order, one print.
4. **New / Edit Order form, Cutting Slip button:** saves the order first (all normal saving rules), then opens all slips of the order, as in Loop 3.
5. Airman orders have the same four places.
6. The old one-page combined slip is **removed**. Nothing may still produce it.

**D. The Cutting Slip page and the print sheet**

- The page has **Back** and **Print**. Its preview is exactly what will print. The paper size comes from Settings → Print paper size (A4 default, A5 allowed).
- Slips flow in **two columns**, left to right, then down the page. A slip is **never split** across two pages. As many slips as fit go on a page; the next page starts when the first is full.
- Slip order: the order's items in their order; for a set item, the Shirt slip first, then the Pant slip.
- Pressing **Print** opens the browser print dialog **once** for the whole sheet, whether it holds one slip or twenty. The owner never prints slip by slip.
- The app menu, buttons and navigation never appear in the printout. Black and white only.

**Done when:**
- An order with three single-part items shows three Cutting Slip buttons, one beside each item, and each opens only its own slip.
- A set item shows a Shirt slip and a Pant slip as separate cards.
- The bottom Print Slip prints all slips in one print dialog, two per row, with no slip cut in half.
- Airman orders do the same, with IV-Number and without Trade, Office, or Branch.

### FIX-21 — Delivery: details page, then Confirm Delivery

**Now:** Pressing **Deliver** marks the order Delivered at once. The status dropdown does the same. There is no step to record who received the order.

**Required flow (as in the owner's recording):**

1. **Delivery screen** (unchanged list, Officer and Airman tabs): tapping **Deliver** on a row, or the row itself, opens the **Delivery Details** page for that order. This is the existing Order Details content (customer details, order information, payment, items), reached from the Delivery screen. **Nothing is changed or saved yet.** A back arrow returns to the list.
2. At the **bottom** of that page is a full-width primary button: **Deliver This Order**.
3. **Deliver This Order** opens the **Confirm Delivery** page. It is a **page**, not a popup. It has:
   - a back arrow, the heading **Confirm Delivery**, and the line "Order #N";
   - a green banner: "Marking as Delivered";
   - then these fields, in this order:
     1. **Delivered Date** (date picker, default today)
     2. **Total Amount (৳)** (read only)
     3. **Discount (৳)** (editable; starts with the discount the order already has)
     4. **Advance (৳)** (read only)
     5. **Cash Receive (৳)** (editable, starts at 0): the cash the customer hands over now
     6. **Due (৳)** (calculated, shown in red while above 0)
     7. **Receiver Name** (starts with the customer's name; editable)
     8. **Receiver Phone Number** (starts with the customer's phone when there is one; editable and may stay blank)
   - a small summary box: "Status: ✓ Delivered" and "Due: ৳N";
   - two buttons: **Cancel** and **Confirm Delivery**.
4. **Only Confirm Delivery** completes the delivery. Cancel and the back arrow leave the order exactly as it was.

**Money rules on this page (Officer orders):**

- **Due** = Total Amount − Discount − Advance − any amount already received later − Cash Receive. It updates live as Discount and Cash Receive change.
- If the order already has later payments, show one more read-only line, **Already Received (৳)**, above Cash Receive.
- Discount cannot be negative or above the Total Amount. Cash Receive cannot be negative or above what is still due before the cash. Show the problem in plain words next to the field and do not confirm.
- The page never moves real money. Cash Receive only records cash already handed over.

**When Confirm Delivery is pressed:**

- Status becomes **Delivered**, and the delivered date is the date on the page.
- **Receiver Name** and **Receiver Phone Number** are saved on the order.
- The Discount on the page becomes the order's discount (it shows on Order Details and on the invoice from then on).
- If Cash Receive is above 0, it is saved as a **payment record** dated the delivered date, in the same way as Pay.
- Show "Order #N delivered", go back to the Delivery list, and the row is gone.
- Order Details of a delivered order shows the delivered date and **Received by** with the receiver's name and phone.
- Orders, Delivery, Customers (Orders, Spent, Due), Due After Delivery and the Dashboard all recalculate.

**Airman orders:** the Confirm Delivery page shows only **Delivered Date**, **Receiver Name**, **Receiver Phone Number**, the "Status: ✓ Delivered" box, Cancel and Confirm Delivery. No money fields.

**Other ways to reach Delivered:**
- The **status dropdown** (order card and Order Details): choosing **Delivered** no longer saves at once. It opens the same Confirm Delivery page. Cancel keeps the old status (section 5, question 11).
- Moving a Delivered order back to Pending or Cutting Slip – Done works as before: the delivered date is cleared and the receiver name and phone are cleared. Payment records already saved stay.
- **Order Details** of a not-yet-delivered order also shows the **Deliver This Order** button at the bottom, so the same flow starts from there.

**Done when:**
- Delivery → Deliver → Delivery Details → Deliver This Order → Confirm Delivery → Confirm Delivery shows the order as Delivered with the receiver recorded.
- Pressing Cancel at any point leaves the order Pending.
- A discount added on the Confirm Delivery page changes the order's Due and the invoice.

### FIX-22 — Reports download as PDF

**Now:** Dashboard report, Staff Summary and Staff Management download as **CSV** files. The pages themselves are fine and stay as they are.

**Required:**

1. On these screens, **one download button** replaces the CSV button and any "PDF / Print" button:
   - **Dashboard** (the report for the selected period)
   - **Staff Summary** (the visible table and cards for the selected period, month, status and search)
   - **Staff Management → worker month page** (that worker's entries for that month and year)
   - The **Payslip** for one worker and one month (FIX-14) also downloads as a PDF file.
2. Tapping it **creates a real .pdf file and downloads it immediately**. No print dialog, no preview page, no new tab, and no CSV. Show "Preparing PDF…" while it works, then "PDF downloaded". It works on a phone browser and on a computer.
3. **Content** is what the screen shows for the current selection. Each PDF has:
   - a header with the shop logo and shop name from Settings → Invoice template, the report title, the period or month, and the date and time it was made;
   - the summary cards as a block of figures;
   - the full table with **every column** and a **totals row**;
   - a footer with "Page 1 of N";
   - table headings **repeated on every page**, and **no row split** across two pages.
4. **Per file:**
   - **Dashboard:** every card figure for the chosen period, the monthly performance table, order status counts, Branch split, Airman quantity per item, the overdue deliveries count and the recent orders table. Charts appear as simple drawn bars when possible; the tables must always be there.
   - **Staff Summary:** the six cards (Total Staff, Total Amount, Total Khorach, Total Payable, Total Received, Total Due), then the table (#, Staff Name with the Bangla name, Total Amount, Khorach, Net Payable, Received, Due, Status) and a totals row.
   - **Worker month page:** worker name in English and Bangla, month and year, the entries table in its own column order, blank rows skipped, and the footer figures (Total, Total Khorach, Total Payable, Received, Due).
   - **Payslip:** as in FIX-14.
5. **Paper:** A4. Use **landscape** for wide tables (Staff Summary, the month table) and portrait where it fits (Dashboard, Payslip). The builder may choose per file.
6. **File names** start with the app name and say what and when, for example `raymond-staff-summary-2026-10.pdf`, `raymond-dashboard-report-2026-10.pdf`, `raymond-worker-<name>-2026-10.pdf`. No spaces.
7. **Bangla and taka sign:** Bangla worker names and the **৳** sign must appear correctly in the PDF, never as boxes or question marks. Bundle a font that has Bengali glyphs and the taka sign with the app. Making the PDF must not need the internet.
8. **Empty result:** if there are no rows, show "Nothing to download for this selection." and make no file.
9. **Removed:** the CSV buttons on the Dashboard, Staff Summary and the worker month page. The **Settings → Data & Backup** downloads (backup file and all-data export) stay as they are (section 5, question 13).
10. Do not use the browser's print for these files. **Cutting slips and invoices keep using normal print** (FIX-20 and Loop 3).

**Done when:**
- Pressing the download button on the Dashboard, Staff Summary and a worker month page saves a `.pdf` file straight away, with no print dialog and no `.csv`.
- A worker with a Bangla name shows the Bangla name and ৳ correctly in the PDF.
- A table that is longer than one page continues on the next page with its headings repeated.

### FIX-23 — Due After Delivery card

**Now:** The owner's Orders screen shows a **Pending Cutting Slip** card and an **Order** card.

**Required:** in place of the **Pending Cutting Slip** card, show the **Due After Delivery** card, as in Loop 2 section 5.1 and in the owner's recording:

- Shows the **total taka of Due on Delivered Officer orders where Due is above 0**, and how many such orders there are, for example `৳86,712` and `8 orders`.
- Red styling, with a taka icon, so it reads as money still owed. The other card keeps its look.
- Tapping the card filters the list to those orders and shows the chip "Filter: Due After Delivery ✕". Tapping the chip clears it.
- The figure updates after Confirm Delivery (Discount and Cash Receive), Pay, editing an order, deleting an order and restoring one.
- The Pending Cutting Slip card, its filter, and its chip are **removed completely**. No hidden code path may still show them.
- The Airman screen cards (one per Airman item) do not change.

Where exactly the card sits and which card stays beside it is in section 5, question 14.

**Done when:** the Orders screen shows Due After Delivery in the place of Pending Cutting Slip, the figure matches the sum of Due on Delivered orders, and tapping it lists exactly those orders.

## 4. Data additions

- **Items (Officer and Airman lists):** a new field **Slip type** (Shirt, Pant, Shirt + Pant). Existing items get the default from section 5, question 1. Changing it never changes saved orders.
- **Order (all categories):** **Receiver Name** and **Receiver Phone Number**, saved on Confirm Delivery.
- **Order (Officer):** the discount may be changed at delivery; Cash Receive is saved as a normal payment record.
- **Airman orders:** Trade and Office values stay in stored data, hidden (FIX-19).
- **Settings:** no new settings screen. Slip type sits on the existing item rows.

## 5. Open decisions for the owner (use the default until answered)

1. **Slip type by item name.** Default: item names containing "Pant" are **Pant**; names containing "Shirt" or "Sleeve" are **Shirt**; every other item (for example Meskit, Summer Ceremonial, Winter Ceremonial, Battle Uniform, MODC Uniform) is **Shirt + Pant**. The owner can change any item in Settings. Please confirm or correct.
2. **Quantity on slips.** Default: one slip per item line, with "Qty N" shown when N is above 1. The other way is one slip per piece (quantity 2 gives two slips).
3. **Set item, per-item button.** Default: its Cutting Slip button opens its Shirt slip and Pant slip together as two separate cards. The other way is two buttons, one for Shirt and one for Pant.
4. **Slip measurement format.** Default: numbers only, joined with ` ~ `, Front as `F-`, Back as `B-`, as read from the recording. Confirm the order, or say if labels (Length, Chest …) should be printed.
5. **Date on the slip.** The recording shows the **delivery date** on an Officer slip. Default: delivery date for Officer, order date for Airman (Airman orders have no delivery date).
6. **Branch on the slip.** The recording shows Branch (GDP) on the slip. Default: show Branch on the cutting slip and on cards and details, but not on the invoice. This replaces the earlier default in Fix Pack V1, section 5, point 3.
7. **Airman bulk buttons.** The reference app has **Download All Cutting Slips**, **Download Not Downloaded**, and a "Downloaded" marker on each item. Default: **not built**. Say if wanted.
8. **Editing row left at Save Order.** Default: an unchanged editing row is ignored; a changed one is added automatically (FIX-18 point 5).
9. **Editing a saved item.** Default: pencil turns that line into an editing row in place, button **Update Item**.
10. **Confirm Delivery details.** Default: Discount in taka only; Delivered Date cannot be a future date; receiver name and phone are cleared if the order is moved away from Delivered.
11. **Status dropdown to Delivered.** Default: opens Confirm Delivery (it no longer saves at once).
12. **Delivery screen tabs.** The reference app has Pending Delivery, Delivered and All Orders tabs. Default: keep the current Officer and Airman tabs and the "not yet delivered" list only.
13. **CSV.** Default: the CSV buttons on the Dashboard, Staff Summary and worker month page are removed. **Settings → Data & Backup** keeps its backup and all-data CSV export, because those are data copies, not reports.
14. **The two cards.** Default: the Due After Delivery card replaces Pending Cutting Slip on the **Orders (Officer)** screen, beside the other card that stays. Tell me which screen you saw the Pending Cutting Slip card on, and which card is the "Order" card.
15. **Trade and Office in Settings.** Default: removed from Settings with the rest of FIX-19; old values stay in storage, hidden.
16. **Dashboard PDF content.** Default: as listed in FIX-22 point 4, including simple charts. Say if you want fewer or more sections.

## 6. Test scenarios

**A. Item rows.** New Order → the first item (Battle Uniform) is in an editing row, not in the list → change the item and quantity → press Add Item → it appears in the saved list, a new editing row appears → add a third item the same way → Total updates.

**B. Airman order.** New Airman Order → editing row with IV-Number → leave IV-Number empty and press Add Item → a clear message, nothing saved → type an IV-Number → Add Item → saved, new editing row. No Trade or Office anywhere on the form, card, details or slip.

**C. Single slip.** Open an order with three items → each item has a Cutting Slip button → tap the second one → only that item's slip is shown.

**D. Shirt and pant slips.** Open an order with a set item → its slips show as two cards, Shirt and Pant, each with its own measurements and notes.

**E. All slips, one print.** Open the same order → bottom Print Slip → all slips on one sheet, two per row → Print → the print dialog opens once.

**F. Delivery.** Delivery → Deliver on a row → Delivery Details page → Deliver This Order → Confirm Delivery → add Discount 50 and Cash Receive 100 → Due updates → Confirm Delivery → Order #N shows Delivered, Received by, the new discount, and a payment record.

**G. Cancel.** Start Delivery → Deliver This Order → Cancel → the order is still Pending.

**H. PDF.** Dashboard → download → a `.pdf` saves, no print dialog. Staff Summary and a worker month page do the same. A Bangla worker name prints correctly.

**I. Card.** Orders screen → the Due After Delivery card replaces Pending Cutting Slip → tap it → only Delivered orders with Due above 0 show → Pay one → the card total drops.

## 7. Out of scope (do not build, tell the owner if you think something is missing)

Airman bulk download buttons and the "Downloaded" marker (unless the owner says yes), tabs on the Delivery screen, online payments or real money movement, new reports beyond the PDFs above, changes to the invoice paper, changes to Staff Pay or History, login.

## 8. Acceptance checklist

- A new order opens with the first item in an **editing row**. Add Item saves it into a list and a new editing row appears. Airman rows need an IV-Number before Add Item.
- Airman screens, slips and Settings have **no Trade or Office**. IV-Number per item still works.
- Every item on Order Details has its own **Cutting Slip** button and it opens only that item's slip.
- Shirt and pant slips are **separate cards**, in the compact format, with no prices.
- The bottom Print Slip, the order card icon and the form button print **all slips of the order in one print**, two columns, no slip cut across pages.
- The old combined one-page slip is gone.
- Deliver and the status dropdown both lead to **Delivery Details → Deliver This Order → Confirm Delivery**. Nothing is delivered until Confirm Delivery is pressed. Cancel changes nothing.
- Confirm Delivery has Delivered Date, Total Amount, Discount, Advance, Cash Receive, Due, Receiver Name and Receiver Phone Number. Airman orders show no money fields.
- The Dashboard, Staff Summary, worker month page and Payslip **download a `.pdf` straight away**, with no CSV and no print dialog. Bangla and ৳ show correctly.
- The Orders screen shows **Due After Delivery** where Pending Cutting Slip was.
- Nothing else has changed. The word "optional" appears nowhere in the UI.
