import React from 'react';

/**
 * Darzi Design Language (Graphite and Parchment) Domain Illustrations
 * Signature Object: A tailor's hand-tag in graphite with an embossed ember coin (#fa7e42) and twine string.
 * Signature Motif: The 1px tape-measure ruler tick strip.
 */

export const TailorTagIllustration: React.FC<{
  size?: number;
  className?: string;
  withString?: boolean;
}> = ({ size = 140, className = '', withString = false }) => {
  return (
    <div
      style={{ width: size, height: withString ? size * 1.25 : size }}
      className={`relative flex items-center justify-center select-none ${className}`}
      aria-hidden="true"
    >
      <svg
        viewBox="0 0 160 180"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full drop-shadow-[0_12px_24px_rgba(0,0,0,0.18)]"
      >
        <defs>
          <linearGradient id="tagGraphite" x1="20" y1="30" x2="140" y2="160" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#3d3d40" />
            <stop offset="36%" stopColor="#1d1d1f" />
            <stop offset="100%" stopColor="#0a0a0b" />
          </linearGradient>
          <linearGradient id="tagSheen" x1="0" y1="0" x2="160" y2="180" gradientUnits="userSpaceOnUse">
            <stop offset="30%" stopColor="white" stopOpacity="0" />
            <stop offset="46%" stopColor="white" stopOpacity="0.14" />
            <stop offset="52%" stopColor="white" stopOpacity="0.02" />
            <stop offset="65%" stopColor="white" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="coinEmber" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#ff8b4e" />
            <stop offset="100%" stopColor="#f0561f" />
          </linearGradient>
        </defs>

        {/* Twine String */}
        {withString && (
          <path
            d="M80 8C74 16 86 28 80 42"
            stroke="#c8bcae"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
        )}

        {/* Tag Body with Chamfered Shoulders */}
        <g transform="rotate(-4 80 95)">
          {/* Subtle drop shadow behind tag */}
          <path
            d="M52 38L108 38L126 58V152C126 158.6 120.6 164 114 164H46C39.4 164 34 158.6 34 152V58L52 38Z"
            fill="url(#tagGraphite)"
            stroke="rgba(255,255,255,0.14)"
            strokeWidth="1.2"
          />
          {/* Sheen reflection overlay */}
          <path
            d="M52 38L108 38L126 58V152C126 158.6 120.6 164 114 164H46C39.4 164 34 158.6 34 152V58L52 38Z"
            fill="url(#tagSheen)"
          />

          {/* Brass Eyelet */}
          <circle cx="80" cy="52" r="5.5" fill="#f5f5f7" stroke="#9e9ea3" strokeWidth="1.5" />
          <circle cx="80" cy="52" r="3" fill="#1d1d1f" />

          {/* Embossed Ember Coin */}
          <g transform="translate(62, 86)">
            <circle cx="18" cy="18" r="18" fill="url(#coinEmber)" />
            <circle cx="18" cy="18" r="15.5" stroke="rgba(255,255,255,0.3)" strokeWidth="1" fill="none" />
            {/* Tailor Shears Icon on Coin */}
            <path
              d="M13 13L23 23M23 13L13 23"
              stroke="#ffffff"
              strokeWidth="2.2"
              strokeLinecap="round"
            />
            <circle cx="12" cy="12" r="2.5" stroke="#ffffff" strokeWidth="1.5" fill="none" />
            <circle cx="24" cy="24" r="2.5" stroke="#ffffff" strokeWidth="1.5" fill="none" />
          </g>

          {/* Minimal Stitched Detail Line at bottom */}
          <line
            x1="46"
            y1="146"
            x2="114"
            y2="146"
            stroke="rgba(255,255,255,0.2)"
            strokeWidth="1.5"
            strokeDasharray="3 3"
          />
        </g>
      </svg>
    </div>
  );
};

export const RulerTickStrip: React.FC<{
  className?: string;
  dark?: boolean;
}> = ({ className = 'h-6 w-full', dark = false }) => {
  return (
    <div
      className={`relative overflow-hidden select-none ${className}`}
      style={{
        backgroundImage: dark
          ? 'repeating-linear-gradient(90deg, rgba(29,29,31,0.25) 0 1px, transparent 1px 20px)'
          : 'repeating-linear-gradient(90deg, rgba(255,255,255,0.28) 0 1px, transparent 1px 20px)',
      }}
      aria-hidden="true"
    />
  );
};

export const EmptyStateCardsIllustration: React.FC<{
  size?: number;
  className?: string;
}> = ({ size = 180, className = '' }) => {
  return (
    <div
      style={{ width: size, height: size * 0.9 }}
      className={`relative flex items-center justify-center select-none ${className}`}
      aria-hidden="true"
    >
      <svg viewBox="0 0 180 160" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
        <defs>
          <linearGradient id="backEmber" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#fa7e42" />
            <stop offset="100%" stopColor="#f0561f" />
          </linearGradient>
          <linearGradient id="frontGraphite" x1="30" y1="30" x2="150" y2="140" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#3d3d40" />
            <stop offset="40%" stopColor="#1d1d1f" />
            <stop offset="100%" stopColor="#0a0a0b" />
          </linearGradient>
        </defs>

        {/* Back Card (Orange Ember) */}
        <rect
          x="34"
          y="20"
          width="96"
          height="108"
          rx="18"
          transform="rotate(-8 34 20)"
          fill="url(#backEmber)"
          opacity="0.9"
        />

        {/* Front Card (Graphite Object) */}
        <g transform="rotate(4 50 35)">
          <rect
            x="44"
            y="30"
            width="100"
            height="112"
            rx="18"
            fill="url(#frontGraphite)"
            stroke="rgba(255,255,255,0.12)"
            strokeWidth="1.5"
          />
          {/* #1 Entity Chip */}
          <rect x="56" y="44" width="32" height="24" rx="8" fill="rgba(255,255,255,0.12)" />
          <text x="72" y="60" textAnchor="middle" fill="#ffffff" fontSize="12" fontWeight="600" fontFamily="sans-serif">
            #1
          </text>

          {/* Tape measure ticks along bottom */}
          <line x1="56" y1="126" x2="132" y2="126" stroke="rgba(255,255,255,0.22)" strokeWidth="1" strokeDasharray="2 3" />

          {/* Plus Badge */}
          <circle cx="124" cy="46" r="13" fill="#0066cc" />
          <path d="M124 40V52M118 46H130" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />
        </g>
      </svg>
    </div>
  );
};
