import React from 'react';
import {
  Shield,
  Shirt,
  Scissors,
  Award,
  Layers,
  Sparkles,
  Compass,
  Crown,
  Tag,
  Feather,
  Anchor,
  Crosshair,
  Package,
  Check,
  Upload,
  X,
} from 'lucide-react';

export interface GarmentLogoPreset {
  id: string;
  label: string;
  category: string;
  icon: React.ComponentType<{ className?: string }>;
  bgGradient: string;
  accentColor: string;
}

export const GARMENT_LOGO_PRESETS: GarmentLogoPreset[] = [
  {
    id: 'camo',
    label: 'Battle Uniform (Camo)',
    category: 'Uniform',
    icon: Crosshair,
    bgGradient: 'from-[#2e3b2b] to-[#1c241a]',
    accentColor: '#688c5d',
  },
  {
    id: 'shirt',
    label: 'Officer Shirt',
    category: 'Shirt',
    icon: Shirt,
    bgGradient: 'from-[#004b99] to-[#002d5e]',
    accentColor: '#388bfd',
  },
  {
    id: 'pant',
    label: 'Uniform Pant',
    category: 'Pant',
    icon: Layers,
    bgGradient: 'from-[#2d3139] to-[#181a1f]',
    accentColor: '#8b949e',
  },
  {
    id: 'ceremonial',
    label: 'Ceremonial Uniform',
    category: 'Ceremonial',
    icon: Award,
    bgGradient: 'from-[#8c6b1f] to-[#4d3a0e]',
    accentColor: '#d29922',
  },
  {
    id: 'bush',
    label: 'Half Bush',
    category: 'Uniform',
    icon: Anchor,
    bgGradient: 'from-[#1f4e5b] to-[#0f2c34]',
    accentColor: '#39c5cf',
  },
  {
    id: 'meskit',
    label: 'Meskit Mess Jacket',
    category: 'Meskit',
    icon: Sparkles,
    bgGradient: 'from-[#4c1d95] to-[#2e1065]',
    accentColor: '#a855f7',
  },
  {
    id: 'safari',
    label: 'Civilian Safari',
    category: 'Civil',
    icon: Compass,
    bgGradient: 'from-[#78350f] to-[#451a03]',
    accentColor: '#f59e0b',
  },
  {
    id: 'blazer',
    label: 'Blazer & Suit',
    category: 'Civil',
    icon: Crown,
    bgGradient: 'from-[#1e293b] to-[#0f172a]',
    accentColor: '#38bdf8',
  },
  {
    id: 'modc',
    label: 'MODC Guard',
    category: 'Uniform',
    icon: Shield,
    bgGradient: 'from-[#701a75] to-[#4a044e]',
    accentColor: '#e879f9',
  },
  {
    id: 'acc',
    label: 'Ribbons & Badge',
    category: 'Other',
    icon: Feather,
    bgGradient: 'from-[#9a3412] to-[#431407]',
    accentColor: '#fa7e42',
  },
  {
    id: 'general',
    label: 'Tailored Garment',
    category: 'General',
    icon: Scissors,
    bgGradient: 'from-[#27272a] to-[#09090b]',
    accentColor: '#e4e4e7',
  },
];

export function getGarmentLogoPreset(idOrName?: string, category?: string): GarmentLogoPreset {
  if (!idOrName) return GARMENT_LOGO_PRESETS[10]; // general

  // Exact ID match
  const exact = GARMENT_LOGO_PRESETS.find((p) => p.id === idOrName);
  if (exact) return exact;

  const lower = idOrName.toLowerCase();
  if (lower.includes('battle') || lower.includes('camo') || lower.includes('coverall')) {
    return GARMENT_LOGO_PRESETS[0];
  }
  if (lower.includes('ceremonial')) {
    return GARMENT_LOGO_PRESETS[3];
  }
  if (lower.includes('meskit')) {
    return GARMENT_LOGO_PRESETS[5];
  }
  if (lower.includes('bush')) {
    return GARMENT_LOGO_PRESETS[4];
  }
  if (lower.includes('safari')) {
    return GARMENT_LOGO_PRESETS[6];
  }
  if (lower.includes('blazer') || lower.includes('suit') || lower.includes('court')) {
    return GARMENT_LOGO_PRESETS[7];
  }
  if (lower.includes('modc')) {
    return GARMENT_LOGO_PRESETS[8];
  }
  if (lower.includes('pant') || lower.includes('paijama')) {
    return GARMENT_LOGO_PRESETS[2];
  }
  if (lower.includes('shirt') || lower.includes('fotua') || lower.includes('punjabi') || lower.includes('ganji')) {
    return GARMENT_LOGO_PRESETS[1];
  }
  if (lower.includes('appulate') || lower.includes('keti') || lower.includes('badge')) {
    return GARMENT_LOGO_PRESETS[9];
  }

  // Fallback on category
  if (category) {
    const cLower = category.toLowerCase();
    if (cLower === 'shirt') return GARMENT_LOGO_PRESETS[1];
    if (cLower === 'pant') return GARMENT_LOGO_PRESETS[2];
    if (cLower === 'ceremonial') return GARMENT_LOGO_PRESETS[3];
    if (cLower === 'meskit') return GARMENT_LOGO_PRESETS[5];
    if (cLower === 'civil') return GARMENT_LOGO_PRESETS[7];
  }

  return GARMENT_LOGO_PRESETS[10];
}

interface GarmentLogoProps {
  logo?: string;
  name?: string;
  category?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  shape?: 'rounded' | 'circle';
}

export const GarmentLogo: React.FC<GarmentLogoProps> = ({
  logo,
  name = '',
  category = '',
  size = 'md',
  className = '',
  shape = 'rounded',
}) => {
  // If logo is a custom image data URL or HTTP URL
  const isCustomImage = logo && (logo.startsWith('data:image') || logo.startsWith('http://') || logo.startsWith('https://'));

  const sizeClasses = {
    sm: 'w-7 h-7 text-[12px]',
    md: 'w-9 h-9 text-[14px]',
    lg: 'w-11 h-11 text-[16px]',
    xl: 'w-14 h-14 text-[20px]',
  };

  const iconSizes = {
    sm: 'w-3.5 h-3.5',
    md: 'w-4.5 h-4.5',
    lg: 'w-5 h-5',
    xl: 'w-7 h-7',
  };

  const radiusClass = shape === 'circle' ? 'rounded-full' : 'rounded-[12px]';

  if (isCustomImage) {
    return (
      <div
        className={`${sizeClasses[size]} ${radiusClass} overflow-hidden shrink-0 border border-[#e0e0e0] shadow-2xs bg-white ${className}`}
      >
        <img src={logo} alt={name || 'Garment Logo'} className="w-full h-full object-cover" />
      </div>
    );
  }

  const preset = getGarmentLogoPreset(logo || name, category);
  const IconComp = preset.icon;

  return (
    <div
      className={`${sizeClasses[size]} ${radiusClass} shrink-0 bg-gradient-to-br ${preset.bgGradient} text-white flex items-center justify-center shadow-xs border border-white/10 ${className}`}
      title={preset.label}
    >
      <IconComp className={iconSizes[size]} />
    </div>
  );
};

interface LogoPickerModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLogo?: string;
  garmentName: string;
  onSelectLogo: (logoIdOrUrl: string) => void;
}

export const LogoPickerModal: React.FC<LogoPickerModalProps> = ({
  isOpen,
  onClose,
  currentLogo,
  garmentName,
  onSelectLogo,
}) => {
  const [customUrl, setCustomUrl] = React.useState('');
  const [fileError, setFileError] = React.useState('');
  const fileInputRef = React.useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFileError('');
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setFileError('Please select a valid PNG, JPG, or SVG image file.');
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      setFileError('Image size exceeds 2MB limit.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        onSelectLogo(reader.result);
        onClose();
      }
    };
    reader.readAsDataURL(file);
  };

  const handleApplyUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (customUrl.trim()) {
      onSelectLogo(customUrl.trim());
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-60 flex items-center justify-center p-4">
      <div
        className="fixed inset-0 bg-black/40 backdrop-blur-xs transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        className="relative z-10 w-full max-w-lg bg-white rounded-[26px] border border-[#e0e0e0] shadow-[0_16px_48px_rgba(0,0,0,0.18)] p-6 space-y-5 select-none"
        role="dialog"
        aria-modal="true"
      >
        <div className="flex items-center justify-between pb-3 border-b border-[#f0f0f0]">
          <div>
            <h3 className="text-[18px] font-semibold text-[#1d1d1f]">Choose Garment Logo / Icon</h3>
            <p className="text-[13px] text-[#6e6e73]">Assign a military emblem or custom icon to &ldquo;{garmentName}&rdquo;</p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#6e6e73] hover:text-[#1d1d1f] flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Preset Emblem Grid */}
        <div>
          <span className="text-[12px] font-semibold text-[#6e6e73] uppercase tracking-wider block mb-2.5">
            Military & Tailoring Badges
          </span>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {GARMENT_LOGO_PRESETS.map((preset) => {
              const active = currentLogo === preset.id;
              const Icon = preset.icon;
              return (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => {
                    onSelectLogo(preset.id);
                    onClose();
                  }}
                  className={`p-3 rounded-[14px] border text-left flex items-center gap-3 transition-all cursor-pointer ${
                    active
                      ? 'border-[#0071e3] bg-[#f0f7ff] ring-2 ring-[#0071e3]/20'
                      : 'border-[#e0e0e0] hover:border-[#b0b0b0] bg-white hover:bg-[#fafafc]'
                  }`}
                >
                  <div
                    className={`w-9 h-9 rounded-[10px] bg-gradient-to-br ${preset.bgGradient} text-white flex items-center justify-center shrink-0 shadow-2xs`}
                  >
                    <Icon className="w-4.5 h-4.5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="text-[13px] font-semibold text-[#1d1d1f] block truncate">
                      {preset.label}
                    </span>
                    <span className="text-[11px] text-[#6e6e73]">{preset.category}</span>
                  </div>
                  {active && <Check className="w-4 h-4 text-[#0071e3] shrink-0" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Upload Custom Image Logo */}
        <div className="pt-2 border-t border-[#f0f0f0] space-y-3">
          <span className="text-[12px] font-semibold text-[#6e6e73] uppercase tracking-wider block">
            Or Upload Custom Insignia / Photo
          </span>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFileUpload}
          />

          <div className="flex flex-col sm:flex-row gap-2">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="h-10 px-4 rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#1d1d1f] text-[13px] font-semibold flex items-center justify-center gap-2 cursor-pointer transition-colors"
            >
              <Upload className="w-4 h-4 text-[#6e6e73]" />
              <span>Upload Image File</span>
            </button>

            <form onSubmit={handleApplyUrl} className="flex-1 flex gap-2">
              <input
                type="url"
                value={customUrl}
                onChange={(e) => setCustomUrl(e.target.value)}
                placeholder="https://... logo image URL"
                className="flex-1 h-10 px-3 rounded-[12px] bg-[#f5f5f7] border border-[#e0e0e0] text-[13px] outline-none focus:border-[#0071e3]"
              />
              <button
                type="submit"
                disabled={!customUrl.trim()}
                className="h-10 px-4 rounded-full bg-[#0066cc] disabled:bg-[#ccc] text-white text-[13px] font-semibold cursor-pointer"
              >
                Apply
              </button>
            </form>
          </div>

          {fileError && <p className="text-[12px] text-[#c62828] font-medium">{fileError}</p>}
        </div>
      </div>
    </div>
  );
};
