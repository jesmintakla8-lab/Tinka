import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { ScreenName } from './Navbar.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { formatDate } from '../utils/logic.ts';
import { Truck, CheckCircle2, AlertCircle, CreditCard, User, Phone } from 'lucide-react';

interface ConfirmDeliveryScreenProps {
  orderNumber: number;
  category: 'Officer' | 'Airman';
  onNavigate: (screen: ScreenName, params?: any) => void;
  returnTo?: 'delivery' | 'orders' | 'order-details';
}

export const ConfirmDeliveryScreen: React.FC<ConfirmDeliveryScreenProps> = ({
  orderNumber,
  category,
  onNavigate,
  returnTo = 'delivery',
}) => {
  const { state, confirmOfficerDelivery, confirmAirmanDelivery } = useApp();

  const isOfficer = category === 'Officer';
  const officerOrder = isOfficer ? state.officerOrders.find((o) => o.orderNumber === orderNumber) : null;
  const airmanOrder = !isOfficer ? state.airmanOrders.find((o) => o.orderNumber === orderNumber) : null;
  const order = isOfficer ? officerOrder : airmanOrder;

  const todayStr = formatDate();

  const [deliveredDate, setDeliveredDate] = useState<string>(todayStr);
  const initialDiscount = isOfficer && officerOrder ? officerOrder.discountAmount || 0 : 0;
  const [discountInput, setDiscountInput] = useState<string>(String(initialDiscount));
  const [cashReceiveInput, setCashReceiveInput] = useState<string>('0');

  const initialReceiverName = order ? order.customerName || '' : '';
  const initialReceiverPhone = order ? order.customerPhone || '' : '';
  const [receiverName, setReceiverName] = useState<string>(initialReceiverName);
  const [receiverPhone, setReceiverPhone] = useState<string>(initialReceiverPhone);
  const [formError, setFormError] = useState<string>('');

  if (!order) {
    return (
      <PolarisPage title="Order Not Found" backAction={() => onNavigate(returnTo)}>
        <div className="bg-white rounded-[24px] p-12 text-center border border-[#e0e0e0]">
          <p className="text-[15px] text-[#6e6e73] mb-4">
            Order #{orderNumber} was not found.
          </p>
          <button onClick={() => onNavigate(returnTo)} className="btn btn-primary">
            Back to Queue
          </button>
        </div>
      </PolarisPage>
    );
  }

  // Calculated numbers for Officer Order
  const { total, baseDue, finalDiscount, cashReceive, finalDue } = useMemo(() => {
    if (!isOfficer || !officerOrder) {
      return { total: 0, baseDue: 0, finalDiscount: 0, cashReceive: 0, finalDue: 0 };
    }
    const tot = officerOrder.totalAmount;
    const baseD = officerOrder.due;
    const disc = parseFloat(discountInput) || 0;
    const cash = parseFloat(cashReceiveInput) || 0;
    const remaining = Math.max(0, baseD - cash);
    return {
      total: tot,
      baseDue: baseD,
      finalDiscount: disc,
      cashReceive: cash,
      finalDue: remaining,
    };
  }, [isOfficer, officerOrder, discountInput, cashReceiveInput]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (isOfficer) {
      const res = confirmOfficerDelivery({
        orderNumber,
        deliveredDate,
        discountValue: discountInput,
        discountType: 'taka',
        discountAmount: finalDiscount,
        cashReceive: cashReceive,
        receiverName: receiverName.trim() || order.customerName,
        receiverPhone: receiverPhone.trim() || order.customerPhone || '',
      });

      if (!res.success) {
        setFormError(res.error || 'Failed to complete delivery');
        return;
      }
    } else {
      const res = confirmAirmanDelivery({
        orderNumber,
        deliveredDate,
        receiverName: receiverName.trim() || order.customerName,
        receiverPhone: receiverPhone.trim() || order.customerPhone || '',
      });

      if (!res.success) {
        setFormError(res.error || 'Failed to complete delivery');
        return;
      }
    }

    onNavigate(returnTo, { orderNumber, category });
  };

  return (
    <PolarisPage
      title={`Confirm Delivery · Order #${order.orderNumber}`}
      subtitle={`Handoff and receipt confirmation for ${order.customerName} (${order.customerBdNumber})`}
      backAction={() => onNavigate(returnTo)}
      fullWidth
    >
      <form onSubmit={handleSubmit} className="max-w-3xl mx-auto space-y-6">
        {formError && (
          <div className="p-4 rounded-[16px] bg-[#fceaea] border border-[#e5484d] text-[#c62828] text-[14px] flex items-center gap-2">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <span>{formError}</span>
          </div>
        )}

        {/* Financial Clearance Panel (Officer Orders) */}
        {isOfficer && (
          <div className="bg-white rounded-[24px] p-6 border border-[#e0e0e0] space-y-5 select-none">
            <h3 className="text-[20px] font-semibold text-[#1d1d1f]">
              Payment & Due Settlement
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 bg-[#f5f5f7] rounded-[18px]">
                <span className="text-[12px] text-[#6e6e73] block mb-1">Total Order Value</span>
                <span className="text-[24px] font-semibold text-[#1d1d1f] num">৳{total.toLocaleString()}</span>
              </div>
              <div className="p-4 bg-[#f5f5f7] rounded-[18px]">
                <span className="text-[12px] text-[#6e6e73] block mb-1">Current Balance Due</span>
                <span className="text-[24px] font-semibold text-[#c62828] num">৳{baseDue.toLocaleString()}</span>
              </div>
              <div className="p-4 bg-[#f5f5f7] rounded-[18px]">
                <span className="text-[12px] text-[#6e6e73] block mb-1">Due After Handoff</span>
                <span className={`text-[24px] font-semibold num ${finalDue > 0 ? 'text-[#c62828]' : 'text-[#1e7b43]'}`}>
                  ৳{finalDue.toLocaleString()}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="text-[13px] font-semibold text-[#1d1d1f] block mb-1.5">
                  Cash Received Now at Handoff (৳)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="0"
                    max={baseDue}
                    value={cashReceiveInput}
                    onChange={(e) => setCashReceiveInput(e.target.value)}
                    className="w-full h-[44px] px-4 rounded-[12px] bg-white border border-[#e0e0e0] text-[16px] font-semibold text-[#1d1d1f] num outline-none focus:border-[#0071e3]"
                  />
                  <button
                    type="button"
                    onClick={() => setCashReceiveInput(String(baseDue))}
                    className="absolute right-2 top-1/2 -translate-y-1/2 px-2.5 py-1 text-[12px] font-semibold text-[#0066cc] bg-[#f5f5f7] hover:bg-[#e0e0e0] rounded-full"
                  >
                    Clear Full Due
                  </button>
                </div>
              </div>

              <div>
                <label className="text-[13px] font-semibold text-[#1d1d1f] block mb-1.5">
                  Delivery Date
                </label>
                <input
                  type="date"
                  value={deliveredDate}
                  onChange={(e) => setDeliveredDate(e.target.value)}
                  className="w-full h-[44px] px-4 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] font-semibold text-[#1d1d1f] num outline-none focus:border-[#0071e3]"
                />
              </div>
            </div>
          </div>
        )}

        {/* Receiver Verification Panel */}
        <div className="bg-white rounded-[24px] p-6 border border-[#e0e0e0] space-y-5">
          <h3 className="text-[20px] font-semibold text-[#1d1d1f]">
            Receiver Verification & Receipt
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-[13px] font-semibold text-[#1d1d1f] block mb-1.5">
                Receiver Name
              </label>
              <input
                type="text"
                value={receiverName}
                onChange={(e) => setReceiverName(e.target.value)}
                placeholder="Receiver name (if colleague or orderly)"
                className="w-full h-[44px] px-4 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] text-[#1d1d1f] outline-none focus:border-[#0071e3]"
              />
            </div>

            <div>
              <label className="text-[13px] font-semibold text-[#1d1d1f] block mb-1.5">
                Receiver Phone
              </label>
              <input
                type="tel"
                value={receiverPhone}
                onChange={(e) => setReceiverPhone(e.target.value)}
                placeholder="Receiver mobile number"
                className="w-full h-[44px] px-4 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] text-[#1d1d1f] num outline-none focus:border-[#0071e3]"
              />
            </div>
          </div>
        </div>

        {/* Action Pair */}
        <div className="flex items-center justify-end gap-3 pt-4">
          <button
            type="button"
            onClick={() => onNavigate(returnTo)}
            className="h-[44px] px-6 rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[15px] font-semibold text-[#1d1d1f] cursor-pointer transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="h-[44px] px-8 rounded-full bg-[#0066cc] hover:bg-[#0071e3] text-[15px] font-semibold text-white cursor-pointer shadow-xs active:scale-95 transition-all flex items-center gap-2"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Complete & Deliver Order</span>
          </button>
        </div>
      </form>
    </PolarisPage>
  );
};
