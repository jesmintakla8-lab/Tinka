import React, { useState, useRef, useEffect } from 'react';
import { AirmanOrderItem, AirmanItemDefinition } from '../types/index.ts';
import { ManageItemsModal } from './ManageItemsModal.tsx';
import {
  ChevronDown,
  Search,
  Plus,
  X,
  Edit3,
  Pencil,
  Trash2,
  AlertCircle,
} from 'lucide-react';

interface CompactAirmanItemsPickerProps {
  items: AirmanOrderItem[];
  onChange: (items: AirmanOrderItem[]) => void;
  availableItems: AirmanItemDefinition[];
  editingRow: {
    catalogItem: AirmanItemDefinition | null;
    quantity: number;
    ivNumber: string;
  };
  onEditingRowChange: (
    row: { catalogItem: AirmanItemDefinition | null; quantity: number; ivNumber: string },
    touched: boolean
  ) => void;
  isEditingRowTouched: boolean;
}

export const CompactAirmanItemsPicker: React.FC<CompactAirmanItemsPickerProps> = ({
  items,
  onChange,
  availableItems,
  editingRow,
  onEditingRowChange,
  isEditingRowTouched,
}) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [rowError, setRowError] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);

  // In-place edit state for saved item
  const [inPlaceEditIndex, setInPlaceEditIndex] = useState<number | null>(null);
  const [inPlaceItem, setInPlaceItem] = useState<AirmanItemDefinition | null>(null);
  const [inPlaceQty, setInPlaceQty] = useState<number>(1);
  const [inPlaceIv, setInPlaceIv] = useState<string>('');
  const [inPlaceError, setInPlaceError] = useState('');
  const [inPlaceDropdownOpen, setInPlaceDropdownOpen] = useState(false);
  const [inPlaceSearch, setInPlaceSearch] = useState('');
  const inPlaceDropdownRef = useRef<HTMLDivElement>(null);

  const [manageModalOpen, setManageModalOpen] = useState(false);

  // Initialize editing row if not set
  useEffect(() => {
    if (availableItems.length > 0 && !editingRow.catalogItem) {
      const first = availableItems[0];
      onEditingRowChange(
        {
          catalogItem: first,
          quantity: 1,
          ivNumber: '',
        },
        false
      );
    }
  }, [availableItems, editingRow.catalogItem, onEditingRowChange]);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
      if (inPlaceDropdownRef.current && !inPlaceDropdownRef.current.contains(event.target as Node)) {
        setInPlaceDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredCatalog = availableItems.filter((i) =>
    i.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredInPlaceCatalog = availableItems.filter((i) =>
    i.name.toLowerCase().includes(inPlaceSearch.toLowerCase())
  );

  const handleAddItem = () => {
    if (!editingRow.catalogItem) return;

    const trimmedIv = (editingRow.ivNumber || '').trim();
    if (!trimmedIv) {
      setRowError('IV-Number is required before adding this item.');
      return;
    }

    setRowError('');
    const newItem: AirmanOrderItem = {
      id: `air-item-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      name: editingRow.catalogItem.name,
      quantity: editingRow.quantity,
      ivNumber: trimmedIv,
    };

    onChange([...items, newItem]);

    // Reset editing row with first item default, qty 1, empty IV
    const first = availableItems[0] || editingRow.catalogItem;
    onEditingRowChange(
      {
        catalogItem: first,
        quantity: 1,
        ivNumber: '',
      },
      false
    );
  };

  const handleRemoveSavedItem = (index: number) => {
    if (inPlaceEditIndex === index) {
      setInPlaceEditIndex(null);
    }
    const updated = items.filter((_, idx) => idx !== index);
    onChange(updated);
  };

  const handleStartInPlaceEdit = (index: number) => {
    const target = items[index];
    const catItem = availableItems.find((i) => i.name === target.name) || {
      id: `custom-air-${index}`,
      name: target.name,
    };
    setInPlaceEditIndex(index);
    setInPlaceItem(catItem);
    setInPlaceQty(target.quantity);
    setInPlaceIv(target.ivNumber || '');
    setInPlaceError('');
    setInPlaceDropdownOpen(false);
  };

  const handleSaveInPlaceEdit = () => {
    if (inPlaceEditIndex === null || !inPlaceItem) return;
    const trimmedIv = inPlaceIv.trim();
    if (!trimmedIv) {
      setInPlaceError('IV-Number is required.');
      return;
    }
    const updated = [...items];
    updated[inPlaceEditIndex] = {
      ...updated[inPlaceEditIndex],
      name: inPlaceItem.name,
      quantity: inPlaceQty,
      ivNumber: trimmedIv,
    };
    onChange(updated);
    setInPlaceEditIndex(null);
  };

  const handleCancelInPlaceEdit = () => {
    setInPlaceEditIndex(null);
  };

  return (
    <div className="bg-white rounded-2xl border border-[#E3E3E3] p-4 sm:p-5 shadow-[0_1px_2px_rgba(26,26,26,0.06)] space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-[#F1F1F1]">
        <div className="flex items-center space-x-2">
          <h3 className="text-sm sm:text-base font-bold text-[#1A1A1A] tracking-tight">
            1. Items
          </h3>
          <span className="text-xs text-[#616161] font-medium">
            ({items.length} {items.length === 1 ? 'item saved' : 'items saved'})
          </span>
        </div>

        <button
          type="button"
          onClick={() => setManageModalOpen(true)}
          className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-lg text-xs font-semibold text-[#005BD3] hover:text-[#0047A5] hover:bg-blue-50 transition-colors cursor-pointer"
          title="Manage Airman Uniform items"
        >
          <Edit3 className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Manage Items</span>
        </button>
      </div>

      {/* SAVED ITEMS LIST (ABOVE EDITING ROW) */}
      <div className="space-y-2">
        <label className="block text-[11px] font-bold text-[#616161] uppercase tracking-wider">
          Saved Items ({items.length})
        </label>

        {items.length === 0 ? (
          <div className="text-xs text-[#8A8A8A] italic py-2 px-3 bg-[#FAFBFB] rounded-xl border border-dashed border-[#E3E3E3]">
            No items saved yet. Specify IV-Number below and tap "Add Item".
          </div>
        ) : (
          <div className="space-y-2">
            {items.map((item, index) => {
              if (inPlaceEditIndex === index) {
                return (
                  <div
                    key={item.id || index}
                    className="p-3 bg-blue-50/50 border border-blue-300 rounded-xl space-y-2"
                  >
                    <div className="flex flex-wrap sm:flex-nowrap items-center gap-2">
                      {/* In-place Item Selector */}
                      <div className="relative flex-1 min-w-[160px]" ref={inPlaceDropdownRef}>
                        <button
                          type="button"
                          onClick={() => setInPlaceDropdownOpen(!inPlaceDropdownOpen)}
                          className="w-full h-9 px-3 bg-white border border-[#D1D5DB] rounded-lg flex items-center justify-between text-xs font-semibold text-[#303030]"
                        >
                          <span className="truncate">{inPlaceItem?.name || 'Select uniform'}</span>
                          <ChevronDown className="w-4 h-4 text-[#8A8A8A] shrink-0 ml-1" />
                        </button>
                        {inPlaceDropdownOpen && (
                          <div className="absolute left-0 top-full mt-1 w-full sm:w-[280px] bg-white rounded-xl border border-[#E3E3E3] shadow-xl z-50 overflow-hidden">
                            <div className="p-2 border-b border-[#E3E3E3] bg-[#F7F7F7]">
                              <input
                                type="text"
                                value={inPlaceSearch}
                                onChange={(e) => setInPlaceSearch(e.target.value)}
                                placeholder="Search..."
                                autoFocus
                                className="w-full h-7 px-2 text-xs bg-white border border-[#D1D5DB] rounded"
                              />
                            </div>
                            <div className="max-h-48 overflow-y-auto divide-y divide-[#F1F1F1] py-1">
                              {filteredInPlaceCatalog.map((cItem) => (
                                <button
                                  key={cItem.id}
                                  type="button"
                                  onClick={() => {
                                    setInPlaceItem(cItem);
                                    setInPlaceDropdownOpen(false);
                                  }}
                                  className="w-full px-3 py-1.5 text-xs flex justify-between text-left hover:bg-blue-50"
                                >
                                  <span className="truncate">{cItem.name}</span>
                                </button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                      {/* In-place Qty */}
                      <div className="w-16 shrink-0">
                        <select
                          value={inPlaceQty}
                          onChange={(e) => setInPlaceQty(Number(e.target.value))}
                          className="w-full h-9 px-2 bg-white border border-[#D1D5DB] rounded-lg text-xs font-bold text-center"
                        >
                          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((q) => (
                            <option key={q} value={q}>
                              {q}
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* In-place IV Input */}
                      <div className="w-28 sm:w-32 shrink-0">
                        <input
                          type="text"
                          value={inPlaceIv}
                          onChange={(e) => {
                            setInPlaceIv(e.target.value);
                            setInPlaceError('');
                          }}
                          placeholder="IV #"
                          className="w-full h-9 px-2.5 bg-white border border-[#D1D5DB] rounded-lg text-xs font-mono font-medium text-[#303030] focus:ring-1 focus:ring-[#005BD3]"
                        />
                      </div>

                      {/* In-place Actions */}
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={handleSaveInPlaceEdit}
                          className="h-9 px-3 bg-[#1A1A1A] hover:bg-black text-white text-xs font-bold rounded-lg shadow-2xs cursor-pointer"
                        >
                          Update Item
                        </button>
                        <button
                          type="button"
                          onClick={handleCancelInPlaceEdit}
                          className="h-9 px-2.5 bg-white border border-[#D1D5DB] hover:bg-[#F3F3F3] text-xs font-semibold rounded-lg text-[#616161] cursor-pointer"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                    {inPlaceError && (
                      <p className="text-xs text-[#8E0B21] font-medium">{inPlaceError}</p>
                    )}
                  </div>
                );
              }

              return (
                <div
                  key={item.id || index}
                  className="flex items-center justify-between p-2.5 bg-[#FAFBFB] hover:bg-white border border-[#E3E3E3] rounded-xl text-xs transition-colors shadow-2xs"
                >
                  <div className="flex items-center space-x-3 min-w-0">
                    <span className="font-bold text-[#1A1A1A] truncate">{item.name}</span>
                    <span className="text-[#616161] font-medium shrink-0">
                      Qty: {item.quantity}
                    </span>
                    <span className="font-mono text-blue-700 text-xs bg-blue-100/70 px-2 py-0.5 rounded-md font-semibold shrink-0">
                      IV: {item.ivNumber}
                    </span>
                  </div>

                  <div className="flex items-center space-x-1 shrink-0 ml-2">
                    <button
                      type="button"
                      onClick={() => handleStartInPlaceEdit(index)}
                      className="p-1.5 text-[#616161] hover:text-[#005BD3] hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                      title="Edit item"
                      aria-label={`Edit ${item.name}`}
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRemoveSavedItem(index)}
                      className="p-1.5 text-[#8A8A8A] hover:text-[#8E0B21] hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                      title="Delete item"
                      aria-label={`Delete ${item.name}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* EDITING ROW (BELOW SAVED ITEMS) */}
      <div className="pt-3 border-t border-[#E3E3E3] space-y-2.5">
        <div className="flex items-center justify-between">
          <label className="block text-[11px] font-bold text-[#1A1A1A] uppercase tracking-wider">
            Configure Item {isEditingRowTouched ? '(Unsaved Change)' : ''}
          </label>
          <span className="text-[11px] text-[#616161]">
            IV-Number required before adding
          </span>
        </div>

        <div className="flex flex-wrap sm:flex-nowrap items-center gap-2.5 relative">
          {/* Item Selector Dropdown */}
          <div className="relative flex-1 min-w-[180px]" ref={dropdownRef}>
            <button
              type="button"
              onClick={() => setDropdownOpen(!dropdownOpen)}
              className="w-full h-10 px-3.5 bg-[#FAFAFA] hover:bg-white border border-[#D1D5DB] rounded-xl flex items-center justify-between text-xs font-semibold text-[#303030] transition-all focus:outline-none focus:ring-2 focus:ring-[#005BD3] cursor-pointer text-left shadow-2xs"
            >
              <span className="truncate">
                {editingRow.catalogItem?.name || 'Select uniform'}
              </span>
              <ChevronDown className="w-4 h-4 text-[#8A8A8A] shrink-0 ml-2" />
            </button>

            {dropdownOpen && (
              <div className="absolute left-0 top-full mt-1.5 w-full sm:w-[320px] bg-white rounded-2xl border border-[#E3E3E3] shadow-xl z-50 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
                <div className="p-2.5 border-b border-[#E3E3E3] bg-[#F7F7F7]">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-[#8A8A8A]" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search uniform items..."
                      autoFocus
                      className="w-full h-8 pl-8 pr-7 text-xs bg-white border border-[#D1D5DB] rounded-lg text-[#303030] placeholder-[#8A8A8A] focus:outline-none focus:ring-1 focus:ring-[#005BD3]"
                    />
                    {searchQuery && (
                      <button
                        onClick={() => setSearchQuery('')}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#8A8A8A] hover:text-[#303030]"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="max-h-[200px] overflow-y-auto divide-y divide-[#F1F1F1] py-1">
                  {filteredCatalog.map((catalogItem) => {
                    const isSelected = editingRow.catalogItem?.id === catalogItem.id;
                    return (
                      <button
                        key={catalogItem.id}
                        type="button"
                        onClick={() => {
                          onEditingRowChange(
                            {
                              catalogItem,
                              quantity: editingRow.quantity,
                              ivNumber: editingRow.ivNumber,
                            },
                            true
                          );
                          setDropdownOpen(false);
                          setSearchQuery('');
                        }}
                        className={`w-full px-3.5 py-2 text-xs flex items-center justify-between text-left transition-colors cursor-pointer ${
                          isSelected
                            ? 'bg-blue-50/90 text-[#005BD3] font-bold'
                            : 'text-[#303030] hover:bg-[#F7F7F7] font-medium'
                        }`}
                      >
                        <span className="truncate pr-2">{catalogItem.name}</span>
                      </button>
                    );
                  })}
                </div>

                <div className="p-2 border-t border-[#E3E3E3] bg-[#F7F7F7]">
                  <button
                    type="button"
                    onClick={() => {
                      setDropdownOpen(false);
                      setManageModalOpen(true);
                    }}
                    className="w-full py-1.5 px-3 rounded-lg text-xs font-semibold text-[#303030] hover:text-[#005BD3] hover:bg-white flex items-center justify-center gap-1.5 transition-colors cursor-pointer border border-transparent hover:border-[#E3E3E3]"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>Manage Items</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Quantity Dropdown */}
          <div className="w-20 shrink-0">
            <select
              value={editingRow.quantity}
              onChange={(e) => {
                const q = Number(e.target.value);
                onEditingRowChange(
                  {
                    ...editingRow,
                    quantity: q,
                  },
                  true
                );
              }}
              className="w-full h-10 px-2.5 bg-[#FAFAFA] hover:bg-white border border-[#D1D5DB] rounded-xl text-xs font-bold text-[#303030] focus:outline-none focus:ring-2 focus:ring-[#005BD3] cursor-pointer text-center shadow-2xs"
              aria-label="Item quantity"
            >
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((q) => (
                <option key={q} value={q}>
                  {q}
                </option>
              ))}
            </select>
          </div>

          {/* IV Number Input (Required before add) */}
          <div className="w-28 sm:w-36 shrink-0">
            <input
              type="text"
              value={editingRow.ivNumber}
              onChange={(e) => {
                const val = e.target.value;
                setRowError('');
                onEditingRowChange(
                  {
                    ...editingRow,
                    ivNumber: val,
                  },
                  true
                );
              }}
              placeholder="IV #"
              className="w-full h-10 px-3 bg-[#FAFAFA] hover:bg-white border border-[#D1D5DB] rounded-xl text-xs font-mono font-medium text-[#303030] placeholder-[#8A8A8A] focus:outline-none focus:ring-2 focus:ring-[#005BD3] shadow-2xs"
            />
          </div>

          {/* + Add Item Button */}
          <button
            type="button"
            onClick={handleAddItem}
            className="h-10 px-4 bg-[#1A1A1A] hover:bg-black active:scale-95 text-white border border-[#303030] rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-[0_2px_4px_rgba(0,0,0,0.15)] cursor-pointer shrink-0"
          >
            <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>Add Item</span>
          </button>
        </div>

        {rowError && (
          <div className="flex items-center space-x-1.5 text-xs text-[#8E0B21] font-medium pt-1">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            <span>{rowError}</span>
          </div>
        )}
      </div>

      <ManageItemsModal
        isOpen={manageModalOpen}
        onClose={() => setManageModalOpen(false)}
        initialTab="airman"
      />
    </div>
  );
};
