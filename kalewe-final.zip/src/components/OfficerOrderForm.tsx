import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useApp } from '../context/AppContext.tsx';
import {
  OfficerOrder,
  OfficerOrderItem,
  PantMeasurements,
  ShirtMeasurements,
  ItemDefinition,
} from '../types/index.ts';
import {
  INITIAL_PANT_MEASUREMENTS,
  INITIAL_SHIRT_MEASUREMENTS,
} from '../utils/starterData.ts';
import {
  calculateDiscount,
  calculateDue,
  formatDate,
  getBdDigits,
  getLatestMeasurementsForCustomer,
  normalizeBdNumber,
} from '../utils/logic.ts';
import {
  Plus,
  Minus,
  Trash2,
  X,
  AlertCircle,
  Search,
  Check,
  CreditCard,
  User,
  Calendar,
  Ruler,
  ChevronDown,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { GarmentLogo } from './GarmentIcons.tsx';
import { AnimatePresence } from 'motion/react';

interface OfficerOrderFormProps {
  orderNumber?: number;
  draftId?: string;
  onNavigate: (screen: ScreenName, params?: any) => void;
}

const LOCAL_DRAFT_KEY = 'officer_order_local_autosave';

export const OfficerOrderForm: React.FC<OfficerOrderFormProps> = ({
  orderNumber,
  draftId,
  onNavigate,
}) => {
  const { state, saveOfficerOrder, saveDraft, deleteDraft } = useApp();

  const isEdit = typeof orderNumber === 'number';
  const existingOrder = isEdit ? state.officerOrders.find((o) => o.orderNumber === orderNumber) : null;
  const existingDraft = draftId ? state.drafts.find((d) => d.id === draftId) : null;

  // Form State
  const [items, setItems] = useState<OfficerOrderItem[]>(() => {
    if (existingOrder?.items && existingOrder.items.length > 0) return existingOrder.items;
    if (existingDraft?.officerItems && existingDraft.officerItems.length > 0) return existingDraft.officerItems;
    return [];
  });

  const [selectedCatalogItem, setSelectedCatalogItem] = useState<ItemDefinition | null>(() => {
    return state.settings.items[0] || null;
  });
  const [addItemQty, setAddItemQty] = useState<number>(1);
  const [addItemPrice, setAddItemPrice] = useState<number>(() => state.settings.items[0]?.price || 800);
  const [garmentSearch, setGarmentSearch] = useState('');

  const [shirt, setShirt] = useState<ShirtMeasurements>(INITIAL_SHIRT_MEASUREMENTS);
  const [pant, setPant] = useState<PantMeasurements>(INITIAL_PANT_MEASUREMENTS);

  // Customer info
  const [bdDigits, setBdDigits] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [branch, setBranch] = useState('');
  const [orderDate, setOrderDate] = useState(formatDate());
  const [deliveryDate, setDeliveryDate] = useState('');
  const [ribbon, setRibbon] = useState(state.settings.ribbonValues[0] || '1');

  const [totalAmount, setTotalAmount] = useState<number>(0);
  const [discountValue, setDiscountValue] = useState('');
  const [advance, setAdvance] = useState<number>(0);

  // Existing payments if editing
  const existingPayments = useMemo(() => existingOrder?.payments || [], [existingOrder]);

  const [formError, setFormError] = useState<string>('');
  const [autofilledNotice, setAutofilledNotice] = useState<string>('');
  const [cancelModalOpen, setCancelModalOpen] = useState(false);
  const [showBdDropdown, setShowBdDropdown] = useState(false);

  // Load existing order / draft
  useEffect(() => {
    if (existingOrder) {
      if (existingOrder.items?.length > 0) setItems(existingOrder.items);
      setShirt(existingOrder.shirtMeasurements || INITIAL_SHIRT_MEASUREMENTS);
      setPant(existingOrder.pantMeasurements || INITIAL_PANT_MEASUREMENTS);
      setBdDigits(getBdDigits(existingOrder.customerBdNumber || ''));
      setCustomerName(existingOrder.customerName || '');
      setPhone(existingOrder.customerPhone || '');
      setBranch(existingOrder.branch || '');
      setOrderDate(existingOrder.orderDate || formatDate());
      setDeliveryDate(existingOrder.deliveryDate || '');
      setRibbon(existingOrder.ribbon || state.settings.ribbonValues[0] || '1');
      setTotalAmount(existingOrder.totalAmount || 0);
      setDiscountValue(existingOrder.discountValue || '');
      setAdvance(existingOrder.advance || 0);
    } else if (existingDraft) {
      if (existingDraft.officerItems && existingDraft.officerItems.length > 0) setItems(existingDraft.officerItems);
      setShirt(existingDraft.shirtMeasurements || INITIAL_SHIRT_MEASUREMENTS);
      setPant(existingDraft.pantMeasurements || INITIAL_PANT_MEASUREMENTS);
      setBdDigits(getBdDigits(existingDraft.customerBdNumber || ''));
      setCustomerName(existingDraft.customerName || '');
      setPhone(existingDraft.customerPhone || '');
      setBranch(existingDraft.branch || '');
      setOrderDate(existingDraft.orderDate || formatDate());
      setDeliveryDate(existingDraft.deliveryDate || '');
      setRibbon(existingDraft.ribbon || state.settings.ribbonValues[0] || '1');
      setTotalAmount(existingDraft.totalAmount || 0);
      setDiscountValue(existingDraft.discountValue || '');
      setAdvance(existingDraft.advance || 0);
    }
  }, [existingOrder, existingDraft]);

  // Recalculate Total from items if not editing an existing order with custom total
  useEffect(() => {
    const sum = items.reduce((acc, it) => acc + (it.lineTotal || (it.price || 0) * it.quantity), 0);
    setTotalAmount(sum);
  }, [items]);

  // Financial Calculations
  const discountCalculation = useMemo(() => {
    return calculateDiscount(totalAmount, discountValue, state.settings.defaultDiscountType);
  }, [totalAmount, discountValue, state.settings.defaultDiscountType]);

  const due = useMemo(() => {
    return calculateDue(totalAmount, discountCalculation.amount, advance, existingPayments);
  }, [totalAmount, discountCalculation.amount, advance, existingPayments]);

  const paidPercent =
    totalAmount > 0
      ? Math.min(100, Math.round(((totalAmount - due) / totalAmount) * 100))
      : 100;

  // Handle customer auto-complete from BD Number
  const handleBdChange = (value: string) => {
    setBdDigits(value);
    const normalized = normalizeBdNumber(value);
    const matchedCustomer = state.customers.find(
      (c) => c.category === 'Officer' && normalizeBdNumber(c.bdNumber) === normalized
    );
    if (matchedCustomer) {
      setCustomerName(matchedCustomer.name);
      if (matchedCustomer.phone) setPhone(matchedCustomer.phone);
      setAutofilledNotice(`Filled from saved customer record: ${matchedCustomer.name}`);

      // Also check if customer has previous measurements
      const latest = getLatestMeasurementsForCustomer(
        matchedCustomer.bdNumber,
        'Officer',
        state.officerOrders,
        state.airmanOrders
      );
      if (latest && latest.found) {
        if (latest.shirt) setShirt(latest.shirt);
        if (latest.pant) setPant(latest.pant);
      }
    } else {
      setAutofilledNotice('');
    }
  };

  // BD Suggestions
  const bdSuggestions = useMemo(() => {
    if (!bdDigits || bdDigits.length < 1) return [];
    const q = bdDigits.trim();
    return state.customers
      .filter((c) => c.category === 'Officer' && getBdDigits(c.bdNumber).includes(q))
      .slice(0, 5);
  }, [bdDigits, state.customers]);

  const handleAddItem = () => {
    if (!selectedCatalogItem) return;
    const lineTotal = addItemPrice * addItemQty;
    const newItem: OfficerOrderItem = {
      id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      name: selectedCatalogItem.name,
      quantity: addItemQty,
      price: addItemPrice,
      lineTotal,
    };
    setItems((prev) => [...prev, newItem]);
    setAddItemQty(1);
  };

  const handleRemoveItem = (index: number) => {
    setItems((prev) => prev.filter((_, i) => i !== index));
  };

  const handleUpdateItemQty = (index: number, delta: number) => {
    setItems((prev) =>
      prev.map((it, i) => {
        if (i !== index) return it;
        const newQty = Math.max(1, (it.quantity || 1) + delta);
        return {
          ...it,
          quantity: newQty,
          lineTotal: newQty * (it.price || 0),
        };
      })
    );
  };

  const filteredCatalogItems = useMemo(() => {
    if (!garmentSearch.trim()) return state.settings.items;
    const q = garmentSearch.toLowerCase().trim();
    return state.settings.items.filter((i) =>
      i.name.toLowerCase().includes(q) || (i.category || '').toLowerCase().includes(q)
    );
  }, [state.settings.items, garmentSearch]);

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!customerName.trim()) {
      setFormError('Customer name is required.');
      return;
    }
    if (!bdDigits.trim()) {
      setFormError('BD number is required.');
      return;
    }
    if (items.length === 0) {
      setFormError('At least one uniform garment item must be added to the order.');
      return;
    }

    const normalizedBd = normalizeBdNumber(bdDigits);
    const payload = {
      orderNumber: isEdit ? orderNumber : undefined,
      customerName: customerName.trim(),
      customerBdNumber: normalizedBd,
      bdNumber: normalizedBd,
      customerPhone: phone.trim(),
      phone: phone.trim(),
      branch,
      orderDate,
      deliveryDate: deliveryDate || formatDate(),
      ribbon,
      status: existingOrder ? existingOrder.status : ('Pending' as const),
      items,
      shirtMeasurements: shirt,
      pantMeasurements: pant,
      measurements: {
        ...shirt,
        ...pant,
      },
      totalAmount,
      total: totalAmount,
      discountValue,
      discountAmount: discountCalculation.amount,
      discountType: state.settings.defaultDiscountType,
      advance,
      due,
      payments: existingPayments,
    };

    const res = saveOfficerOrder(payload as any, draftId);
    if (!res.success) {
      setFormError(res.error || 'Failed to save order.');
      return;
    }

    // Clear local draft on success
    try {
      localStorage.removeItem(LOCAL_DRAFT_KEY);
    } catch {}

    onNavigate('orders');
  };

  const isValidToSave = customerName.trim() && bdDigits.trim() && items.length > 0;

  return (
    <PolarisPage
      title={isEdit ? `Edit Officer Order #${orderNumber}` : 'New Officer Order'}
      subtitle={
        isEdit
          ? 'Update commissioned uniform garments, measurements, or billing amounts.'
          : 'Officer order. Items, measurements, and billing summary in one place.'
      }
      secondaryActions={[
        {
          label: 'Cancel',
          onClick: () => setCancelModalOpen(true),
        },
      ]}
      fullWidth
    >
      <form onSubmit={handleSubmitOrder}>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* =========================================================================
              LEFT COLUMN (8 Cols): Stacked Section Panels (Items, Customer, Measurements)
              Section 5.4 & Section 10.8
             ========================================================================= */}
          <div className="lg:col-span-8 space-y-6">
            {formError && (
              <div className="p-4 rounded-[16px] bg-[#fceaea] border border-[#e5484d] text-[#c62828] text-[14px] flex items-center gap-2">
                <AlertCircle className="w-5 h-5 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            {/* Section 1: Uniform Items with Horizontal Scrollable Garment Row & Minimalist Stepper */}
            <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-[#f0f0f0] gap-2.5">
                <div>
                  <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Uniform Garments</h3>
                  <p className="text-[13px] text-[#6e6e73]">
                    Scroll row to choose uniform type, adjust quantity with minimalist stepper
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-[#6e6e73] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      value={garmentSearch}
                      onChange={(e) => setGarmentSearch(e.target.value)}
                      placeholder="Filter garments..."
                      className="h-8 pl-8 pr-3 text-[12px] bg-[#f5f5f7] rounded-full border border-[#e0e0e0] outline-none focus:border-[#0071e3]"
                    />
                  </div>
                  <span className="text-[12px] font-bold text-[#1d1d1f] px-2.5 py-1 rounded-full bg-[#f5f5f7] border border-[#e0e0e0]/70 shrink-0">
                    {items.length} added
                  </span>
                </div>
              </div>

              {/* 1. HORIZONTAL SCROLLABLE GARMENT ROW ("Scroll like a row") */}
              <div>
                <label className="text-[11px] font-bold text-[#6e6e73] uppercase tracking-wider block mb-2">
                  Select Uniform Garment (Swipe or scroll row)
                </label>
                <div className="flex items-center gap-2.5 overflow-x-auto pb-2 no-scrollbar scroll-smooth">
                  {filteredCatalogItems.map((catItem) => {
                    const isSelected = selectedCatalogItem?.id === catItem.id;
                    return (
                      <button
                        key={catItem.id}
                        type="button"
                        onClick={() => {
                          setSelectedCatalogItem(catItem);
                          setAddItemPrice(catItem.price);
                        }}
                        className={`shrink-0 p-3 rounded-[14px] border text-left transition-all cursor-pointer min-w-[145px] max-w-[170px] select-none ${
                          isSelected
                            ? 'bg-blue-50/90 border-[#0066cc] ring-2 ring-[#0066cc] shadow-xs'
                            : 'bg-white border-[#e0e0e0] hover:border-[#1d1d1f] hover:bg-[#fafafc]'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <GarmentLogo logo={catItem.logo} name={catItem.name} category={catItem.category} size="sm" />
                          <span className="text-[12px] font-bold text-[#0066cc] num">
                            ৳{catItem.price}
                          </span>
                        </div>
                        <div className="text-[13px] font-bold text-[#1d1d1f] truncate leading-tight">
                          {catItem.name}
                        </div>
                        <div className="text-[11px] text-[#6e6e73] truncate">
                          {catItem.category || 'Uniform'}
                        </div>
                      </button>
                    );
                  })}
                  {filteredCatalogItems.length === 0 && (
                    <div className="text-[13px] text-[#6e6e73] py-2 px-3">
                      No matching garments found in catalog.
                    </div>
                  )}
                </div>
              </div>

              {/* 2. MINIMALIST CHOOSING & QUANTITY STEPPER TRAY */}
              <div className="p-4 bg-[#f5f5f7] rounded-[16px] border border-[#e0e0e0]/70 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-3 min-w-0">
                  {selectedCatalogItem && (
                    <GarmentLogo logo={selectedCatalogItem.logo} name={selectedCatalogItem.name} category={selectedCatalogItem.category} size="md" />
                  )}
                  <div className="min-w-0">
                    <span className="text-[11px] font-bold text-[#6e6e73] uppercase tracking-wider block">
                      Selected Garment
                    </span>
                    <div className="text-[16px] font-bold text-[#1d1d1f] truncate mt-0.5">
                      {selectedCatalogItem?.name || 'Select a garment'}
                    </div>
                    <div className="text-[12px] text-[#6e6e73]">
                      ৳{addItemPrice.toLocaleString()} each · Line total:{' '}
                      <strong className="text-[#0066cc] num">
                        ৳{(addItemPrice * addItemQty).toLocaleString()}
                      </strong>
                    </div>
                  </div>
                </div>

                {/* Minimalist Quantity Stepper + Presets + Add Button */}
                <div className="flex items-center gap-3 shrink-0 flex-wrap">
                  {/* Stepper */}
                  <div className="flex items-center bg-white rounded-[12px] border border-[#e0e0e0] p-1 shadow-2xs">
                    <button
                      type="button"
                      onClick={() => setAddItemQty((q) => Math.max(1, q - 1))}
                      className="w-8 h-8 rounded-[8px] hover:bg-[#f5f5f7] text-[#1d1d1f] flex items-center justify-center cursor-pointer active:scale-95 transition-all"
                      aria-label="Decrease quantity"
                    >
                      <Minus className="w-3.5 h-3.5 stroke-[2.5]" />
                    </button>
                    <span className="w-10 text-center font-bold text-[15px] text-[#1d1d1f] num">
                      {addItemQty}
                    </span>
                    <button
                      type="button"
                      onClick={() => setAddItemQty((q) => q + 1)}
                      className="w-8 h-8 rounded-[8px] hover:bg-[#f5f5f7] text-[#1d1d1f] flex items-center justify-center cursor-pointer active:scale-95 transition-all"
                      aria-label="Increase quantity"
                    >
                      <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                    </button>
                  </div>

                  {/* Preset Pills */}
                  <div className="hidden sm:flex items-center gap-1">
                    {[1, 2, 3, 4, 5].map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => setAddItemQty(preset)}
                        className={`w-7 h-8 rounded-[8px] text-[12px] font-bold transition-all cursor-pointer ${
                          addItemQty === preset
                            ? 'bg-[#1d1d1f] text-white'
                            : 'bg-white border border-[#e0e0e0] text-[#6e6e73] hover:text-[#1d1d1f]'
                        }`}
                      >
                        {preset}
                      </button>
                    ))}
                  </div>

                  {/* Add Button */}
                  <button
                    type="button"
                    onClick={handleAddItem}
                    className="h-10 px-4 rounded-[12px] bg-[#1d1d1f] hover:bg-black text-white text-[13px] font-bold cursor-pointer transition-all active:scale-95 shadow-xs flex items-center gap-1.5"
                  >
                    <Plus className="w-4 h-4 stroke-[2.5]" />
                    <span>Add to Order</span>
                  </button>
                </div>
              </div>

              {/* 3. ADDED ITEMS LIST WITH INLINE STEPPERS */}
              <div className="space-y-2 pt-1">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-bold text-[#6e6e73] uppercase tracking-wider">
                    Garments in this Order ({items.length})
                  </label>
                  {items.length > 0 && (
                    <span className="text-[12px] text-[#6e6e73]">
                      Tap + or − to adjust quantity instantly
                    </span>
                  )}
                </div>

                {items.length === 0 ? (
                  <div className="py-6 text-center text-[13px] text-[#6e6e73] bg-[#f5f5f7] rounded-[16px] border border-dashed border-[#e0e0e0]">
                    No garments added yet. Tap a garment above and click "Add to Order".
                  </div>
                ) : (
                  items.map((it, idx) => {
                    const price = it.price || 0;
                    const lineTot = it.lineTotal || price * it.quantity;
                    return (
                      <div
                        key={it.id || idx}
                        className="p-3 bg-[#f5f5f7] hover:bg-white border border-[#e0e0e0] rounded-[14px] flex items-center justify-between text-[13px] transition-all shadow-2xs"
                      >
                        <div className="flex items-center gap-3 min-w-0 pr-3">
                          <GarmentLogo name={it.name} size="sm" />
                          <div className="min-w-0">
                            <span className="font-bold text-[#1d1d1f] block truncate">
                              {it.name}
                            </span>
                            <span className="text-[12px] text-[#6e6e73]">
                              ৳{price.toLocaleString()} each
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-3 shrink-0">
                          {/* In-place minimalist stepper */}
                          <div className="flex items-center bg-white rounded-[10px] border border-[#e0e0e0] p-0.5">
                            <button
                              type="button"
                              onClick={() => handleUpdateItemQty(idx, -1)}
                              className="w-6 h-6 rounded-[6px] hover:bg-[#f5f5f7] text-[#1d1d1f] flex items-center justify-center cursor-pointer active:scale-90"
                              title="Decrease"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="w-7 text-center font-bold text-[13px] text-[#1d1d1f] num">
                              {it.quantity}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleUpdateItemQty(idx, 1)}
                              className="w-6 h-6 rounded-[6px] hover:bg-[#f5f5f7] text-[#1d1d1f] flex items-center justify-center cursor-pointer active:scale-90"
                              title="Increase"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>

                          <span className="font-bold text-[#1d1d1f] num min-w-[70px] text-right text-[14px]">
                            ৳{lineTot.toLocaleString()}
                          </span>

                          <button
                            type="button"
                            onClick={() => handleRemoveItem(idx)}
                            className="w-7 h-7 rounded-[8px] bg-white hover:bg-[#fceaea] hover:text-[#c62828] text-[#6e6e73] border border-[#e0e0e0] flex items-center justify-center cursor-pointer transition-colors"
                            title="Remove garment"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Section 2: Customer & Schedule */}
            <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#f0f0f0]">
                <div>
                  <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Customer & Schedule</h3>
                  <p className="text-[13px] text-[#6e6e73]">Officer identity, contact, and handoff date</p>
                </div>
              </div>

              {autofilledNotice && (
                <div className="p-3 rounded-[14px] bg-[#e3f4e8] text-[#1e7b43] text-[13px] flex items-center gap-2">
                  <Check className="w-4 h-4" />
                  <span>{autofilledNotice}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {/* BD Number with suggestions */}
                <div className="relative">
                  <label className="text-[13px] font-semibold text-[#1d1d1f] block mb-1">
                    Officer BD Number *
                  </label>
                  <input
                    type="text"
                    value={bdDigits}
                    onChange={(e) => handleBdChange(e.target.value)}
                    onFocus={() => setShowBdDropdown(true)}
                    placeholder="e.g. 12408 or BD/12408"
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] font-semibold text-[#1d1d1f] num outline-none focus:border-[#0071e3]"
                  />
                  {showBdDropdown && bdSuggestions.length > 0 && (
                    <div className="absolute left-0 right-0 top-full mt-1 bg-white rounded-[16px] border border-[#e0e0e0] shadow-lg z-20 overflow-hidden divide-y divide-[#f0f0f0]">
                      {bdSuggestions.map((sug) => (
                        <div
                          key={sug.bdNumber}
                          onClick={() => {
                            setBdDigits(getBdDigits(sug.bdNumber));
                            setCustomerName(sug.name);
                            if (sug.phone) setPhone(sug.phone);
                            setShowBdDropdown(false);
                            setAutofilledNotice(`Loaded customer: ${sug.name}`);
                          }}
                          className="p-3 hover:bg-[#f5f5f7] cursor-pointer text-[13px]"
                        >
                          <div className="font-semibold text-[#1d1d1f]">{sug.name}</div>
                          <div className="text-[12px] text-[#6e6e73]">BD/{sug.bdNumber} {sug.phone ? `· ${sug.phone}` : ''}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Customer Name */}
                <div>
                  <label className="text-[13px] font-semibold text-[#1d1d1f] block mb-1">
                    Officer Full Name *
                  </label>
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. F/L Tanvir Ahmed"
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] text-[#1d1d1f] outline-none focus:border-[#0071e3]"
                  />
                </div>

                {/* Phone Contact */}
                <div>
                  <label className="text-[13px] font-semibold text-[#1d1d1f] block mb-1">
                    Phone Contact
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="Mobile number"
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] text-[#1d1d1f] num outline-none focus:border-[#0071e3]"
                  />
                </div>

                {/* Branch / Unit */}
                <div>
                  <label className="text-[13px] font-semibold text-[#1d1d1f] block mb-1">
                    Branch / Trade
                  </label>
                  <input
                    type="text"
                    value={branch}
                    onChange={(e) => setBranch(e.target.value)}
                    placeholder="e.g. GD(P), ADWC, Admin"
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] text-[#1d1d1f] outline-none focus:border-[#0071e3]"
                  />
                </div>

                {/* Order Date */}
                <div>
                  <label className="text-[13px] font-semibold text-[#1d1d1f] block mb-1">
                    Order Date
                  </label>
                  <input
                    type="date"
                    value={orderDate}
                    onChange={(e) => setOrderDate(e.target.value)}
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] text-[#1d1d1f] num outline-none focus:border-[#0071e3]"
                  />
                </div>

                {/* Delivery Date */}
                <div>
                  <label className="text-[13px] font-semibold text-[#1d1d1f] block mb-1">
                    Target Delivery Date
                  </label>
                  <input
                    type="date"
                    value={deliveryDate}
                    onChange={(e) => setDeliveryDate(e.target.value)}
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] text-[#1d1d1f] num outline-none focus:border-[#0071e3]"
                  />
                </div>
              </div>
            </div>

            {/* Section 3: Measurements (Grouped into Parchment Trays) */}
            <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-5">
              <div className="flex items-center justify-between pb-3 border-b border-[#f0f0f0]">
                <div>
                  <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Measurements</h3>
                  <p className="text-[13px] text-[#6e6e73]">Bespoke tailored dimensions in inches</p>
                </div>
              </div>

              {/* Shirt / Jacket Measurements Tray */}
              <div className="p-5 bg-[#f5f5f7] rounded-[18px] space-y-3">
                <span className="text-[14px] font-semibold text-[#1d1d1f] block">
                  Coat / Shirt Dimensions
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {[
                    { key: 'length', label: 'Length' },
                    { key: 'chest', label: 'Chest' },
                    { key: 'belly', label: 'Belly' },
                    { key: 'shoulder', label: 'Shoulder' },
                    { key: 'sleeve', label: 'Sleeve' },
                    { key: 'collar', label: 'Collar' },
                    { key: 'cuff', label: 'Cuff' },
                  ].map(({ key, label }) => (
                    <div key={key}>
                      <label className="text-[11px] font-semibold text-[#6e6e73] block mb-1">
                        {label}
                      </label>
                      <input
                        type="text"
                        value={(shirt as any)[key] || ''}
                        onChange={(e) =>
                          setShirt((prev) => ({ ...prev, [key]: e.target.value }))
                        }
                        placeholder="—"
                        className="w-full h-[40px] px-3 text-center rounded-[10px] bg-white border border-[#e0e0e0] text-[15px] font-semibold text-[#1d1d1f] num outline-none focus:border-[#0071e3]"
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* Trousers Measurements Tray */}
              <div className="p-5 bg-[#f5f5f7] rounded-[18px] space-y-3">
                <span className="text-[14px] font-semibold text-[#1d1d1f] block">
                  Trousers / Pant Dimensions
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {[
                    { key: 'length', label: 'Length' },
                    { key: 'waist', label: 'Waist' },
                    { key: 'hip', label: 'Hip' },
                    { key: 'thigh', label: 'Thigh' },
                    { key: 'bottom', label: 'Bottom' },
                    { key: 'knee', label: 'Knee' },
                    { key: 'fly', label: 'Fly / Rise' },
                  ].map(({ key, label }) => (
                    <div key={key}>
                      <label className="text-[11px] font-semibold text-[#6e6e73] block mb-1">
                        {label}
                      </label>
                      <input
                        type="text"
                        value={(pant as any)[key] || ''}
                        onChange={(e) =>
                          setPant((prev) => ({ ...prev, [key]: e.target.value }))
                        }
                        placeholder="—"
                        className="w-full h-[40px] px-3 text-center rounded-[10px] bg-white border border-[#e0e0e0] text-[15px] font-semibold text-[#1d1d1f] num outline-none focus:border-[#0071e3]"
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* =========================================================================
              RIGHT COLUMN (4 Cols): Signature Graphite Live Summary Card
              Section 5.4 & Section 10.9
             ========================================================================= */}
          <div className="lg:col-span-4 sticky top-6">
            <div className="object-card p-6 rounded-[24px] space-y-5 select-none">
              <div className="relative z-10 space-y-5">
                {/* Total Row */}
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[14px] text-white/70 block">Total amount</span>
                    <span className="text-[11px] text-white/50 block">Auto sum (Price × Qty)</span>
                  </div>
                  <span className="text-[28px] font-semibold text-white num leading-tight">
                    ৳{totalAmount.toLocaleString()}
                  </span>
                </div>

                {/* Dark inputs for Discount and Advance */}
                <div className="space-y-3 pt-1 border-t border-white/10">
                  <div>
                    <label className="text-[12px] text-white/70 block mb-1">Discount</label>
                    <input
                      type="text"
                      value={discountValue}
                      onChange={(e) => setDiscountValue(e.target.value)}
                      placeholder="e.g. 10% or 200"
                      className="w-full h-[40px] px-3.5 rounded-[12px] bg-white/10 border border-white/15 text-white text-[15px] num placeholder-white/40 outline-none focus:border-[#2997ff]"
                    />
                  </div>

                  <div>
                    <label className="text-[12px] text-white/70 block mb-1">Advance received (৳)</label>
                    <input
                      type="number"
                      min="0"
                      max={totalAmount}
                      value={advance || ''}
                      onChange={(e) => setAdvance(parseFloat(e.target.value) || 0)}
                      placeholder="0"
                      className="w-full h-[40px] px-3.5 rounded-[12px] bg-white/10 border border-white/15 text-white text-[15px] font-semibold num placeholder-white/40 outline-none focus:border-[#2997ff]"
                    />
                  </div>
                </div>

                {/* Formula Divider & Coral Due Numeral per Section 10.9 */}
                <div className="pt-2 border-t border-white/10 space-y-1">
                  <div className="flex items-center justify-between text-[12px] text-white/60">
                    <span>Due Balance</span>
                    <span>Total − discount − advance</span>
                  </div>
                  <div className="text-[44px] font-semibold text-[#fe6a6a] num leading-none">
                    <span className="text-[20px] text-white/50 font-normal mr-1 align-top">৳</span>
                    {due.toLocaleString()}
                  </div>
                </div>

                {/* Thin White Progress Bar */}
                <div className="space-y-1">
                  <div className="h-1 bg-white/15 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-white rounded-full transition-all"
                      style={{ width: `${paidPercent}%` }}
                    />
                  </div>
                  <span className="text-[11px] text-white/60 block text-right num">
                    {paidPercent}% settled
                  </span>
                </div>

                {/* Single Primary Action: Save Order */}
                <button
                  type="submit"
                  disabled={!isValidToSave}
                  className="w-full h-[44px] rounded-full bg-[#0066cc] hover:bg-[#0071e3] disabled:opacity-50 text-white text-[15px] font-semibold cursor-pointer transition-all active:scale-95 shadow-xs flex items-center justify-center gap-2"
                >
                  <Check className="w-4 h-4 stroke-[2.5]" />
                  <span>{isEdit ? 'Update order' : 'Save order'}</span>
                </button>

                <p className="text-[12px] text-white/50 text-center leading-tight">
                  Needs a customer name, BD number and at least one item.
                </p>
              </div>
            </div>
          </div>
        </div>
      </form>

      {/* Cancel Modal */}
      <AnimatePresence>
        {cancelModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="fixed inset-0 bg-black/35 backdrop-blur-xs"
              onClick={() => setCancelModalOpen(false)}
            />
            <div className="relative z-10 w-full max-w-sm bg-white rounded-[28px] p-6 border border-[#e0e0e0] shadow-2xl">
              <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Leave without saving?</h3>
              <p className="text-[14px] text-[#6e6e73] mt-2">
                Any unsaved changes to this uniform order will be discarded.
              </p>
              <div className="grid grid-cols-2 gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setCancelModalOpen(false)}
                  className="h-[44px] rounded-full bg-[#f5f5f7] text-[#1d1d1f] font-semibold text-[14px]"
                >
                  Keep editing
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('orders')}
                  className="h-[44px] rounded-full bg-[#c62828] text-white font-semibold text-[14px]"
                >
                  Leave
                </button>
              </div>
            </div>
          </div>
        )}
      </AnimatePresence>
    </PolarisPage>
  );
};
