import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { StaffWorker } from '../types/index.ts';
import { MONTH_METADATA } from '../utils/starterData.ts';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import {
  Plus,
  Search,
  Edit2,
  Trash2,
  Folder,
  ArrowRight,
  UserCheck,
  X,
  Calendar,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';
import { AnimatePresence } from 'motion/react';

interface StaffManagementScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const StaffManagementScreen: React.FC<StaffManagementScreenProps> = ({ onNavigate }) => {
  const { state, addWorker, updateWorker, deleteWorker } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMonth, setSelectedMonth] = useState<string>(() => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  });

  // Modals
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newBanglaName, setNewBanglaName] = useState('');
  const [modalError, setModalError] = useState('');

  const [editTarget, setEditTarget] = useState<StaffWorker | null>(null);
  const [editName, setEditName] = useState('');
  const [editBanglaName, setEditBanglaName] = useState('');

  const [deleteTarget, setDeleteTarget] = useState<StaffWorker | null>(null);

  const filteredWorkers = useMemo(() => {
    let list = [...state.workers];
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        (w) =>
          w.name.toLowerCase().includes(q) ||
          (w.banglaName && w.banglaName.toLowerCase().includes(q))
      );
    }
    return list;
  }, [state.workers, searchQuery]);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setModalError('');
    if (!newName.trim()) {
      setModalError('Artisan name is required.');
      return;
    }
    const res = addWorker(newName.trim(), newBanglaName.trim());
    if (!res.success) {
      setModalError(res.error || 'Failed to add staff craftsman.');
      return;
    }
    setAddModalOpen(false);
    setNewName('');
    setNewBanglaName('');
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editTarget) return;
    updateWorker(editTarget.id, {
      name: editName.trim(),
      banglaName: editBanglaName.trim(),
    });
    setEditTarget(null);
  };

  const handleDeleteConfirm = () => {
    if (!deleteTarget) return;
    deleteWorker(deleteTarget.id);
    setDeleteTarget(null);
  };

  return (
    <PolarisPage
      title="Staff Craftsmen"
      subtitle="Master tailors, cutters, and sewing artisans piece-rate production registers."
      primaryAction={{
        label: 'Add craftsman',
        icon: <Plus className="w-4 h-4" />,
        onClick: () => {
          setModalError('');
          setAddModalOpen(true);
        },
      }}
      fullWidth
    >
      {/* Top Controls: Search + Month Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 select-none">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
          {MONTH_METADATA.slice(0, 6).map((m) => {
            const isSelected = selectedMonth.endsWith(m.numStr);
            return (
              <button
                key={m.numStr}
                aria-pressed={isSelected}
                onClick={() => setSelectedMonth(`2026-${m.numStr}`)}
                className={`h-9 px-3.5 rounded-full text-[13px] font-semibold transition-all cursor-pointer whitespace-nowrap ${
                  isSelected
                    ? 'bg-white border-2 border-[#0071e3] text-[#1d1d1f]'
                    : 'bg-white border border-[#e0e0e0] text-[#6e6e73] hover:text-[#1d1d1f]'
                }`}
              >
                {m.name}
              </button>
            );
          })}
        </div>

        <div className="relative min-w-[260px]">
          <Search className="w-4 h-4 text-[#6e6e73] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search craftsman name..."
            className="w-full h-[40px] pl-10 pr-8 rounded-full bg-white border border-[#e0e0e0] text-[14px] text-[#1d1d1f] placeholder-[#7a7a7a] outline-none focus:border-[#0071e3]"
          />
        </div>
      </div>

      {/* Staff Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredWorkers.map((worker) => (
          <div
            key={worker.id}
            className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 flex flex-col justify-between space-y-4 hover:border-[#1d1d1f] transition-all"
          >
            <div>
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="entity-chip text-white font-bold">
                    {worker.name.slice(0, 2).toUpperCase()}
                  </div>
                  <div className="min-w-0">
                    <h3 className="text-[17px] font-semibold text-[#1d1d1f] leading-snug truncate">
                      {worker.name}
                    </h3>
                    {worker.banglaName && (
                      <span className="text-[13px] text-[#6e6e73] block truncate">
                        {worker.banglaName}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => {
                      setEditTarget(worker);
                      setEditName(worker.name);
                      setEditBanglaName(worker.banglaName || '');
                    }}
                    className="w-8 h-8 rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#6e6e73] flex items-center justify-center cursor-pointer"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setDeleteTarget(worker)}
                    className="w-8 h-8 rounded-full bg-[#fceaea] hover:bg-[#fbdcdc] text-[#c62828] flex items-center justify-center cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="mt-4 p-3.5 bg-[#f5f5f7] rounded-[16px] text-[13px] text-[#6e6e73] space-y-1">
                <div className="flex justify-between">
                  <span>Status:</span>
                  <span className="font-semibold text-[#1e7b43]">Active Master</span>
                </div>
                <div className="flex justify-between">
                  <span>Selected Ledger:</span>
                  <span className="font-semibold text-[#1d1d1f] num">{selectedMonth}</span>
                </div>
              </div>
            </div>

            <button
              onClick={() =>
                onNavigate('worker-page', {
                  workerId: worker.id,
                  month: selectedMonth,
                })
              }
              className="w-full h-[40px] rounded-full bg-[#0066cc] hover:bg-[#0071e3] text-white text-[13px] font-semibold flex items-center justify-center gap-2 cursor-pointer shadow-xs active:scale-95 transition-all"
            >
              <Folder className="w-4 h-4" />
              <span>Open Monthly Hishab</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>

      {/* Add Worker Modal */}
      <AnimatePresence>
        {addModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="fixed inset-0 bg-black/35 backdrop-blur-xs"
              onClick={() => setAddModalOpen(false)}
            />
            <div className="relative z-10 w-full max-w-md bg-white rounded-[28px] p-6 border border-[#e0e0e0] shadow-2xl">
              <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Add Staff Craftsman</h3>
              <p className="text-[13px] text-[#6e6e73] mt-0.5">
                Register master cutter or tailor in the workshop ledger
              </p>

              {modalError && (
                <div className="my-3 p-3 rounded-[12px] bg-[#fceaea] text-[#c62828] text-[13px]">
                  {modalError}
                </div>
              )}

              <form onSubmit={handleAddSubmit} className="space-y-4 my-4">
                <div>
                  <label className="text-[12px] font-semibold text-[#6e6e73] block mb-1">
                    English Name *
                  </label>
                  <input
                    type="text"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="e.g. Master Rafiq"
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] outline-none focus:border-[#0071e3]"
                  />
                </div>
                <div>
                  <label className="text-[12px] font-semibold text-[#6e6e73] block mb-1">
                    Bangla Name (Optional)
                  </label>
                  <input
                    type="text"
                    value={newBanglaName}
                    onChange={(e) => setNewBanglaName(e.target.value)}
                    placeholder="e.g. রফিক"
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] outline-none focus:border-[#0071e3]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setAddModalOpen(false)}
                    className="h-[44px] rounded-full bg-[#f5f5f7] font-semibold text-[14px]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="h-[44px] rounded-full bg-[#0066cc] text-white font-semibold text-[14px]"
                  >
                    Save Craftsman
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit Worker Modal */}
      <AnimatePresence>
        {editTarget && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="fixed inset-0 bg-black/35 backdrop-blur-xs"
              onClick={() => setEditTarget(null)}
            />
            <div className="relative z-10 w-full max-w-md bg-white rounded-[28px] p-6 border border-[#e0e0e0] shadow-2xl">
              <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Edit Craftsman</h3>
              <form onSubmit={handleEditSubmit} className="space-y-4 my-4">
                <div>
                  <label className="text-[12px] font-semibold text-[#6e6e73] block mb-1">Name</label>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px]"
                  />
                </div>
                <div>
                  <label className="text-[12px] font-semibold text-[#6e6e73] block mb-1">Bangla Name</label>
                  <input
                    type="text"
                    value={editBanglaName}
                    onChange={(e) => setEditBanglaName(e.target.value)}
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px]"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setEditTarget(null)}
                    className="h-[44px] rounded-full bg-[#f5f5f7] font-semibold text-[14px]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="h-[44px] rounded-full bg-[#0066cc] text-white font-semibold text-[14px]"
                  >
                    Update
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation */}
      <AnimatePresence>
        {deleteTarget && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="fixed inset-0 bg-black/35 backdrop-blur-xs"
              onClick={() => setDeleteTarget(null)}
            />
            <div className="relative z-10 w-full max-w-sm bg-white rounded-[28px] p-6 border border-[#e0e0e0] shadow-2xl">
              <h3 className="text-[20px] font-semibold text-[#1d1d1f]">
                Delete {deleteTarget.name}?
              </h3>
              <p className="text-[14px] text-[#6e6e73] mt-2">
                This will remove the artisan from future monthly hishab assignments.
              </p>
              <div className="grid grid-cols-2 gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setDeleteTarget(null)}
                  className="h-[44px] rounded-full bg-[#f5f5f7] font-semibold text-[14px]"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleDeleteConfirm}
                  className="h-[44px] rounded-full bg-[#c62828] text-white font-semibold text-[14px]"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        )}
      </AnimatePresence>
    </PolarisPage>
  );
};
