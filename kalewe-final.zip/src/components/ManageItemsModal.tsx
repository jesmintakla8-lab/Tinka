import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { ItemDefinition, AirmanItemDefinition, WorkItemDefinition } from '../types/index.ts';
import { STARTER_ITEMS, STARTER_AIRMAN_ITEMS } from '../utils/starterData.ts';
import { GarmentLogo, LogoPickerModal, GARMENT_LOGO_PRESETS } from './GarmentIcons.tsx';
import {
  X,
  Search,
  Plus,
  Trash2,
  Check,
  Tag,
  AlertCircle,
  RotateCcw,
  Package,
  Minus,
  SlidersHorizontal,
  Sparkles,
  Camera,
  Layers,
} from 'lucide-react';

interface ManageItemsModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'officer' | 'airman' | 'worker';
  onPriceChange?: () => void;
}

const CATEGORIES = ['All', 'Uniform', 'Shirt', 'Pant', 'Ceremonial', 'Civil', 'Meskit', 'Other'];

export const ManageItemsModal: React.FC<ManageItemsModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'officer',
  onPriceChange,
}) => {
  const {
    state,
    updateSettings,
    deleteOfficerItem,
    deleteAirmanItem,
    updateWorkerItem,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'officer' | 'airman' | 'worker'>(initialTab);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [saveSuccessNotice, setSaveSuccessNotice] = useState<string>('');

  // Logo Picker State
  const [logoPickerItem, setLogoPickerItem] = useState<{
    id: string;
    name: string;
    currentLogo?: string;
    isAirman?: boolean;
  } | null>(null);

  // New Officer Item Form State
  const [newItemName, setNewItemName] = useState('');
  const [newItemPrice, setNewItemPrice] = useState<number | ''>('');
  const [newItemStock, setNewItemStock] = useState<number>(15);
  const [newItemCategory, setNewItemCategory] = useState<string>('Uniform');
  const [newItemLogo, setNewItemLogo] = useState<string>('camo');
  const [formError, setFormError] = useState<string>('');

  // Local price override state for smooth typing before blur
  const [priceOverrides, setPriceOverrides] = useState<Record<string, number>>({});

  const showNotice = (msg: string) => {
    setSaveSuccessNotice(msg);
    setTimeout(() => setSaveSuccessNotice(''), 3000);
  };

  // Stock Summary Stats
  const stockStats = useMemo(() => {
    const items = state.settings.items;
    let totalUnits = 0;
    let lowStockCount = 0;
    let outOfStockCount = 0;

    items.forEach((i) => {
      const count = i.stockCount ?? 12;
      totalUnits += count;
      if (count === 0) outOfStockCount++;
      else if (count <= 5) lowStockCount++;
    });

    return {
      totalSkus: items.length,
      totalUnits,
      lowStockCount,
      outOfStockCount,
    };
  }, [state.settings.items]);

  const filteredOfficerItems = useMemo(() => {
    let list = state.settings.items;
    if (selectedCategory !== 'All') {
      list = list.filter((i) => (i.category || 'Uniform').toLowerCase() === selectedCategory.toLowerCase());
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter((i) => i.name.toLowerCase().includes(q) || (i.category || '').toLowerCase().includes(q));
    }
    return list;
  }, [state.settings.items, selectedCategory, searchQuery]);

  const filteredAirmanItems = useMemo(() => {
    let list = state.settings.airmanItems;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter((i) => i.name.toLowerCase().includes(q));
    }
    return list;
  }, [state.settings.airmanItems, searchQuery]);

  const filteredWorkItems = useMemo(() => {
    let list = state.settings.workItems;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter((i) => i.name.toLowerCase().includes(q));
    }
    return list;
  }, [state.settings.workItems, searchQuery]);

  // Handle Add Item with Stock and Logo
  const handleAddNewOfficerItem = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    if (!newItemName.trim()) {
      setFormError('Item name is required');
      return;
    }
    const name = newItemName.trim();
    const exists = state.settings.items.some(
      (i) => i.name.toLowerCase() === name.toLowerCase()
    );
    if (exists) {
      setFormError('An item with this name already exists.');
      return;
    }

    const price = typeof newItemPrice === 'number' ? newItemPrice : 0;
    const stock = typeof newItemStock === 'number' ? newItemStock : 10;
    const newItem: ItemDefinition = {
      id: `item-${Date.now()}`,
      name,
      price,
      category: newItemCategory,
      needsPriceCheck: false,
      logo: newItemLogo,
      stockCount: stock,
      stockStatus: stock > 5 ? 'in_stock' : stock > 0 ? 'low_stock' : 'out_of_stock',
      sku: `BAF-${name.substring(0, 4).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`,
    };

    updateSettings({ items: [...state.settings.items, newItem] });
    showNotice(`Added "${name}" with ৳${price} and ${stock} in stock`);
    setNewItemName('');
    setNewItemPrice('');
    setNewItemStock(15);
    if (onPriceChange) onPriceChange();
  };

  const handleAddNewAirmanItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim()) return;
    const name = newItemName.trim();
    const exists = state.settings.airmanItems.some(
      (i) => i.name.toLowerCase() === name.toLowerCase()
    );
    if (exists) {
      setFormError('Airman item already exists');
      return;
    }

    const newItem: AirmanItemDefinition = {
      id: `air-item-${Date.now()}`,
      name,
      logo: newItemLogo,
      stockCount: 20,
      stockStatus: 'in_stock',
    };

    updateSettings({ airmanItems: [...state.settings.airmanItems, newItem] });
    showNotice(`Added Airman uniform "${name}"`);
    setNewItemName('');
  };

  const handleUpdateStock = (item: ItemDefinition, delta: number) => {
    const current = item.stockCount ?? 12;
    const nextStock = Math.max(0, current + delta);
    const updated = state.settings.items.map((i) =>
      i.id === item.id
        ? {
            ...i,
            stockCount: nextStock,
            stockStatus: (nextStock > 5 ? 'in_stock' : nextStock > 0 ? 'low_stock' : 'out_of_stock') as any,
          }
        : i
    );
    updateSettings({ items: updated });
    showNotice(`${item.name} stock set to ${nextStock}`);
  };

  const handleUpdateAirmanStock = (item: AirmanItemDefinition, delta: number) => {
    const current = item.stockCount ?? 20;
    const nextStock = Math.max(0, current + delta);
    const updated = state.settings.airmanItems.map((i) =>
      i.id === item.id
        ? {
            ...i,
            stockCount: nextStock,
            stockStatus: (nextStock > 5 ? 'in_stock' : nextStock > 0 ? 'low_stock' : 'out_of_stock') as any,
          }
        : i
    );
    updateSettings({ airmanItems: updated });
    showNotice(`${item.name} stock set to ${nextStock}`);
  };

  const handleSelectLogo = (logoKeyOrUrl: string) => {
    if (!logoPickerItem) return;
    if (logoPickerItem.isAirman) {
      const updated = state.settings.airmanItems.map((i) =>
        i.id === logoPickerItem.id ? { ...i, logo: logoKeyOrUrl } : i
      );
      updateSettings({ airmanItems: updated });
    } else {
      const updated = state.settings.items.map((i) =>
        i.id === logoPickerItem.id ? { ...i, logo: logoKeyOrUrl } : i
      );
      updateSettings({ items: updated });
    }
    showNotice(`Updated emblem for ${logoPickerItem.name}`);
    setLogoPickerItem(null);
  };

  const handlePriceBlur = (item: ItemDefinition, newPrice: number) => {
    if (newPrice !== item.price && !isNaN(newPrice)) {
      const updated = state.settings.items.map((i) =>
        i.id === item.id ? { ...i, price: Math.max(0, newPrice) } : i
      );
      updateSettings({ items: updated });
      showNotice(`Saved ${item.name} at ৳${newPrice}`);
      if (onPriceChange) onPriceChange();
    }
  };

  const handleResetOfficerDefaults = () => {
    updateSettings({ items: STARTER_ITEMS });
    showNotice('Officer item catalog reset to defaults');
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4">
        <div
          className="fixed inset-0 bg-black/45 backdrop-blur-xs transition-opacity"
          onClick={onClose}
          aria-hidden="true"
        />

        <div
          className="relative z-10 w-full max-w-4xl bg-white rounded-[24px] sm:rounded-[32px] border border-[#e0e0e0] shadow-[0_16px_50px_rgba(0,0,0,0.18)] flex flex-col max-h-[92vh] overflow-hidden select-none"
          role="dialog"
          aria-modal="true"
        >
          {/* Header */}
          <div className="px-5 sm:px-7 py-4 border-b border-[#f0f0f0] flex items-center justify-between gap-3 bg-white">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-[12px] bg-[#1d1d1f] text-white flex items-center justify-center shadow-xs">
                <Package className="w-5 h-5 text-[#fa7e42]" />
              </div>
              <div>
                <h3 className="text-[19px] font-semibold text-[#1d1d1f] tracking-tight">
                  Stock Management & Uniform Catalog
                </h3>
                <p className="text-[12px] text-[#6e6e73]">
                  Garment logos, inventory counts, pricing & military insignias
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={onClose}
                className="w-9 h-9 rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#6e6e73] hover:text-[#1d1d1f] flex items-center justify-center cursor-pointer transition-colors"
                aria-label="Close"
              >
                <X className="w-4.5 h-4.5" />
              </button>
            </div>
          </div>

          {/* Quick Metrics Bar */}
          <div className="px-5 sm:px-7 py-3 bg-[#f5f5f7] border-b border-[#e0e0e0]/70 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-4 sm:gap-6 flex-wrap">
              <div className="flex items-center gap-2">
                <span className="text-[#6e6e73]">Total SKUs:</span>
                <span className="font-semibold text-[#1d1d1f] text-[13px] num">
                  {stockStats.totalSkus}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[#6e6e73]">Total Stock Units:</span>
                <span className="font-semibold text-[#1d1d1f] text-[13px] num">
                  {stockStats.totalUnits} pcs
                </span>
              </div>
              {stockStats.lowStockCount > 0 && (
                <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#fdeee7] text-[#c2410c] font-semibold">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{stockStats.lowStockCount} Low stock</span>
                </div>
              )}
            </div>

            <span className="text-[11px] text-[#6e6e73] hidden sm:inline">
              Tap any logo to change insignia
            </span>
          </div>

          {/* Notice Banner */}
          {saveSuccessNotice && (
            <div className="mx-5 sm:mx-7 mt-3 px-3.5 py-2 rounded-[12px] bg-[#e3f4e8] text-[#1e7b43] text-[13px] font-semibold flex items-center gap-2">
              <Check className="w-4 h-4 shrink-0" />
              <span>{saveSuccessNotice}</span>
            </div>
          )}

          {/* Tab Chips & Search */}
          <div className="px-5 sm:px-7 py-3 border-b border-[#f0f0f0] flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white">
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1 sm:pb-0">
              {(['officer', 'airman', 'worker'] as const).map((tab) => {
                const active = activeTab === tab;
                const labels = {
                  officer: `Officer Stock (${state.settings.items.length})`,
                  airman: `Airman Stock (${state.settings.airmanItems.length})`,
                  worker: 'Artisan Rates',
                };
                return (
                  <button
                    key={tab}
                    type="button"
                    aria-pressed={active}
                    onClick={() => setActiveTab(tab)}
                    className={`h-8.5 px-3.5 rounded-full text-[13px] font-semibold transition-all cursor-pointer whitespace-nowrap ${
                      active
                        ? 'bg-[#1d1d1f] text-white shadow-xs'
                        : 'bg-[#f5f5f7] border border-[#e0e0e0] text-[#6e6e73] hover:text-[#1d1d1f]'
                    }`}
                  >
                    {labels[tab]}
                  </button>
                );
              })}
            </div>

            <div className="relative min-w-[220px]">
              <Search className="w-3.5 h-3.5 text-[#6e6e73] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Filter by uniform name..."
                className="w-full h-8.5 pl-8 pr-3 rounded-full bg-[#f5f5f7] border border-[#e0e0e0] text-[13px] outline-none focus:border-[#0071e3]"
              />
            </div>
          </div>

          {/* Category Filter Pills (Officer tab only) */}
          {activeTab === 'officer' && (
            <div className="px-5 sm:px-7 py-2 border-b border-[#f0f0f0] bg-[#fafafc] flex items-center gap-1.5 overflow-x-auto no-scrollbar">
              {CATEGORIES.map((cat) => {
                const active = selectedCategory === cat;
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setSelectedCategory(cat)}
                    className={`h-7 px-3 rounded-full text-[12px] font-medium transition-colors whitespace-nowrap cursor-pointer ${
                      active
                        ? 'bg-white border-2 border-[#0071e3] text-[#0066cc] font-semibold shadow-2xs'
                        : 'bg-transparent text-[#6e6e73] hover:text-[#1d1d1f]'
                    }`}
                  >
                    {cat}
                  </button>
                );
              })}
            </div>
          )}

          {/* Body Content */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-7 space-y-5 bg-[#fafafc]">
            {activeTab === 'officer' && (
              <div className="space-y-4">
                {/* Add New Item & Stock Bar */}
                <div className="p-4 bg-white rounded-[20px] border border-[#e0e0e0] shadow-2xs">
                  <span className="text-[12px] font-bold text-[#6e6e73] uppercase tracking-wider block mb-2.5">
                    + Add New Uniform / Garment with Stock
                  </span>
                  <form
                    onSubmit={handleAddNewOfficerItem}
                    className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-center"
                  >
                    {/* Logo Preview & Quick Preset */}
                    <div className="sm:col-span-2 flex items-center gap-2">
                      <GarmentLogo logo={newItemLogo} size="md" />
                      <select
                        value={newItemLogo}
                        onChange={(e) => setNewItemLogo(e.target.value)}
                        className="h-9 px-2 rounded-[10px] bg-[#f5f5f7] border border-[#e0e0e0] text-[12px] font-medium outline-none"
                        title="Pick emblem preset"
                      >
                        {GARMENT_LOGO_PRESETS.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.label}
                          </option>
                        ))}
                      </select>
                    </div>

                    <input
                      type="text"
                      value={newItemName}
                      onChange={(e) => setNewItemName(e.target.value)}
                      placeholder="e.g. BD Camo Serge Shirt"
                      className="sm:col-span-4 h-9 px-3 rounded-[10px] bg-[#f5f5f7] border border-[#e0e0e0] text-[13px] outline-none focus:border-[#0071e3]"
                    />

                    <select
                      value={newItemCategory}
                      onChange={(e) => setNewItemCategory(e.target.value)}
                      className="sm:col-span-2 h-9 px-2 rounded-[10px] bg-[#f5f5f7] border border-[#e0e0e0] text-[13px] outline-none"
                    >
                      {CATEGORIES.filter((c) => c !== 'All').map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>

                    <div className="sm:col-span-2 relative">
                      <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[11px] font-semibold text-[#6e6e73]">
                        Stock
                      </span>
                      <input
                        type="number"
                        min="0"
                        value={newItemStock}
                        onChange={(e) => setNewItemStock(Number(e.target.value) || 0)}
                        placeholder="15"
                        className="w-full h-9 pl-12 pr-2 rounded-[10px] bg-[#f5f5f7] border border-[#e0e0e0] text-[13px] num font-semibold outline-none"
                      />
                    </div>

                    <div className="sm:col-span-2 flex items-center gap-1.5">
                      <div className="relative flex-1">
                        <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[11px] font-semibold text-[#6e6e73]">
                          ৳
                        </span>
                        <input
                          type="number"
                          min="0"
                          value={newItemPrice}
                          onChange={(e) => setNewItemPrice(e.target.value === '' ? '' : Number(e.target.value))}
                          placeholder="Price"
                          className="w-full h-9 pl-6 pr-2 rounded-[10px] bg-[#f5f5f7] border border-[#e0e0e0] text-[13px] num font-semibold outline-none"
                        />
                      </div>
                      <button
                        type="submit"
                        className="h-9 px-3.5 rounded-full bg-[#0066cc] hover:bg-[#0071e3] text-white text-[13px] font-semibold flex items-center justify-center gap-1 cursor-pointer shrink-0 shadow-xs"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add</span>
                      </button>
                    </div>
                  </form>
                  {formError && <p className="text-[12px] text-[#c62828] mt-1.5">{formError}</p>}
                </div>

                {/* Garments Stock Cards List */}
                <div className="space-y-2.5">
                  {filteredOfficerItems.map((item) => {
                    const currentDisplayPrice =
                      priceOverrides[item.id] !== undefined ? priceOverrides[item.id] : item.price;
                    const stock = item.stockCount ?? 12;
                    const isLowStock = stock > 0 && stock <= 5;
                    const isOutStock = stock === 0;

                    return (
                      <div
                        key={item.id}
                        className="bg-white p-3.5 rounded-[18px] border border-[#e0e0e0] hover:border-[#b0b0b0] flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors shadow-2xs"
                      >
                        {/* Left: Garment Logo & Identity */}
                        <div className="flex items-center gap-3 min-w-0">
                          <button
                            type="button"
                            onClick={() =>
                              setLogoPickerItem({
                                id: item.id,
                                name: item.name,
                                currentLogo: item.logo,
                              })
                            }
                            className="relative group cursor-pointer"
                            title="Click to change logo / upload insignia"
                          >
                            <GarmentLogo logo={item.logo} name={item.name} category={item.category} size="lg" />
                            <div className="absolute inset-0 rounded-[12px] bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition-opacity">
                              <Camera className="w-3.5 h-3.5" />
                            </div>
                          </button>

                          <div className="min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-semibold text-[15px] text-[#1d1d1f] truncate">
                                {item.name}
                              </span>
                              <span className="px-2 py-0.5 rounded-full text-[11px] font-medium bg-[#f5f5f7] border border-[#e0e0e0] text-[#6e6e73]">
                                {item.category || 'Uniform'}
                              </span>
                            </div>
                            <span className="text-[11px] text-[#8e8e93] num">
                              {item.sku || `SKU-BAF-${item.id.slice(-4)}`}
                            </span>
                          </div>
                        </div>

                        {/* Right: Stock Stepper + Price Input + Actions */}
                        <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-[#f0f0f0]">
                          {/* Stock Counter Stepper */}
                          <div className="flex items-center gap-1.5">
                            <div className="h-8 px-1.5 rounded-full bg-[#f5f5f7] border border-[#e0e0e0] flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => handleUpdateStock(item, -1)}
                                className="w-6 h-6 rounded-full bg-white hover:bg-[#e0e0e0] text-[#1d1d1f] flex items-center justify-center cursor-pointer shadow-2xs active:scale-90"
                                title="Reduce stock"
                              >
                                <Minus className="w-3 h-3" />
                              </button>
                              <span
                                className={`text-[12px] font-bold num px-2 min-w-[28px] text-center ${
                                  isOutStock
                                    ? 'text-[#c62828]'
                                    : isLowStock
                                    ? 'text-[#c2410c]'
                                    : 'text-[#1d1d1f]'
                                }`}
                              >
                                {stock}
                              </span>
                              <button
                                type="button"
                                onClick={() => handleUpdateStock(item, 1)}
                                className="w-6 h-6 rounded-full bg-white hover:bg-[#e0e0e0] text-[#1d1d1f] flex items-center justify-center cursor-pointer shadow-2xs active:scale-90"
                                title="Increase stock"
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                            </div>

                            {/* Stock Status Badge */}
                            <span
                              className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                                isOutStock
                                  ? 'bg-[#fceaea] text-[#c62828]'
                                  : isLowStock
                                  ? 'bg-[#fdeee7] text-[#c2410c]'
                                  : 'bg-[#e3f4e8] text-[#1e7b43]'
                              }`}
                            >
                              {isOutStock ? 'Out' : isLowStock ? 'Low' : 'In Stock'}
                            </span>
                          </div>

                          {/* Price Input */}
                          <div className="relative w-24">
                            <span className="absolute left-2 top-1/2 -translate-y-1/2 text-[12px] font-semibold text-[#6e6e73]">
                              ৳
                            </span>
                            <input
                              type="number"
                              min="0"
                              value={currentDisplayPrice}
                              onChange={(e) => {
                                const val = Number(e.target.value);
                                setPriceOverrides({ ...priceOverrides, [item.id]: val });
                              }}
                              onBlur={() => handlePriceBlur(item, currentDisplayPrice)}
                              className="w-full h-8 pl-5 pr-2 rounded-[8px] bg-[#f5f5f7] border border-[#e0e0e0] text-[13px] font-semibold text-right num outline-none focus:border-[#0071e3]"
                            />
                          </div>

                          {/* Delete Item */}
                          <button
                            type="button"
                            onClick={() => deleteOfficerItem(item.id)}
                            className="w-8 h-8 rounded-full hover:bg-[#fceaea] text-[#6e6e73] hover:text-[#c62828] flex items-center justify-center transition-colors cursor-pointer"
                            title="Delete item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {activeTab === 'airman' && (
              <div className="space-y-4">
                {/* Add Airman Item */}
                <div className="p-4 bg-white rounded-[20px] border border-[#e0e0e0] shadow-2xs">
                  <span className="text-[12px] font-bold text-[#6e6e73] uppercase tracking-wider block mb-2.5">
                    + Add New Airman Uniform / Trade Garment
                  </span>
                  <form
                    onSubmit={handleAddNewAirmanItem}
                    className="flex flex-col sm:flex-row items-center gap-2.5"
                  >
                    <div className="flex items-center gap-2">
                      <GarmentLogo logo={newItemLogo} size="md" />
                      <select
                        value={newItemLogo}
                        onChange={(e) => setNewItemLogo(e.target.value)}
                        className="h-9 px-2 rounded-[10px] bg-[#f5f5f7] border border-[#e0e0e0] text-[12px] font-medium outline-none"
                      >
                        {GARMENT_LOGO_PRESETS.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.label}
                          </option>
                        ))}
                      </select>
                    </div>
                    <input
                      type="text"
                      value={newItemName}
                      onChange={(e) => setNewItemName(e.target.value)}
                      placeholder="e.g. Airman Khaki Half Sleeve"
                      className="flex-1 h-9 px-3 rounded-[10px] bg-[#f5f5f7] border border-[#e0e0e0] text-[13px] outline-none"
                    />
                    <button
                      type="submit"
                      className="h-9 px-4 bg-[#0066cc] hover:bg-[#0071e3] text-white rounded-full text-[13px] font-semibold flex items-center gap-1 shrink-0 cursor-pointer shadow-xs"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add Airman Garment</span>
                    </button>
                  </form>
                </div>

                {/* Airman Items Cards */}
                <div className="space-y-2.5">
                  {filteredAirmanItems.map((item) => {
                    const stock = item.stockCount ?? 20;
                    return (
                      <div
                        key={item.id}
                        className="bg-white p-3.5 rounded-[18px] border border-[#e0e0e0] hover:border-[#b0b0b0] flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors shadow-2xs"
                      >
                        <div className="flex items-center gap-3">
                          <button
                            type="button"
                            onClick={() =>
                              setLogoPickerItem({
                                id: item.id,
                                name: item.name,
                                currentLogo: item.logo,
                                isAirman: true,
                              })
                            }
                            className="relative group cursor-pointer"
                            title="Change insignia / logo"
                          >
                            <GarmentLogo logo={item.logo} name={item.name} size="lg" />
                            <div className="absolute inset-0 rounded-[12px] bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition-opacity">
                              <Camera className="w-3.5 h-3.5" />
                            </div>
                          </button>
                          <div>
                            <span className="font-semibold text-[15px] text-[#1d1d1f] block">
                              {item.name}
                            </span>
                            <span className="text-[11px] text-[#6e6e73]">Airman BAF Issue</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-3 shrink-0">
                          {/* Stock Counter */}
                          <div className="h-8 px-1.5 rounded-full bg-[#f5f5f7] border border-[#e0e0e0] flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleUpdateAirmanStock(item, -1)}
                              className="w-6 h-6 rounded-full bg-white hover:bg-[#e0e0e0] text-[#1d1d1f] flex items-center justify-center cursor-pointer shadow-2xs active:scale-90"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="text-[12px] font-bold num px-2 min-w-[28px] text-center text-[#1d1d1f]">
                              {stock}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleUpdateAirmanStock(item, 1)}
                              className="w-6 h-6 rounded-full bg-white hover:bg-[#e0e0e0] text-[#1d1d1f] flex items-center justify-center cursor-pointer shadow-2xs active:scale-90"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>

                          <button
                            type="button"
                            onClick={() => deleteAirmanItem(item.id)}
                            className="w-8 h-8 rounded-full hover:bg-[#fceaea] text-[#6e6e73] hover:text-[#c62828] flex items-center justify-center cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {activeTab === 'worker' && (
              <div className="space-y-4">
                <div className="p-3.5 bg-white rounded-[18px] border border-[#e0e0e0] text-[13px] text-[#6e6e73]">
                  Artisan tailor piece-rates for sewing, cutting, and finishing uniforms.
                </div>

                <div className="divide-y divide-[#f0f0f0] border border-[#e0e0e0] bg-white rounded-[18px] overflow-hidden">
                  {filteredWorkItems.map((item) => (
                    <div
                      key={item.id}
                      className="p-3 flex items-center justify-between gap-3 hover:bg-[#fafafc]"
                    >
                      <span className="font-semibold text-[14px] text-[#1d1d1f] truncate">
                        {item.name}
                      </span>
                      <div className="relative w-28 shrink-0">
                        <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[12px] font-semibold text-[#6e6e73]">
                          ৳
                        </span>
                        <input
                          type="number"
                          min="0"
                          defaultValue={item.rate}
                          onBlur={(e) => {
                            const val = Number(e.target.value);
                            if (val !== item.rate && !isNaN(val)) {
                              updateWorkerItem(item.id, item.name, val);
                              showNotice(`Updated rate to ৳${val}`);
                            }
                          }}
                          className="w-full h-8 pl-6 pr-2 rounded-[8px] bg-[#f5f5f7] border border-[#e0e0e0] text-[13px] font-semibold text-right num outline-none focus:border-[#0071e3]"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="px-5 sm:px-7 py-4 border-t border-[#f0f0f0] bg-white flex items-center justify-between">
            {activeTab === 'officer' ? (
              <button
                type="button"
                onClick={handleResetOfficerDefaults}
                className="text-[12px] font-semibold text-[#6e6e73] hover:text-[#1d1d1f] flex items-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Defaults</span>
              </button>
            ) : (
              <span />
            )}

            <button
              type="button"
              onClick={onClose}
              className="h-[42px] px-7 rounded-full bg-[#0066cc] hover:bg-[#0071e3] text-white text-[14px] font-semibold cursor-pointer active:scale-95 transition-all shadow-xs"
            >
              Done
            </button>
          </div>
        </div>
      </div>

      {/* Emblem / Logo Picker Modal */}
      {logoPickerItem && (
        <LogoPickerModal
          isOpen={true}
          onClose={() => setLogoPickerItem(null)}
          currentLogo={logoPickerItem.currentLogo}
          garmentName={logoPickerItem.name}
          onSelectLogo={handleSelectLogo}
        />
      )}
    </>
  );
};
