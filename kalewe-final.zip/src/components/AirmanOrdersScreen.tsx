import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../context/AppContext.tsx';
import { AirmanOrder, OrderStatus } from '../types/index.ts';
import { StatusBadge } from './StatusBadge.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { EmptyStateCardsIllustration, RulerTickStrip } from './Illustrations.tsx';
import {
  Plus,
  Search,
  ArrowUpDown,
  Printer,
  Edit2,
  Trash2,
  Plane,
  X,
  Scissors,
  Calendar,
  CheckCircle2,
  LayoutGrid,
  List,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';

interface AirmanOrdersScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const AirmanOrdersScreen: React.FC<AirmanOrdersScreenProps> = ({ onNavigate }) => {
  const { state, updateAirmanOrderStatus, deleteAirmanOrder } = useApp();

  const [selectedYear, setSelectedYear] = useState<string>('All');
  const [activeTab, setActiveTab] = useState<'All' | OrderStatus>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');

  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');

  const [selectedOrderNumber, setSelectedOrderNumber] = useState<number | null>(() => {
    return state.airmanOrders.length > 0 ? state.airmanOrders[0].orderNumber : null;
  });

  // Two-step delete dialog
  const [deleteTargetOrder, setDeleteTargetOrder] = useState<AirmanOrder | null>(null);
  const [deleteStep, setDeleteStep] = useState<1 | 2>(1);

  // Filter orders by running year
  const yearOrders = useMemo(() => {
    if (selectedYear === 'All') return state.airmanOrders;
    return state.airmanOrders.filter((o) => o.runningYear === selectedYear);
  }, [state.airmanOrders, selectedYear]);

  // Tab counts
  const tabCounts = useMemo(() => {
    return {
      All: yearOrders.length,
      Pending: yearOrders.filter((o) => o.status === 'Pending').length,
      'Cutting Slip – Done': yearOrders.filter((o) => o.status === 'Cutting Slip – Done').length,
      Delivered: yearOrders.filter((o) => o.status === 'Delivered').length,
    };
  }, [yearOrders]);

  // Pending count
  const pendingCount = useMemo(() => {
    return yearOrders.filter((o) => o.status !== 'Delivered').length;
  }, [yearOrders]);

  // Filter and sort orders
  const filteredOrders = useMemo(() => {
    let list = [...yearOrders];

    if (activeTab !== 'All') {
      list = list.filter((o) => o.status === activeTab);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter((o) => {
        const orderNumStr = String(o.orderNumber);
        const nameMatch = (o.customerName || '').toLowerCase().includes(q);
        const bdMatch = (o.customerBdNumber || '').toLowerCase().includes(q);
        const ivMatch = o.items.some((it) => (it.ivNumber || '').toLowerCase().includes(q));
        const itemMatch = o.items.some((it) => (it.name || '').toLowerCase().includes(q));
        return orderNumStr.includes(q) || nameMatch || bdMatch || ivMatch || itemMatch;
      });
    }

    list.sort((a, b) => {
      if (sortOrder === 'newest') {
        return b.orderNumber - a.orderNumber;
      }
      return a.orderNumber - b.orderNumber;
    });

    return list;
  }, [yearOrders, activeTab, searchQuery, sortOrder]);

  const currentSelectedOrder = useMemo(() => {
    if (!filteredOrders.length) return null;
    const found = filteredOrders.find((o) => o.orderNumber === selectedOrderNumber);
    return found || filteredOrders[0];
  }, [filteredOrders, selectedOrderNumber]);

  const handleDeleteStepOne = (order: AirmanOrder) => {
    setDeleteTargetOrder(order);
    setDeleteStep(1);
  };

  const handleDeleteConfirm = () => {
    if (!deleteTargetOrder) return;
    if (deleteStep === 1) {
      setDeleteStep(2);
    } else {
      deleteAirmanOrder(deleteTargetOrder.orderNumber);
      setDeleteTargetOrder(null);
      setDeleteStep(1);
    }
  };

  return (
    <PolarisPage
      title="Airman Orders"
      subtitle="Bangladesh Air Force non-commissioned airmen trade batch uniforms and tailoring orders."
      primaryAction={{
        label: 'New order',
        icon: <Plus className="w-4 h-4 stroke-[2.2]" />,
        onClick: () => onNavigate('new-airman-order'),
      }}
      fullWidth
    >
      {/* =========================================================================
          COMPACT SUMMARY BAND (Paper Tile + Graphite Object Card)
         ========================================================================= */}
      <div className="bg-white rounded-[20px] p-4 sm:p-5 border border-[#e0e0e0] grid grid-cols-1 md:grid-cols-2 gap-4 select-none">
        {/* Left Paper Tile: Year Selection & Batch Info */}
        <div className="p-4 rounded-[16px] bg-[#f5f5f7]">
          <span className="text-[13px] font-semibold text-[#6e6e73] block mb-1">
            Running Year & Batch
          </span>
          <div className="flex items-baseline gap-2 mb-2.5">
            <span className="text-[28px] sm:text-[32px] font-semibold text-[#1d1d1f] tracking-[-0.03em] num leading-tight">
              {yearOrders.length}
            </span>
            <span className="text-[13px] text-[#6e6e73]">
              uniforms in {selectedYear === 'All' ? 'all years' : `year ${selectedYear}`}
            </span>
          </div>

          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              onClick={() => setSelectedYear('All')}
              className={`h-7 px-2.5 rounded-full text-[12px] font-semibold cursor-pointer transition-all ${
                selectedYear === 'All'
                  ? 'bg-[#1d1d1f] text-white'
                  : 'bg-white border border-[#e0e0e0] text-[#1d1d1f] hover:bg-white/80'
              }`}
            >
              All Years
            </button>
            {(state.settings.runningYears || ['2026', '2025', '2024']).map((yr) => (
              <button
                key={yr}
                onClick={() => setSelectedYear(yr)}
                className={`h-7 px-2.5 rounded-full text-[12px] font-semibold cursor-pointer transition-all ${
                  selectedYear === yr
                    ? 'bg-[#1d1d1f] text-white'
                    : 'bg-white border border-[#e0e0e0] text-[#1d1d1f] hover:bg-white/80'
                }`}
              >
                {yr}
              </button>
            ))}
          </div>
        </div>

        {/* Right Graphite Object Tile: Pending Airman Uniforms */}
        <div className="object-card p-4 rounded-[16px]">
          <div className="relative z-10">
            <span className="text-[13px] font-semibold text-white/70 block mb-1">
              Active Production Queue
            </span>
            <div className="flex items-baseline gap-2 mb-2.5">
              <span className="text-[28px] sm:text-[32px] font-semibold text-white tracking-[-0.03em] num leading-tight">
                {pendingCount}
              </span>
              <span className="text-[13px] text-white/70">
                uniforms pending delivery
              </span>
            </div>
            <p className="text-[12px] text-white/60">
              Trade garments are tailored per batch authorization for BAF airmen.
            </p>
            <div className="mt-2.5 pt-1">
              <RulerTickStrip dark={false} className="h-3 opacity-30" />
            </div>
          </div>
        </div>
      </div>

      {/* =========================================================================
          CONTROL BAND (Filter Chips with counts, Search pill, Sort pill, View Toggle)
         ========================================================================= */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 select-none">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
          {(['All', 'Pending', 'Cutting Slip – Done', 'Delivered'] as const).map((tab) => {
            const isSelected = activeTab === tab;
            return (
              <button
                key={tab}
                aria-pressed={isSelected}
                onClick={() => setActiveTab(tab)}
                className={`h-[40px] px-4 rounded-full text-[14px] font-semibold tracking-[-0.224px] flex items-center gap-2 transition-all whitespace-nowrap cursor-pointer ${
                  isSelected
                    ? 'bg-white border-2 border-[#0071e3] text-[#1d1d1f]'
                    : 'bg-white border border-[#e0e0e0] text-[#1d1d1f] hover:bg-[#fafafc]'
                }`}
              >
                <span>{tab}</span>
                <span className="text-[13px] font-normal text-[#6e6e73] num">
                  {tabCounts[tab]}
                </span>
              </button>
            );
          })}
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* View Switcher Toggle */}
          <div className="flex items-center bg-white border border-[#e0e0e0] rounded-full p-0.5 shadow-2xs shrink-0">
            <button
              type="button"
              onClick={() => setViewMode('grid')}
              className={`h-[34px] px-3 rounded-full flex items-center gap-1.5 text-[12px] font-bold transition-all cursor-pointer ${
                viewMode === 'grid'
                  ? 'bg-[#1d1d1f] text-white shadow-xs'
                  : 'text-[#6e6e73] hover:text-[#1d1d1f]'
              }`}
              title="Multi-card grid view"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>Cards</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('table')}
              className={`h-[34px] px-3 rounded-full flex items-center gap-1.5 text-[12px] font-bold transition-all cursor-pointer ${
                viewMode === 'table'
                  ? 'bg-[#1d1d1f] text-white shadow-xs'
                  : 'text-[#6e6e73] hover:text-[#1d1d1f]'
              }`}
              title="Table view"
            >
              <List className="w-3.5 h-3.5" />
              <span>Table</span>
            </button>
          </div>

          <div className="relative min-w-[200px] sm:min-w-[240px]">
            <Search className="w-4 h-4 text-[#6e6e73] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search airman, BD, IV..."
              className="w-full h-[38px] pl-10 pr-8 rounded-full bg-white border border-[#e0e0e0] text-[13px] text-[#1d1d1f] placeholder-[#7a7a7a] outline-none focus:border-[#0071e3] focus:ring-1 focus:ring-[#0071e3] transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6e6e73] hover:text-[#1d1d1f]"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <button
            onClick={() => setSortOrder(sortOrder === 'newest' ? 'oldest' : 'newest')}
            className="h-[38px] px-3.5 rounded-full bg-white border border-[#e0e0e0] text-[13px] font-semibold text-[#1d1d1f] flex items-center gap-1.5 hover:bg-[#fafafc] cursor-pointer whitespace-nowrap shadow-2xs"
          >
            <span className="text-[#6e6e73] font-normal">Sort:</span>
            <span>{sortOrder === 'newest' ? 'Newest' : 'Oldest'}</span>
            <ArrowUpDown className="w-3.5 h-3.5 text-[#6e6e73]" />
          </button>
        </div>
      </div>

      {/* =========================================================================
          WORK BAND (Cards Grid View or Table View)
         ========================================================================= */}
      {filteredOrders.length === 0 ? (
        <div className="bg-[#f5f5f7] rounded-[24px] p-12 text-center border border-[#e0e0e0] flex flex-col items-center justify-center">
          <EmptyStateCardsIllustration size={160} />
          <h3 className="text-[22px] font-semibold text-[#1d1d1f] mt-4">
            No airman orders found
          </h3>
          <p className="text-[15px] text-[#6e6e73] mt-1.5 max-w-sm">
            {searchQuery
              ? 'Try resetting your search query.'
              : 'Tap New order to log an Airman trade batch uniform.'}
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setActiveTab('All');
            }}
            className="btn btn-primary mt-6"
          >
            Reset filter
          </button>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <span className="text-[13px] text-[#6e6e73]">
              Showing {filteredOrders.length} of {yearOrders.length} Airman orders
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredOrders.map((order) => {
              const ivStr = order.items.map((it) => it.ivNumber).filter(Boolean).join(', ') || 'Not set';
              const itemsStr = order.items.map((it) => it.name).join(', ') || 'No garments';

              return (
                <div
                  key={order.id}
                  onClick={() =>
                    onNavigate('order-details', {
                      orderNumber: order.orderNumber,
                      category: 'Airman',
                    })
                  }
                  className="bg-white rounded-[20px] p-5 border border-[#e0e0e0] shadow-2xs hover:border-[#1d1d1f] hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group"
                >
                  <div>
                    {/* Top Line */}
                    <div className="flex items-start gap-3 mb-3">
                      <div className="entity-chip shrink-0 w-10 h-10 rounded-[10px] bg-[#1d1d1f] text-white font-bold text-[13px] flex items-center justify-center shadow-xs">
                        #{order.orderNumber}
                      </div>
                      <div className="min-w-0 flex-1">
                        <h3 className="text-[16px] font-bold text-[#1d1d1f] leading-snug truncate group-hover:text-[#0066cc] transition-colors">
                          {order.customerName}
                        </h3>
                        <p className="text-[13px] text-[#6e6e73] leading-tight truncate">
                          Airman · {order.customerBdNumber}
                        </p>
                      </div>
                      <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-[#f5f5f7] text-[#1d1d1f] border border-[#e0e0e0]">
                        {order.runningYear}
                      </span>
                    </div>

                    {/* Status Badge Dropdown */}
                    <div className="mb-3.5">
                      <StatusBadge
                        status={order.status}
                        variant="card-pill"
                        interactive={true}
                        onChange={(newStatus) => updateAirmanOrderStatus(order.orderNumber, newStatus)}
                      />
                    </div>

                    {/* IV Number & Garments */}
                    <div className="space-y-2 text-[12px] p-3 rounded-[12px] bg-[#f5f5f7] mb-3">
                      <div className="flex justify-between">
                        <span className="text-[#6e6e73]">IV Number:</span>
                        <span className="font-semibold text-[#1d1d1f] num">{ivStr}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#6e6e73]">Garments:</span>
                        <span className="font-semibold text-[#1d1d1f] truncate max-w-[170px]">{itemsStr}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-[#f0f0f0] flex items-center justify-between text-[12px]">
                    <span className="text-[#6e6e73]">{order.orderDate}</span>
                    <span className="text-[#0066cc] font-semibold group-hover:underline">View Cutting Slip ›</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Table Panel (8 Columns) */}
          <div className="lg:col-span-8 bg-white rounded-[24px] border border-[#e0e0e0] p-6 overflow-hidden">
            <div className="flex items-center justify-between pb-4 mb-3 border-b border-[#f0f0f0]">
              <h2 className="text-[22px] font-semibold text-[#1d1d1f] tracking-[-0.02em]">
                Airman Uniform Orders
              </h2>
              <span className="text-[13px] text-[#6e6e73]">
                Showing {filteredOrders.length} of {yearOrders.length}
              </span>
            </div>

            <div className="overflow-x-auto no-scrollbar">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="h-10 bg-[#f5f5f7] rounded-[12px] text-[12px] font-semibold text-[#6e6e73] select-none">
                    <th className="px-3.5 rounded-l-[12px]">Order & Airman</th>
                    <th className="px-3">IV Number</th>
                    <th className="px-3">Status</th>
                    <th className="px-3">Garments</th>
                    <th className="px-3.5 text-right rounded-r-[12px]">Year</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#f0f0f0]">
                  {filteredOrders.map((order) => {
                    const isSelected = currentSelectedOrder?.orderNumber === order.orderNumber;
                    return (
                      <tr
                        key={order.id}
                        onClick={() => setSelectedOrderNumber(order.orderNumber)}
                        className={`h-[68px] cursor-pointer transition-colors ${
                          isSelected ? 'bg-[#f0f0f0]' : 'hover:bg-[#fafafc]'
                        }`}
                      >
                        <td className="px-3.5 py-2">
                          <div className="flex items-center gap-3">
                            <div className="entity-chip">
                              #{order.orderNumber}
                            </div>
                            <div className="min-w-0">
                              <div className="text-[15px] font-semibold text-[#1d1d1f] truncate">
                                {order.customerName}
                              </div>
                              <div className="text-[13px] text-[#6e6e73]">
                                Airman · {order.customerBdNumber}
                              </div>
                            </div>
                          </div>
                        </td>

                        <td className="px-3 py-2 text-[14px] text-[#1d1d1f] font-normal num">
                          {order.items.map((it) => it.ivNumber).filter(Boolean).join(', ') || 'Not set'}
                        </td>

                        <td className="px-3 py-2">
                          <StatusBadge
                            status={order.status}
                            interactive={true}
                            onChange={(newStatus) =>
                              updateAirmanOrderStatus(order.orderNumber, newStatus)
                            }
                          />
                        </td>

                        <td className="px-3 py-2 text-[13px] text-[#6e6e73]">
                          {order.items.map((it) => it.name).join(', ') || 'No items'}
                        </td>

                        <td className="px-3.5 py-2 text-right text-[14px] font-semibold text-[#1d1d1f] num">
                          {order.runningYear}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Sticky Aside Panel (4 Columns) */}
          <div className="lg:col-span-4 sticky top-6">
            {currentSelectedOrder ? (
              <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-6">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="entity-chip w-11 h-11 text-[13px]">
                      #{currentSelectedOrder.orderNumber}
                    </div>
                    <div className="min-w-0">
                      <h3 className="text-[20px] font-semibold text-[#1d1d1f] leading-snug truncate">
                        {currentSelectedOrder.customerName}
                      </h3>
                      <p className="text-[13px] text-[#6e6e73]">
                        Airman · {currentSelectedOrder.customerBdNumber}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Status Segment Bar */}
                <div className="space-y-1.5 select-none">
                  <div className="grid grid-cols-3 gap-1.5">
                    <div className="h-1 rounded-full bg-[#1d1d1f]" />
                    <div
                      className={`h-1 rounded-full ${
                        currentSelectedOrder.status === 'Cutting Slip – Done' ||
                        currentSelectedOrder.status === 'Delivered'
                          ? 'bg-[#1d1d1f]'
                          : 'bg-[#e0e0e0]'
                      }`}
                    />
                    <div
                      className={`h-1 rounded-full ${
                        currentSelectedOrder.status === 'Delivered'
                          ? 'bg-[#1d1d1f]'
                          : 'bg-[#e0e0e0]'
                      }`}
                    />
                  </div>
                  <div className="flex justify-between text-[11px] text-[#6e6e73] font-semibold">
                    <span>Order Placed</span>
                    <span>Cutting Done</span>
                    <span>Delivered</span>
                  </div>
                </div>

                {/* Info Tray */}
                <div className="p-4 bg-[#f5f5f7] rounded-[18px] space-y-2.5">
                  <div className="flex justify-between text-[13px]">
                    <span className="text-[#6e6e73]">Running Year:</span>
                    <span className="font-semibold text-[#1d1d1f] num">{currentSelectedOrder.runningYear}</span>
                  </div>
                  <div className="flex justify-between text-[13px]">
                    <span className="text-[#6e6e73]">IV Number:</span>
                    <span className="font-semibold text-[#1d1d1f] num">
                      {currentSelectedOrder.items.map((it) => it.ivNumber).filter(Boolean).join(', ') || 'Not set'}
                    </span>
                  </div>
                  <div className="flex justify-between text-[13px]">
                    <span className="text-[#6e6e73]">Order Date:</span>
                    <span className="font-semibold text-[#1d1d1f] num">{currentSelectedOrder.orderDate || 'Not set'}</span>
                  </div>
                  <div className="flex justify-between text-[13px]">
                    <span className="text-[#6e6e73]">Delivered Date:</span>
                    <span className="font-semibold text-[#1d1d1f] num">{currentSelectedOrder.deliveredDate || 'In Progress'}</span>
                  </div>
                </div>

                {/* Items in batch */}
                <div className="space-y-2">
                  <span className="text-[12px] font-semibold text-[#6e6e73] uppercase tracking-wider block">
                    Garments in Batch
                  </span>
                  <div className="space-y-1.5">
                    {currentSelectedOrder.items.map((it, idx) => (
                      <div
                        key={idx}
                        className="p-3 bg-[#f5f5f7] rounded-[14px] flex items-center justify-between text-[13px]"
                      >
                        <span className="font-semibold text-[#1d1d1f]">{it.name}</span>
                        <span className="text-[#6e6e73] num">Qty: {it.quantity}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="space-y-2.5">
                  <button
                    onClick={() =>
                      onNavigate('print-slip', {
                        orderNumber: currentSelectedOrder.orderNumber,
                        category: 'Airman',
                      })
                    }
                    className="w-full h-[44px] rounded-full bg-[#0066cc] hover:bg-[#0071e3] text-white text-[15px] font-semibold flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 shadow-xs"
                  >
                    <Scissors className="w-4 h-4" />
                    <span>Print Cutting Slip</span>
                  </button>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() =>
                        onNavigate('edit-airman-order', {
                          orderNumber: currentSelectedOrder.orderNumber,
                        })
                      }
                      className="h-9 rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#1d1d1f] text-[13px] font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                    >
                      <Edit2 className="w-3.5 h-3.5 text-[#6e6e73]" />
                      <span>Edit</span>
                    </button>

                    <button
                      onClick={() => handleDeleteStepOne(currentSelectedOrder)}
                      className="h-9 rounded-full bg-[#fceaea] hover:bg-[#fbdcdc] text-[#c62828] text-[13px] font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-8 text-center text-[#6e6e73]">
                Select an airman order to view details.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Two-step delete dialog */}
      <AnimatePresence>
        {deleteTargetOrder && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="fixed inset-0 bg-black/35 backdrop-blur-xs"
              onClick={() => setDeleteTargetOrder(null)}
              aria-hidden="true"
            />
            <div className="relative z-10 w-full max-w-[420px] bg-white rounded-[28px] p-6 border border-[#e0e0e0] shadow-2xl">
              <div className="flex items-center justify-between mb-4">
                <div className="w-10 h-10 rounded-full bg-[#fceaea] text-[#c62828] flex items-center justify-center">
                  <Trash2 className="w-5 h-5" />
                </div>
                <div className="flex items-center gap-1.5 text-[12px] font-semibold text-[#6e6e73]">
                  <span>Step {deleteStep} of 2</span>
                  <div className="flex items-center gap-1 ml-1">
                    <span className="w-5 h-1.5 rounded-full bg-[#1d1d1f]" />
                    <span
                      className={`w-5 h-1.5 rounded-full transition-colors ${
                        deleteStep === 2 ? 'bg-[#c62828]' : 'bg-[#e0e0e0]'
                      }`}
                    />
                  </div>
                </div>
              </div>

              <h3 className="text-[22px] font-semibold text-[#1d1d1f] leading-snug">
                {deleteStep === 1
                  ? `Delete airman order #${deleteTargetOrder.orderNumber}?`
                  : 'This cannot be undone. Delete permanently?'}
              </h3>
              <p className="text-[15px] text-[#6e6e73] mt-2 leading-relaxed">
                {deleteStep === 1
                  ? `Check the airman order for ${deleteTargetOrder.customerName} before you go on.`
                  : 'Later Airman orders will adjust accordingly.'}
              </p>

              <div className="grid grid-cols-2 gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setDeleteTargetOrder(null)}
                  className="h-[44px] rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#1d1d1f] font-semibold text-[15px]"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleDeleteConfirm}
                  className={`h-[44px] rounded-full font-semibold text-[15px] text-white active:scale-95 ${
                    deleteStep === 1
                      ? 'bg-[#0066cc] hover:bg-[#0071e3]'
                      : 'bg-[#c62828] hover:bg-[#b02222]'
                  }`}
                >
                  {deleteStep === 1 ? 'Continue' : 'Delete'}
                </button>
              </div>
            </div>
          </div>
        )}
      </AnimatePresence>
    </PolarisPage>
  );
};
