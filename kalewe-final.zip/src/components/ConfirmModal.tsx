import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Trash2, AlertCircle, CheckCircle2, ShieldAlert } from 'lucide-react';

interface ConfirmModalProps {
  isOpen: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  confirmVariant?: 'danger' | 'primary' | 'success';
  twoStep?: boolean;
  stepTwoTitle?: string;
  stepTwoMessage?: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmModal: React.FC<ConfirmModalProps> = ({
  isOpen,
  title,
  message,
  confirmLabel = 'Continue',
  cancelLabel = 'Cancel',
  confirmVariant = 'primary',
  twoStep = false,
  stepTwoTitle = 'This cannot be undone. Delete permanently?',
  stepTwoMessage = 'Later orders will be affected. Please confirm you want to proceed.',
  onConfirm,
  onCancel,
}) => {
  const [currentStep, setCurrentStep] = useState<1 | 2>(1);

  useEffect(() => {
    if (isOpen) {
      setCurrentStep(1);
    }
  }, [isOpen]);

  const handlePrimaryClick = () => {
    if (twoStep && currentStep === 1) {
      setCurrentStep(2);
    } else {
      onConfirm();
    }
  };

  const isDestructive = confirmVariant === 'danger';
  const displayTitle = twoStep && currentStep === 2 ? stepTwoTitle : title;
  const displayMessage = twoStep && currentStep === 2 ? stepTwoMessage : message;

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Dim to focus: scrim background */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onCancel}
            className="fixed inset-0 bg-black/35 backdrop-blur-xs"
            aria-hidden="true"
          />

          {/* Darzi Modal Panel: 400-440px wide, radius 28px, white canvas on desktop */}
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.94, y: 10 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className="relative z-10 w-full max-w-[420px] bg-white rounded-[28px] p-6 border border-[#e0e0e0] shadow-[0_8px_32px_rgba(0,0,0,0.12)] select-none"
            role="dialog"
            aria-modal="true"
          >
            {/* Header row: Icon circle left, Step indicator right */}
            <div className="flex items-center justify-between mb-4">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                  isDestructive
                    ? 'bg-[#fceaea] text-[#c62828]'
                    : confirmVariant === 'success'
                    ? 'bg-[#e3f4e8] text-[#1e7b43]'
                    : 'bg-[#f5f5f7] text-[#1d1d1f]'
                }`}
              >
                {isDestructive ? (
                  <Trash2 className="w-5 h-5" />
                ) : confirmVariant === 'success' ? (
                  <CheckCircle2 className="w-5 h-5" />
                ) : (
                  <AlertCircle className="w-5 h-5" />
                )}
              </div>

              {twoStep && (
                <div className="flex items-center gap-1.5 text-[12px] font-semibold text-[#6e6e73]">
                  <span>Step {currentStep} of 2</span>
                  <div className="flex items-center gap-1 ml-1">
                    <span className="w-5 h-1.5 rounded-full bg-[#1d1d1f]" />
                    <span
                      className={`w-5 h-1.5 rounded-full transition-colors ${
                        currentStep === 2 ? 'bg-[#c62828]' : 'bg-[#e0e0e0]'
                      }`}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Title & One Sentence Description */}
            <h3 className="text-[22px] font-semibold text-[#1d1d1f] leading-snug tracking-[-0.02em]">
              {displayTitle}
            </h3>
            <p className="text-[15px] font-normal text-[#6e6e73] mt-2 leading-relaxed">
              {displayMessage}
            </p>

            {/* Two equal-width 44px buttons side by side */}
            <div className="grid grid-cols-2 gap-3 mt-6 pt-2">
              <button
                type="button"
                onClick={onCancel}
                className="h-[44px] rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[15px] font-semibold text-[#1d1d1f] flex items-center justify-center transition-all cursor-pointer active:scale-95"
              >
                {cancelLabel}
              </button>

              <button
                type="button"
                onClick={handlePrimaryClick}
                className={`h-[44px] rounded-full text-[15px] font-semibold text-white flex items-center justify-center transition-all cursor-pointer active:scale-95 ${
                  isDestructive
                    ? currentStep === 2
                      ? 'bg-[#c62828] hover:bg-[#b02222]'
                      : 'bg-[#0066cc] hover:bg-[#0071e3]'
                    : confirmVariant === 'success'
                    ? 'bg-[#1e7b43] hover:bg-[#186637]'
                    : 'bg-[#0066cc] hover:bg-[#0071e3]'
                }`}
              >
                {twoStep && currentStep === 1 ? 'Continue' : confirmLabel}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
