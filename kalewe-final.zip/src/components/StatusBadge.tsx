import React from 'react';
import { OrderStatus } from '../types/index.ts';
import { ChevronDown } from 'lucide-react';

interface StatusBadgeProps {
  status: OrderStatus;
  onChange?: (newStatus: OrderStatus) => void;
  interactive?: boolean;
  className?: string;
  variant?: 'dot-text' | 'chip' | 'card-pill';
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({
  status,
  onChange,
  interactive = false,
  className = '',
  variant = 'dot-text',
}) => {
  const getDotColor = (st: OrderStatus) => {
    switch (st) {
      case 'Pending':
        return '#f2a93b'; // caution-dot (amber)
      case 'Cutting Slip – Done':
        return '#7a4fd2'; // stage-dot (purple)
      case 'Delivered':
        return '#2e9e54'; // positive-dot (green)
      default:
        return '#6e6e73';
    }
  };

  const getChipStyle = (st: OrderStatus) => {
    switch (st) {
      case 'Pending':
        return 'bg-[#fdeee7] text-[#c2410c] border border-[#fdeee7]';
      case 'Cutting Slip – Done':
        return 'bg-[#f5f5f7] text-[#1d1d1f] border border-[#e0e0e0]';
      case 'Delivered':
        return 'bg-[#e3f4e8] text-[#1e7b43] border border-[#e3f4e8]';
      default:
        return 'bg-[#f5f5f7] text-[#6e6e73] border border-[#e0e0e0]';
    }
  };

  if (variant === 'chip') {
    return (
      <span
        className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[12px] font-semibold tracking-tight ${getChipStyle(
          status
        )} ${className}`}
      >
        <span
          className="w-2 h-2 rounded-full shrink-0"
          style={{ backgroundColor: getDotColor(status) }}
        />
        {status}
      </span>
    );
  }

  if (variant === 'card-pill') {
    if (!interactive || !onChange) {
      return (
        <span
          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white border border-[#e0e0e0] text-[12px] font-semibold text-[#1d1d1f] shadow-2xs ${className}`}
        >
          <span
            className="w-2 h-2 rounded-full shrink-0"
            style={{ backgroundColor: getDotColor(status) }}
          />
          <span>{status}</span>
        </span>
      );
    }

    return (
      <div className={`relative inline-flex items-center bg-white hover:bg-[#fafafc] border border-[#e0e0e0] hover:border-[#1d1d1f] rounded-full px-2.5 py-1 transition-all shadow-2xs group ${className}`}>
        <span
          className="w-2 h-2 rounded-full shrink-0 mr-1.5"
          style={{ backgroundColor: getDotColor(status) }}
        />
        <select
          value={status}
          onChange={(e) => {
            e.stopPropagation();
            onChange(e.target.value as OrderStatus);
          }}
          onClick={(e) => e.stopPropagation()}
          aria-label="Order status"
          className="appearance-none bg-transparent pr-4 text-[12px] font-semibold text-[#1d1d1f] cursor-pointer outline-none border-0"
        >
          <option value="Pending">Pending</option>
          <option value="Cutting Slip – Done">Cutting Slip – Done</option>
          <option value="Delivered">Delivered</option>
        </select>
        <ChevronDown className="w-3.5 h-3.5 text-[#6e6e73] absolute right-2 pointer-events-none group-hover:text-[#1d1d1f]" />
      </div>
    );
  }

  // Exact Dot + Word requirement from Graphite and Parchment spec (no filled background inside tables)
  if (!interactive || !onChange) {
    return (
      <span className={`inline-flex items-center gap-2 text-[13px] font-semibold text-[#1d1d1f] ${className}`}>
        <span
          className="w-2 h-2 rounded-full shrink-0"
          style={{ backgroundColor: getDotColor(status) }}
        />
        <span>{status}</span>
      </span>
    );
  }

  return (
    <div className={`relative inline-flex items-center group cursor-pointer ${className}`}>
      <span
        className="w-2 h-2 rounded-full shrink-0 mr-2"
        style={{ backgroundColor: getDotColor(status) }}
      />
      <select
        value={status}
        onChange={(e) => {
          e.stopPropagation();
          onChange(e.target.value as OrderStatus);
        }}
        onClick={(e) => e.stopPropagation()}
        aria-label="Order status"
        className="appearance-none bg-transparent pr-4 py-0.5 text-[13px] font-semibold text-[#1d1d1f] hover:text-[#0066cc] cursor-pointer outline-none border-0 focus:ring-1 focus:ring-[#0071e3] rounded"
      >
        <option value="Pending">Pending</option>
        <option value="Cutting Slip – Done">Cutting Slip – Done</option>
        <option value="Delivered">Delivered</option>
      </select>
      <ChevronDown className="w-3 h-3 text-[#6e6e73] absolute right-0 pointer-events-none group-hover:text-[#0066cc]" />
    </div>
  );
};
