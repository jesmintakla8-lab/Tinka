import React from 'react';
import { Folder as FolderIcon, ChevronRight } from 'lucide-react';

interface FolderProps {
  title: string;
  subtitle?: string;
  count?: number | string;
  icon?: React.ReactNode;
  colorScheme?: 'lavender' | 'mint' | 'powder' | 'peach' | 'solar' | 'bone';
  children?: React.ReactNode;
  onClick?: () => void;
  actionText?: string;
  className?: string;
}

const COLOR_MAP = {
  lavender: {
    tabBg: 'bg-[#f1e6ff]',
    tabBorder: 'border-[#e4ccff]',
    tabText: 'text-[#6b21a8]',
    bodyBg: 'bg-[#faf5ff]',
    accentDot: 'bg-[#9333ea]',
    paperBg: 'bg-[#f3e8ff]',
    badgeBg: 'bg-[#e4ccff] text-[#581c87]',
  },
  mint: {
    tabBg: 'bg-[#d3f6e3]',
    tabBorder: 'border-[#a7f3d0]',
    tabText: 'text-[#065f46]',
    bodyBg: 'bg-[#f0fdf4]',
    accentDot: 'bg-[#10b981]',
    paperBg: 'bg-[#dcfce7]',
    badgeBg: 'bg-[#bbf7d0] text-[#064e3b]',
  },
  powder: {
    tabBg: 'bg-[#cce7ff]',
    tabBorder: 'border-[#bfdbfe]',
    tabText: 'text-[#1e40af]',
    bodyBg: 'bg-[#f0f7ff]',
    accentDot: 'bg-[#0069e0]',
    paperBg: 'bg-[#e0f2fe]',
    badgeBg: 'bg-[#bfdbfe] text-[#1e3a8a]',
  },
  peach: {
    tabBg: 'bg-[#ffd1b8]',
    tabBorder: 'border-[#fed7aa]',
    tabText: 'text-[#9a3412]',
    bodyBg: 'bg-[#fff7ed]',
    accentDot: 'bg-[#f97316]',
    paperBg: 'bg-[#ffedd5]',
    badgeBg: 'bg-[#fed7aa] text-[#7c2d12]',
  },
  solar: {
    tabBg: 'bg-[#fff2be]',
    tabBorder: 'border-[#fef08a]',
    tabText: 'text-[#854d0e]',
    bodyBg: 'bg-[#fefce8]',
    accentDot: 'bg-[#eab308]',
    paperBg: 'bg-[#fef9c3]',
    badgeBg: 'bg-[#fef08a] text-[#713f12]',
  },
  bone: {
    tabBg: 'bg-[#ffffff]',
    tabBorder: 'border-[#e2edfa]',
    tabText: 'text-[#0a0d12]',
    bodyBg: 'bg-[#fafdff]',
    accentDot: 'bg-[#0069e0]',
    paperBg: 'bg-[#ebf5ff]',
    badgeBg: 'bg-[#ebf5ff] text-[#0069e0]',
  },
};

export const Folder: React.FC<FolderProps> = ({
  title,
  subtitle,
  count,
  icon = <FolderIcon className="w-4 h-4" />,
  colorScheme = 'bone',
  children,
  onClick,
  actionText = 'Open Folder',
  className = '',
}) => {
  const c = COLOR_MAP[colorScheme];

  return (
    <div
      onClick={onClick}
      className={`relative pt-3 group transition-all duration-300 ${
        onClick ? 'cursor-pointer' : ''
      } ${className}`}
    >
      {/* 3D Tactile Paper Slips peaking behind the folder */}
      <div
        className={`absolute top-0 right-8 left-12 h-5 rounded-t-xl opacity-60 transition-transform duration-300 group-hover:-translate-y-1 ${c.paperBg} border-t border-x border-white/60 shadow-xs`}
      />
      <div
        className={`absolute top-1.5 right-6 left-8 h-4 rounded-t-xl opacity-85 transition-transform duration-300 group-hover:-translate-y-0.5 bg-white border-t border-x border-black/5 shadow-xs`}
      />

      {/* Protruding Folder Tab */}
      <div className="relative z-10 flex items-center">
        <div
          className={`inline-flex items-center gap-2 px-5 py-2 rounded-t-[18px] border-t border-x ${c.tabBg} ${c.tabBorder} ${c.tabText} shadow-xs font-medium text-xs tracking-tight select-none`}
        >
          <span className="shrink-0">{icon}</span>
          <span className="font-semibold text-xs tracking-tight">{title}</span>
          {count !== undefined && (
            <span
              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${c.badgeBg}`}
            >
              {count}
            </span>
          )}
        </div>
      </div>

      {/* Main Folder Body Card (32px radius per Geniestudio tokens) */}
      <div
        className={`relative z-10 ${c.bodyBg} border border-white rounded-b-[32px] rounded-tr-[32px] p-5 sm:p-6 shadow-[0_8px_24px_rgba(4,69,144,0.05)] transition-all duration-300 group-hover:shadow-[0_14px_30px_rgba(4,69,144,0.09)] group-hover:translate-y-[-1px]`}
      >
        <div className="flex items-start justify-between gap-3 mb-3">
          <div>
            <h3 className="text-base font-semibold text-[#0a0d12] tracking-tight">
              {title}
            </h3>
            {subtitle && (
              <p className="text-xs text-[#535862] mt-0.5">{subtitle}</p>
            )}
          </div>

          {actionText && (
            <button
              type="button"
              className="inline-flex items-center gap-1 text-xs font-semibold text-[#0069e0] hover:text-[#0052be] transition-colors group-hover:translate-x-0.5"
            >
              <span>{actionText}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Content Inside Folder */}
        {children && <div className="mt-4">{children}</div>}
      </div>
    </div>
  );
};
