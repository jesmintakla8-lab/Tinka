import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { ScreenName } from '../Navbar.tsx';
import {
  Search,
  X,
  ClipboardList,
  Plane,
  Users,
  UserCheck,
  ArrowRight,
} from 'lucide-react';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  onNavigate,
}) => {
  const { state } = useApp();
  const [query, setQuery] = useState('');
  const [activeChip, setActiveChip] = useState<'All' | 'Orders' | 'Customers' | 'Staff'>('All');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
      setActiveChip('All');
    }
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
      } else if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const searchResults = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];

    const results: {
      id: string;
      title: string;
      subtitle: string;
      tag: string;
      icon: any;
      screen: ScreenName;
      params?: any;
    }[] = [];

    // Search Officer Orders
    if (activeChip === 'All' || activeChip === 'Orders') {
      state.officerOrders.forEach((order) => {
        const orderNumStr = String(order.orderNumber);
        const nameMatch = (order.customerName || '').toLowerCase().includes(q);
        const bdMatch = (order.customerBdNumber || '').toLowerCase().includes(q);
        const numMatch = orderNumStr.includes(q);

        if (nameMatch || bdMatch || numMatch) {
          results.push({
            id: `officer-${order.orderNumber}`,
            title: `#${order.orderNumber} · ${order.customerName}`,
            subtitle: `Officer · ${order.customerBdNumber} · ${order.status} · Due ৳${order.due.toLocaleString()}`,
            tag: 'Officer',
            icon: ClipboardList,
            screen: 'order-details',
            params: { orderNumber: order.orderNumber, category: 'Officer' },
          });
        }
      });

      // Search Airman Orders
      state.airmanOrders.forEach((order) => {
        const orderNumStr = String(order.orderNumber);
        const nameMatch = (order.customerName || '').toLowerCase().includes(q);
        const bdMatch = (order.customerBdNumber || '').toLowerCase().includes(q);
        const numMatch = orderNumStr.includes(q);

        if (nameMatch || bdMatch || numMatch) {
          results.push({
            id: `airman-${order.orderNumber}`,
            title: `#${order.orderNumber} · ${order.customerName}`,
            subtitle: `Airman · ${order.customerBdNumber} · ${order.status}`,
            tag: 'Airman',
            icon: Plane,
            screen: 'airman-orders',
            params: { orderNumber: order.orderNumber },
          });
        }
      });
    }

    // Search Customers
    if (activeChip === 'All' || activeChip === 'Customers') {
      state.customers.forEach((cust) => {
        if (
          cust.name.toLowerCase().includes(q) ||
          cust.bdNumber.toLowerCase().includes(q) ||
          cust.phone.includes(q)
        ) {
          results.push({
            id: `cust-${cust.category}-${cust.bdNumber}`,
            title: `${cust.name} (${cust.bdNumber})`,
            subtitle: `${cust.category} · Phone: ${cust.phone || 'Not set'}`,
            tag: 'Customer',
            icon: Users,
            screen: 'customer-history',
            params: { bdNumber: cust.bdNumber, category: cust.category },
          });
        }
      });
    }

    // Search Staff Workers
    if (activeChip === 'All' || activeChip === 'Staff') {
      state.workers.forEach((w) => {
        if (w.name.toLowerCase().includes(q) || (w.banglaName && w.banglaName.includes(q))) {
          results.push({
            id: `worker-${w.id}`,
            title: `${w.name} ${w.banglaName ? `(${w.banglaName})` : ''}`,
            subtitle: `Master Craftsman · Status: ${w.active ? 'Active' : 'Inactive'}`,
            tag: 'Staff',
            icon: UserCheck,
            screen: 'worker-page',
            params: { workerId: w.id },
          });
        }
      });
    }

    return results.slice(0, 15);
  }, [query, activeChip, state]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-14 md:pt-20 p-4">
      <div
        className="fixed inset-0 bg-black/35 backdrop-blur-xs transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      <div
        className="relative z-10 w-full max-w-xl bg-white rounded-[24px] border border-[#e0e0e0] shadow-[0_8px_32px_rgba(0,0,0,0.12)] overflow-hidden flex flex-col max-h-[80vh]"
        role="dialog"
        aria-modal="true"
      >
        {/* Search Input Bar */}
        <div className="p-4 border-b border-[#f0f0f0] flex items-center gap-3 bg-white">
          <Search className="w-5 h-5 text-[#6e6e73] shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search orders, BD numbers, customers, staff..."
            className="flex-1 bg-transparent text-[16px] text-[#1d1d1f] placeholder-[#7a7a7a] outline-none font-normal"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-[#6e6e73] hover:text-[#1d1d1f] rounded-full hover:bg-[#f5f5f7]"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <kbd className="hidden sm:inline-block px-2 py-0.5 rounded-full bg-[#f5f5f7] border border-[#e0e0e0] text-[#6e6e73] text-[11px] font-semibold">
            ESC
          </kbd>
        </div>

        {/* Filter Chips Bar */}
        <div className="px-4 py-2 border-b border-[#f0f0f0] flex items-center gap-2 bg-[#f5f5f7] overflow-x-auto no-scrollbar">
          {(['All', 'Orders', 'Customers', 'Staff'] as const).map((chip) => {
            const active = activeChip === chip;
            return (
              <button
                key={chip}
                onClick={() => setActiveChip(chip)}
                className={`h-8 px-3 rounded-full text-[13px] font-semibold transition-all cursor-pointer whitespace-nowrap ${
                  active
                    ? 'bg-white border-2 border-[#0071e3] text-[#1d1d1f]'
                    : 'bg-white border border-[#e0e0e0] text-[#6e6e73] hover:text-[#1d1d1f]'
                }`}
              >
                {chip}
              </button>
            );
          })}
        </div>

        {/* Results List */}
        <div className="flex-1 overflow-y-auto divide-y divide-[#f0f0f0] p-2">
          {query.trim() === '' ? (
            <div className="p-8 text-center text-[#6e6e73]">
              <Search className="w-8 h-8 text-[#e0e0e0] mx-auto mb-2" />
              <p className="text-[14px]">Type order number, BD number, customer name, or worker.</p>
            </div>
          ) : searchResults.length === 0 ? (
            <div className="p-8 text-center text-[#6e6e73]">
              <p className="text-[15px] font-semibold text-[#1d1d1f]">No matching records found</p>
              <p className="text-[13px] mt-1">Try another search term or change the filter chip.</p>
            </div>
          ) : (
            searchResults.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onNavigate(item.screen, item.params);
                    onClose();
                  }}
                  className="w-full p-3 rounded-[14px] flex items-center justify-between text-left hover:bg-[#f0f0f0] transition-colors group cursor-pointer"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-9 h-9 rounded-[10px] bg-[#1d1d1f] text-white flex items-center justify-center shrink-0">
                      <Icon className="w-4 h-4 text-white" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-[14px] font-semibold text-[#1d1d1f] truncate">
                        {item.title}
                      </div>
                      <div className="text-[12px] text-[#6e6e73] truncate">
                        {item.subtitle}
                      </div>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-[#6e6e73] group-hover:text-[#0066cc] group-hover:translate-x-0.5 transition-all shrink-0 ml-2" />
                </button>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
