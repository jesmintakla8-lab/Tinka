import React from 'react';
import { ChevronLeft } from 'lucide-react';

export interface ActionItem {
  label?: string;
  content?: string;
  onClick?: () => void;
  onAction?: () => void;
  icon?: React.ReactNode;
  disabled?: boolean;
}

export interface PolarisPageProps {
  title: string;
  subtitle?: string;
  badge?: React.ReactNode;
  backAction?: () => void;
  primaryAction?: ActionItem;
  secondaryActions?: ActionItem[];
  children: React.ReactNode;
  fullWidth?: boolean;
}

export const PolarisPage: React.FC<PolarisPageProps> = ({
  title,
  subtitle,
  badge,
  backAction,
  primaryAction,
  secondaryActions = [],
  children,
  fullWidth = false,
}) => {
  return (
    <div className="min-h-full text-[#1d1d1f] pb-16">
      {/* Max Width Container (1440px per Darzi spec) */}
      <div className={`mx-auto space-y-6 ${fullWidth ? 'max-w-[1440px]' : 'max-w-[1360px]'}`}>
        {/* Back Link if nested */}
        {backAction && (
          <div className="pt-1">
            <button
              onClick={backAction}
              className="inline-flex items-center gap-1 text-[15px] font-semibold text-[#0066cc] hover:text-[#0071e3] cursor-pointer transition-colors"
            >
              <ChevronLeft className="w-4 h-4 stroke-[2.2]" />
              <span>Back</span>
            </button>
          </div>
        )}

        {/* Page Header Band */}
        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 pt-1">
          {/* Left: Title + Subtitle */}
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-3">
              <h1 className="text-[32px] md:text-[36px] font-semibold text-[#1d1d1f] tracking-[-0.03em] leading-[1.1]">
                {title}
              </h1>
              {badge && <div className="shrink-0">{badge}</div>}
            </div>
            {subtitle && (
              <p className="text-[15px] md:text-[17px] text-[#6e6e73] font-normal leading-[1.47] mt-1.5 max-w-3xl">
                {subtitle}
              </p>
            )}
          </div>

          {/* Right: Actions Group (Ghost first, Primary last) */}
          {(primaryAction || secondaryActions.length > 0) && (
            <div className="flex items-center gap-2.5 shrink-0 flex-wrap">
              {secondaryActions.map((sec, idx) => {
                const clickFn = sec.onClick || sec.onAction;
                const labelText = sec.label || sec.content;
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={clickFn}
                    disabled={sec.disabled}
                    className="h-[44px] px-5 rounded-full border border-[#0066cc] text-[#0066cc] hover:bg-[#0066cc]/10 text-[15px] font-semibold flex items-center gap-2 transition-all cursor-pointer active:scale-95 disabled:opacity-50"
                  >
                    {sec.icon && <span className="w-4 h-4">{sec.icon}</span>}
                    <span>{labelText}</span>
                  </button>
                );
              })}

              {primaryAction && (
                <button
                  type="button"
                  onClick={primaryAction.onClick || primaryAction.onAction}
                  disabled={primaryAction.disabled}
                  className="h-[44px] px-6 rounded-full bg-[#0066cc] hover:bg-[#0071e3] text-white text-[15px] font-semibold flex items-center gap-2 transition-all cursor-pointer active:scale-95 disabled:opacity-50 shadow-xs"
                >
                  {primaryAction.icon && <span className="w-4 h-4">{primaryAction.icon}</span>}
                  <span>{primaryAction.label || primaryAction.content}</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Work / Content Body */}
        <div className="space-y-6">{children}</div>
      </div>
    </div>
  );
};
