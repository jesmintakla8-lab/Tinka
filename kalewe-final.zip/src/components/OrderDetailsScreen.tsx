import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { StatusBadge } from './StatusBadge.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { TailorTagIllustration } from './Illustrations.tsx';
import {
  Scissors,
  Printer,
  Edit2,
  Trash2,
  CreditCard,
  CheckCircle2,
  Calendar,
  Phone,
  User,
  Shield,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';
import { AnimatePresence } from 'motion/react';

interface OrderDetailsScreenProps {
  orderNumber: number;
  category: 'Officer' | 'Airman';
  onNavigate: (screen: ScreenName, params?: any) => void;
  fromDelivery?: boolean;
}

export const OrderDetailsScreen: React.FC<OrderDetailsScreenProps> = ({
  orderNumber,
  category,
  onNavigate,
  fromDelivery = false,
}) => {
  const {
    state,
    updateOfficerOrderStatus,
    updateAirmanOrderStatus,
    deleteOfficerOrder,
    deleteAirmanOrder,
    recordOfficerPayment,
  } = useApp();

  const isOfficer = category === 'Officer';
  const officerOrder = isOfficer ? state.officerOrders.find((o) => o.orderNumber === orderNumber) : null;
  const airmanOrder = !isOfficer ? state.airmanOrders.find((o) => o.orderNumber === orderNumber) : null;

  const order = isOfficer ? officerOrder : airmanOrder;

  // Pay Modal
  const [payModalOpen, setPayModalOpen] = useState(false);
  const [payAmountInput, setPayAmountInput] = useState<string>('');

  // Delete 2-step modal
  const [deleteStep, setDeleteStep] = useState<0 | 1 | 2>(0);

  const handleBack = () => {
    if (fromDelivery) {
      onNavigate('delivery');
    } else {
      onNavigate(isOfficer ? 'orders' : 'airman-orders');
    }
  };

  if (!order) {
    return (
      <PolarisPage title="Order Not Found" backAction={handleBack}>
        <div className="bg-white rounded-[24px] p-12 text-center border border-[#e0e0e0]">
          <p className="text-[15px] text-[#6e6e73] mb-4">
            Order #{orderNumber} ({category}) does not exist or was deleted.
          </p>
          <button onClick={handleBack} className="btn btn-primary">
            Return to Orders
          </button>
        </div>
      </PolarisPage>
    );
  }

  const handleDeleteStep2 = () => {
    if (isOfficer) {
      deleteOfficerOrder(orderNumber);
    } else {
      deleteAirmanOrder(orderNumber);
    }
    handleBack();
  };

  const handleConfirmPayment = () => {
    if (isOfficer && officerOrder) {
      const amt = parseFloat(payAmountInput);
      if (!isNaN(amt) && amt > 0) {
        recordOfficerPayment(orderNumber, amt);
      }
      setPayModalOpen(false);
    }
  };

  const displayName = isOfficer
    ? officerOrder?.customerName
    : airmanOrder?.customerName || `Airman ${airmanOrder?.customerBdNumber}`;

  const dueAmount = isOfficer && officerOrder ? officerOrder.due : 0;
  const totalAmount = isOfficer && officerOrder ? officerOrder.totalAmount : 0;
  const advanceAmount = isOfficer && officerOrder ? officerOrder.advance : 0;
  const discountAmount = isOfficer && officerOrder ? officerOrder.discountAmount : 0;

  const paidPercent =
    totalAmount > 0
      ? Math.min(100, Math.round(((totalAmount - dueAmount) / totalAmount) * 100))
      : 100;

  return (
    <PolarisPage
      title=""
      backAction={handleBack}
      fullWidth
    >
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* =========================================================================
            LEFT COLUMN (8 Cols): Header Card, Info Trays, Items, Measurements
            Section 5.3 & Section 10.7
           ========================================================================= */}
        <div className="lg:col-span-8 space-y-6">
          {/* Header Card (White panel, 24px radius, 140px parchment illustration square) */}
          <div className="bg-white rounded-[24px] p-6 border border-[#e0e0e0] flex flex-col sm:flex-row items-center sm:items-start gap-6 select-none">
            {/* 140px Parchment Square with Tag Illustration */}
            <div className="w-[140px] h-[140px] rounded-[20px] bg-[#f5f5f7] flex items-center justify-center shrink-0 border border-[#e0e0e0]/60">
              <TailorTagIllustration size={110} withString={true} />
            </div>

            {/* Right Header Content */}
            <div className="flex-1 min-w-0 space-y-3 text-center sm:text-left">
              <span className="text-[14px] text-[#6e6e73] font-normal block">
                Order #{order.orderNumber}
              </span>

              <h1 className="text-[32px] md:text-[36px] font-semibold text-[#1d1d1f] tracking-[-0.03em] leading-tight truncate">
                {displayName}
              </h1>

              {/* Chip Row */}
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-0.5">
                {/* Category Ink Pill */}
                <span className="px-3 py-1 rounded-full bg-[#1d1d1f] text-white text-[12px] font-semibold tracking-tight">
                  {category}
                </span>

                {/* Inline Status Dot + Word */}
                <StatusBadge
                  status={order.status}
                  interactive={true}
                  onChange={(newStatus) => {
                    if (newStatus === 'Delivered') {
                      onNavigate('confirm-delivery', { orderNumber, category, fromDelivery });
                      return;
                    }
                    if (isOfficer) updateOfficerOrderStatus(orderNumber, newStatus);
                    else updateAirmanOrderStatus(orderNumber, newStatus);
                  }}
                />

                <span className="text-[13px] text-[#6e6e73] font-normal">
                  {order.customerBdNumber}
                </span>
              </div>

              {/* Record Actions Under Title */}
              <div className="flex items-center justify-center sm:justify-start gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() =>
                    onNavigate(isOfficer ? 'edit-officer-order' : 'edit-airman-order', {
                      orderNumber: order.orderNumber,
                    })
                  }
                  className="h-[40px] px-5 rounded-full bg-[#0066cc] hover:bg-[#0071e3] text-white text-[14px] font-semibold flex items-center gap-2 cursor-pointer transition-all active:scale-95 shadow-xs"
                >
                  <Edit2 className="w-4 h-4" />
                  <span>Edit order</span>
                </button>

                <button
                  type="button"
                  onClick={() => setDeleteStep(1)}
                  className="w-10 h-10 rounded-full bg-[#fceaea] hover:bg-[#fbdcdc] text-[#c62828] flex items-center justify-center cursor-pointer transition-colors"
                  title="Delete order"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Two Info Trays Side by Side (Customer Info & Order Info) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Customer Info Tray */}
            <div className="p-5 bg-[#f5f5f7] rounded-[18px] border border-[#e0e0e0]/70 space-y-3">
              <h3 className="text-[15px] font-semibold text-[#1d1d1f]">Customer Information</h3>
              <div className="grid grid-cols-2 gap-3 text-[13px]">
                <div>
                  <span className="text-[12px] text-[#6e6e73] block">BD Number</span>
                  <span className="font-semibold text-[#1d1d1f] num">{order.customerBdNumber}</span>
                </div>
                <div>
                  <span className="text-[12px] text-[#6e6e73] block">Customer Name</span>
                  <span className="font-semibold text-[#1d1d1f] truncate block">{displayName}</span>
                </div>
                <div>
                  <span className="text-[12px] text-[#6e6e73] block">Phone Contact</span>
                  <span className="font-semibold text-[#1d1d1f] num">{order.customerPhone || 'Not set'}</span>
                </div>
                <div>
                  <span className="text-[12px] text-[#6e6e73] block">Unit / Rank</span>
                  <span className="font-semibold text-[#1d1d1f]">BAF Commissioned</span>
                </div>
              </div>
            </div>

            {/* Order Info Tray */}
            <div className="p-5 bg-[#f5f5f7] rounded-[18px] border border-[#e0e0e0]/70 space-y-3">
              <h3 className="text-[15px] font-semibold text-[#1d1d1f]">Order Schedule & Status</h3>
              <div className="grid grid-cols-2 gap-3 text-[13px]">
                <div>
                  <span className="text-[12px] text-[#6e6e73] block">Order Date</span>
                  <span className="font-semibold text-[#1d1d1f] num">{order.orderDate || 'Not set'}</span>
                </div>
                <div>
                  <span className="text-[12px] text-[#6e6e73] block">Delivery Due Date</span>
                  <span className="font-semibold text-[#1d1d1f] num">
                    {'deliveryDate' in order ? (order as any).deliveryDate || 'Not set' : '—'}
                  </span>
                </div>
                <div className="col-span-2">
                  <span className="text-[12px] text-[#6e6e73] block">Current Stage</span>
                  <span className={`font-semibold ${order.status === 'Delivered' ? 'text-[#1e7b43]' : 'text-[#1d1d1f]'}`}>
                    {order.status === 'Delivered'
                      ? `Delivered on ${order.deliveredDate || ('deliveryDate' in order ? (order as any).deliveryDate : '') || 'completed'}`
                      : order.status}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Items Table Panel */}
          <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#f0f0f0]">
              <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Tailoring Items & Garments</h3>
              <span className="text-[13px] text-[#6e6e73]">{order.items.length} garments</span>
            </div>

            <div className="overflow-x-auto no-scrollbar">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="h-9 bg-[#f5f5f7] rounded-[10px] text-[12px] font-semibold text-[#6e6e73]">
                    <th className="px-3 rounded-l-[10px]">Item Description</th>
                    <th className="px-3 text-center">Quantity</th>
                    {isOfficer && <th className="px-3 text-right">Unit Price</th>}
                    {isOfficer && <th className="px-3 text-right">Line Total</th>}
                    <th className="px-3 text-right rounded-r-[10px]">Slip</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#f0f0f0]">
                  {order.items.map((it, idx) => (
                    <tr key={idx} className="h-14">
                      <td className="px-3 py-2 font-semibold text-[#1d1d1f] text-[14px]">
                        {it.name}
                      </td>
                      <td className="px-3 py-2 text-center text-[14px] font-semibold text-[#1d1d1f] num">
                        {it.quantity}
                      </td>
                      {isOfficer && (
                        <td className="px-3 py-2 text-right text-[14px] text-[#6e6e73] num">
                          ৳{((it as any).unitPrice || 0).toLocaleString()}
                        </td>
                      )}
                      {isOfficer && (
                        <td className="px-3 py-2 text-right text-[14px] font-semibold text-[#1d1d1f] num">
                          ৳{(((it as any).unitPrice || 0) * it.quantity).toLocaleString()}
                        </td>
                      )}
                      <td className="px-3 py-2 text-right">
                        <button
                          onClick={() =>
                            onNavigate('print-slip', {
                              orderNumber: order.orderNumber,
                              category,
                              itemIndex: idx,
                            })
                          }
                          className="h-7 px-2.5 rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#0066cc] text-[12px] font-semibold inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Scissors className="w-3 h-3" />
                          <span>Slip</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Payments Record Panel (Officer Orders) */}
          {isOfficer && officerOrder && (officerOrder.payments?.length ?? 0) > 0 && (
            <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#f0f0f0]">
                <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Payment History</h3>
                <span className="text-[13px] text-[#6e6e73]">
                  {officerOrder.payments?.length} transactions
                </span>
              </div>
              <div className="divide-y divide-[#f0f0f0]">
                {officerOrder.payments?.map((pay, pIdx) => (
                  <div key={pIdx} className="py-3 flex items-center justify-between text-[13px]">
                    <div>
                      <span className="font-semibold text-[#1d1d1f]">৳{pay.amount.toLocaleString()}</span>
                      <span className="text-[#6e6e73] ml-2">Payment recorded</span>
                    </div>
                    <span className="text-[#6e6e73] num">{pay.date}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Measurements Trays Panel */}
          {((order.shirtMeasurements && Object.values(order.shirtMeasurements).some((v) => typeof v === 'string' && v.trim() !== '')) ||
            (order.pantMeasurements && Object.values(order.pantMeasurements).some((v) => typeof v === 'string' && v.trim() !== ''))) && (
            <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-6">
              <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Garment Measurements</h3>

              {order.shirtMeasurements && (
                <div className="space-y-2">
                  <span className="text-[13px] font-semibold text-[#6e6e73] uppercase tracking-wider block">Shirt Measurements</span>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {Object.entries(order.shirtMeasurements).map(([k, v]) => {
                      if (k === 'handWrittenNotes' || k === 'extraNotes') return null;
                      return (
                        <div key={k} className="p-3 bg-[#f5f5f7] rounded-[14px]">
                          <span className="text-[11px] text-[#6e6e73] uppercase tracking-wider block font-semibold truncate">
                            {k}
                          </span>
                          <span className="text-[16px] font-semibold text-[#1d1d1f] num">{String(v || '—')}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {order.pantMeasurements && (
                <div className="space-y-2">
                  <span className="text-[13px] font-semibold text-[#6e6e73] uppercase tracking-wider block">Pant Measurements</span>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {Object.entries(order.pantMeasurements).map(([k, v]) => {
                      if (k === 'handWrittenNotes' || k === 'extraNotes') return null;
                      return (
                        <div key={k} className="p-3 bg-[#f5f5f7] rounded-[14px]">
                          <span className="text-[11px] text-[#6e6e73] uppercase tracking-wider block font-semibold truncate">
                            {k}
                          </span>
                          <span className="text-[16px] font-semibold text-[#1d1d1f] num">{String(v || '—')}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* =========================================================================
            RIGHT COLUMN (4 Cols): Sticky Money Aside
            Section 10.6
           ========================================================================= */}
        <div className="lg:col-span-4 sticky top-6">
          <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-6">
            <div className="flex items-center justify-between">
              <span className="text-[14px] font-semibold text-[#6e6e73]">Financial Status</span>
              {dueAmount > 0 ? (
                <span className="text-[12px] font-semibold px-2.5 py-0.5 rounded-full bg-[#fdeee7] text-[#c2410c]">
                  Pending clearance
                </span>
              ) : (
                <span className="text-[12px] font-semibold px-2.5 py-0.5 rounded-full bg-[#e3f4e8] text-[#1e7b43]">
                  Delivered & Settled
                </span>
              )}
            </div>

            {/* Red Due Numeral */}
            <div>
              <span className="text-[12px] font-semibold text-[#6e6e73] uppercase tracking-wider block mb-1">
                Balance Due
              </span>
              <div
                className={`text-[44px] font-semibold leading-none num ${
                  dueAmount > 0 ? 'text-[#c62828]' : 'text-[#1e7b43]'
                }`}
              >
                <span className="text-[20px] text-[#6e6e73] font-normal mr-1 align-top">৳</span>
                {dueAmount.toLocaleString()}
              </div>
            </div>

            {/* Financial Details Tray */}
            {isOfficer && (
              <div className="p-4 bg-[#f5f5f7] rounded-[18px] space-y-3 text-[13px]">
                <div className="flex justify-between">
                  <span className="text-[#6e6e73]">Total Price:</span>
                  <span className="font-semibold text-[#1d1d1f] num">৳{totalAmount.toLocaleString()}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between">
                    <span className="text-[#6e6e73]">Discount:</span>
                    <span className="font-semibold text-[#1e7b43] num">-৳{discountAmount.toLocaleString()}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-[#6e6e73]">Advance Received:</span>
                  <span className="font-semibold text-[#1d1d1f] num">৳{advanceAmount.toLocaleString()}</span>
                </div>
                <div className="pt-2 border-t border-[#e0e0e0]/70 flex justify-between">
                  <span className="text-[#6e6e73]">Payment Progress:</span>
                  <span className="font-semibold text-[#1d1d1f] num">{paidPercent}% paid</span>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="space-y-3">
              {isOfficer && dueAmount > 0 && (
                <button
                  onClick={() => {
                    setPayAmountInput(String(dueAmount));
                    setPayModalOpen(true);
                  }}
                  className="w-full h-[44px] rounded-full bg-[#0066cc] hover:bg-[#0071e3] text-white text-[15px] font-semibold flex items-center justify-center gap-2 cursor-pointer shadow-xs active:scale-95 transition-all"
                >
                  <CreditCard className="w-4 h-4" />
                  <span>Pay ৳{dueAmount.toLocaleString()}</span>
                </button>
              )}

              {/* Print Actions */}
              <button
                onClick={() =>
                  onNavigate('print-slip', {
                    orderNumber: order.orderNumber,
                    category,
                  })
                }
                className="w-full h-[44px] rounded-full border border-[#0066cc] text-[#0066cc] hover:bg-[#0066cc]/10 text-[14px] font-semibold flex items-center justify-center gap-2 cursor-pointer transition-colors"
              >
                <Scissors className="w-4 h-4" />
                <span>Print All Cutting Slips</span>
              </button>

              {isOfficer && (
                <button
                  onClick={() =>
                    onNavigate('print-invoice', {
                      orderNumber: order.orderNumber,
                      category: 'Officer',
                    })
                  }
                  className="w-full h-[44px] rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#1d1d1f] text-[14px] font-semibold flex items-center justify-center gap-2 cursor-pointer transition-colors"
                >
                  <Printer className="w-4 h-4 text-[#6e6e73]" />
                  <span>Print Formal Invoice</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Pay Modal */}
      <AnimatePresence>
        {payModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="fixed inset-0 bg-black/35 backdrop-blur-xs"
              onClick={() => setPayModalOpen(false)}
              aria-hidden="true"
            />
            <div className="relative z-10 w-full max-w-md bg-white rounded-[28px] p-6 border border-[#e0e0e0] shadow-2xl">
              <h3 className="text-[22px] font-semibold text-[#1d1d1f]">Receive Payment</h3>
              <p className="text-[14px] text-[#6e6e73] mt-1">
                Clearing due for order #{order.orderNumber} ({displayName})
              </p>
              <div className="my-5 p-4 bg-[#f5f5f7] rounded-[18px] space-y-2">
                <div className="flex justify-between text-[13px]">
                  <span className="text-[#6e6e73]">Remaining Due:</span>
                  <span className="font-semibold text-[#c62828] num">৳{dueAmount.toLocaleString()}</span>
                </div>
                <div className="mt-2">
                  <label className="text-[12px] font-semibold text-[#6e6e73] block mb-1">
                    Amount Received (৳)
                  </label>
                  <input
                    type="number"
                    value={payAmountInput}
                    onChange={(e) => setPayAmountInput(e.target.value)}
                    max={dueAmount}
                    className="w-full h-[44px] px-4 rounded-[12px] bg-white border border-[#e0e0e0] text-[18px] font-semibold num outline-none focus:border-[#0071e3]"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setPayModalOpen(false)}
                  className="h-[44px] rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#1d1d1f] font-semibold text-[15px]"
                >
                  Cancel
                </button>
                <button
                  onClick={handleConfirmPayment}
                  className="h-[44px] rounded-full bg-[#0066cc] hover:bg-[#0071e3] text-white font-semibold text-[15px] shadow-xs active:scale-95"
                >
                  Confirm Pay
                </button>
              </div>
            </div>
          </div>
        )}
      </AnimatePresence>

      {/* Two-step delete dialog */}
      <AnimatePresence>
        {deleteStep > 0 && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="fixed inset-0 bg-black/35 backdrop-blur-xs"
              onClick={() => setDeleteStep(0)}
              aria-hidden="true"
            />
            <div className="relative z-10 w-full max-w-[420px] bg-white rounded-[28px] p-6 border border-[#e0e0e0] shadow-2xl">
              <div className="flex items-center justify-between mb-4">
                <div className="w-10 h-10 rounded-full bg-[#fceaea] text-[#c62828] flex items-center justify-center">
                  <Trash2 className="w-5 h-5" />
                </div>
                <div className="flex items-center gap-1.5 text-[12px] font-semibold text-[#6e6e73]">
                  <span>Step {deleteStep} of 2</span>
                  <div className="flex items-center gap-1 ml-1">
                    <span className="w-5 h-1.5 rounded-full bg-[#1d1d1f]" />
                    <span
                      className={`w-5 h-1.5 rounded-full transition-colors ${
                        deleteStep === 2 ? 'bg-[#c62828]' : 'bg-[#e0e0e0]'
                      }`}
                    />
                  </div>
                </div>
              </div>

              <h3 className="text-[22px] font-semibold text-[#1d1d1f] leading-snug">
                {deleteStep === 1
                  ? `Delete order #${order.orderNumber}?`
                  : 'This cannot be undone. Delete permanently?'}
              </h3>
              <p className="text-[15px] text-[#6e6e73] mt-2 leading-relaxed">
                {deleteStep === 1
                  ? `Please verify that you want to remove ${displayName}'s order. You will be asked once more.`
                  : 'The order and its cutting slips will be removed permanently.'}
              </p>

              <div className="grid grid-cols-2 gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setDeleteStep(0)}
                  className="h-[44px] rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#1d1d1f] font-semibold text-[15px]"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => (deleteStep === 1 ? setDeleteStep(2) : handleDeleteStep2())}
                  className={`h-[44px] rounded-full font-semibold text-[15px] text-white active:scale-95 ${
                    deleteStep === 1
                      ? 'bg-[#0066cc] hover:bg-[#0071e3]'
                      : 'bg-[#c62828] hover:bg-[#b02222]'
                  }`}
                >
                  {deleteStep === 1 ? 'Continue' : 'Delete'}
                </button>
              </div>
            </div>
          </div>
        )}
      </AnimatePresence>
    </PolarisPage>
  );
};
