import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { StatusBadge } from './StatusBadge.tsx';
import { ArrowLeft, Search, Calendar, ChevronRight, User, X, Phone, Ruler } from 'lucide-react';
import { ScreenName } from './Navbar.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';

interface CustomerHistoryScreenProps {
  initialBdNumber?: string;
  initialCategory?: 'Officer' | 'Airman';
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const CustomerHistoryScreen: React.FC<CustomerHistoryScreenProps> = ({
  initialBdNumber,
  initialCategory,
  onNavigate,
}) => {
  const { state } = useApp();

  const [activeCategory, setActiveCategory] = useState<'Officer' | 'Airman'>(
    initialCategory || 'Officer'
  );
  const [selectedBd, setSelectedBd] = useState<string | null>(initialBdNumber || null);
  const [searchQuery, setSearchQuery] = useState('');

  // Per-customer stats
  const customerStats = useMemo(() => {
    const stats: Record<string, { ordersCount: number; spent: number; due: number }> = {};

    for (const c of state.customers) {
      const key = `${c.category}-${c.bdNumber.trim().toUpperCase()}`;
      stats[key] = { ordersCount: 0, spent: 0, due: 0 };
    }

    for (const o of state.officerOrders) {
      const bd = o.customerBdNumber || '';
      const key = `Officer-${bd.trim().toUpperCase()}`;
      if (!stats[key]) stats[key] = { ordersCount: 0, spent: 0, due: 0 };
      stats[key].ordersCount += 1;
      const spent = (Number(o.totalAmount) || 0) - (Number(o.discountAmount) || 0);
      stats[key].spent += spent;
      stats[key].due += Number(o.due) || 0;
    }

    for (const o of state.airmanOrders) {
      const bd = o.customerBdNumber || '';
      const key = `Airman-${bd.trim().toUpperCase()}`;
      if (!stats[key]) stats[key] = { ordersCount: 0, spent: 0, due: 0 };
      stats[key].ordersCount += 1;
    }

    return stats;
  }, [state.customers, state.officerOrders, state.airmanOrders]);

  const customerList = useMemo(() => {
    return state.customers
      .filter((c) => c.category === activeCategory)
      .filter((c) => {
        if (!searchQuery.trim()) return true;
        const q = searchQuery.toLowerCase().trim();
        return c.name.toLowerCase().includes(q) || c.bdNumber.toLowerCase().includes(q);
      });
  }, [state.customers, activeCategory, searchQuery]);

  // Set default selection
  const currentCustomer = useMemo(() => {
    if (selectedBd) {
      const found = state.customers.find(
        (c) => c.category === activeCategory && c.bdNumber === selectedBd
      );
      if (found) return found;
    }
    return customerList[0] || null;
  }, [customerList, selectedBd, activeCategory, state.customers]);

  // Customer orders
  const customerOrders = useMemo(() => {
    if (!currentCustomer) return [];
    if (activeCategory === 'Officer') {
      return state.officerOrders
        .filter((o) => o.customerBdNumber === currentCustomer.bdNumber)
        .sort((a, b) => b.orderNumber - a.orderNumber);
    } else {
      return state.airmanOrders
        .filter((o) => o.customerBdNumber === currentCustomer.bdNumber)
        .sort((a, b) => b.orderNumber - a.orderNumber);
    }
  }, [currentCustomer, activeCategory, state.officerOrders, state.airmanOrders]);

  const stat = currentCustomer
    ? customerStats[`${currentCustomer.category}-${currentCustomer.bdNumber.trim().toUpperCase()}`] || {
        ordersCount: 0,
        spent: 0,
        due: 0,
      }
    : { ordersCount: 0, spent: 0, due: 0 };

  return (
    <PolarisPage
      title="Customer History"
      subtitle="Lifetime order progression, bespoke measurements, and hishab for BAF personnel."
      backAction={() => onNavigate('customers')}
      fullWidth
    >
      {/* Category selector & Search bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 select-none">
        <div className="flex items-center gap-2">
          <button
            aria-pressed={activeCategory === 'Officer'}
            onClick={() => {
              setActiveCategory('Officer');
              setSelectedBd(null);
            }}
            className={`h-[40px] px-5 rounded-full text-[14px] font-semibold transition-all cursor-pointer ${
              activeCategory === 'Officer'
                ? 'bg-white border-2 border-[#0071e3] text-[#1d1d1f]'
                : 'bg-white border border-[#e0e0e0] text-[#6e6e73] hover:text-[#1d1d1f]'
            }`}
          >
            Officer
          </button>
          <button
            aria-pressed={activeCategory === 'Airman'}
            onClick={() => {
              setActiveCategory('Airman');
              setSelectedBd(null);
            }}
            className={`h-[40px] px-5 rounded-full text-[14px] font-semibold transition-all cursor-pointer ${
              activeCategory === 'Airman'
                ? 'bg-white border-2 border-[#0071e3] text-[#1d1d1f]'
                : 'bg-white border border-[#e0e0e0] text-[#6e6e73] hover:text-[#1d1d1f]'
            }`}
          >
            Airman
          </button>
        </div>

        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 text-[#6e6e73] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search name or BD..."
            className="w-full h-[40px] pl-10 pr-8 rounded-full bg-white border border-[#e0e0e0] text-[14px] text-[#1d1d1f] placeholder-[#7a7a7a] outline-none"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column (5 Cols): Customer selector list */}
        <div className="lg:col-span-5 bg-white rounded-[24px] border border-[#e0e0e0] p-5 space-y-3">
          <h3 className="text-[17px] font-semibold text-[#1d1d1f]">
            {activeCategory} Clients ({customerList.length})
          </h3>

          <div className="divide-y divide-[#f0f0f0] max-h-[600px] overflow-y-auto no-scrollbar">
            {customerList.map((c) => {
              const isSelected = currentCustomer?.bdNumber === c.bdNumber;
              return (
                <div
                  key={c.bdNumber}
                  onClick={() => setSelectedBd(c.bdNumber)}
                  className={`p-3 rounded-[16px] cursor-pointer transition-colors flex items-center justify-between ${
                    isSelected ? 'bg-[#f0f0f0]' : 'hover:bg-[#fafafc]'
                  }`}
                >
                  <div className="min-w-0">
                    <span className="font-semibold text-[#1d1d1f] text-[14px] truncate block">
                      {c.name}
                    </span>
                    <span className="text-[12px] text-[#6e6e73] num">
                      BD/{c.bdNumber} {c.phone ? `· ${c.phone}` : ''}
                    </span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#6e6e73] shrink-0" />
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column (7 Cols): Selected Customer Dossier */}
        <div className="lg:col-span-7 space-y-6">
          {currentCustomer ? (
            <>
              {/* Profile Card */}
              <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-5">
                <div className="flex items-center gap-3.5">
                  <div className="entity-chip text-white font-bold text-sm w-11 h-11">
                    BD
                  </div>
                  <div>
                    <h2 className="text-[24px] font-semibold text-[#1d1d1f] leading-snug">
                      {currentCustomer.name}
                    </h2>
                    <p className="text-[13px] text-[#6e6e73]">
                      BD/{currentCustomer.bdNumber} · {currentCustomer.category} · Phone: {currentCustomer.phone || 'Not set'}
                    </p>
                  </div>
                </div>

                {/* Lifetime Stats Tray */}
                <div className="grid grid-cols-3 gap-3 p-4 bg-[#f5f5f7] rounded-[18px]">
                  <div>
                    <span className="text-[11px] font-semibold text-[#6e6e73] block mb-1">Total Orders</span>
                    <span className="text-[22px] font-semibold text-[#1d1d1f] num">{stat.ordersCount}</span>
                  </div>
                  {activeCategory === 'Officer' && (
                    <>
                      <div>
                        <span className="text-[11px] font-semibold text-[#6e6e73] block mb-1">Lifetime Spent</span>
                        <span className="text-[22px] font-semibold text-[#1d1d1f] num">৳{stat.spent.toLocaleString()}</span>
                      </div>
                      <div>
                        <span className="text-[11px] font-semibold text-[#6e6e73] block mb-1">Balance Due</span>
                        <span className={`text-[22px] font-semibold num ${stat.due > 0 ? 'text-[#c62828]' : 'text-[#1e7b43]'}`}>
                          ৳{stat.due.toLocaleString()}
                        </span>
                      </div>
                    </>
                  )}
                </div>
              </div>

              {/* Order History List */}
              <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-4">
                <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Uniform Orders History</h3>
                <div className="divide-y divide-[#f0f0f0]">
                  {customerOrders.map((ord) => (
                    <div
                      key={ord.id}
                      onClick={() =>
                        onNavigate('order-details', {
                          orderNumber: ord.orderNumber,
                          category: activeCategory,
                        })
                      }
                      className="py-3 flex items-center justify-between hover:bg-[#fafafc] rounded-[14px] px-2 cursor-pointer transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className="entity-chip">#{ord.orderNumber}</div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-[#1d1d1f] text-[14px]">
                              {ord.items.map((it) => it.name).join(', ')}
                            </span>
                            <StatusBadge status={ord.status} />
                          </div>
                          <span className="text-[12px] text-[#6e6e73] num">
                            Ordered: {ord.orderDate || 'Not set'} · Delivery: {('deliveryDate' in ord ? (ord as any).deliveryDate : (ord as any).deliveredDate) || 'Not set'}
                          </span>
                        </div>
                      </div>

                      <div className="text-right flex items-center gap-3">
                        {activeCategory === 'Officer' && (
                          <div>
                            <span className="text-[14px] font-semibold text-[#1d1d1f] num block">
                              ৳{((ord as any).totalAmount || (ord as any).total || 0).toLocaleString()}
                            </span>
                            {(ord as any).due > 0 && (
                              <span className="text-[12px] font-semibold text-[#c62828] num">
                                ৳{(ord as any).due.toLocaleString()} due
                              </span>
                            )}
                          </div>
                        )}
                        <ChevronRight className="w-4 h-4 text-[#6e6e73]" />
                      </div>
                    </div>
                  ))}
                  {customerOrders.length === 0 && (
                    <div className="py-6 text-center text-[#6e6e73] text-[13px]">
                      No previous orders recorded for this customer yet.
                    </div>
                  )}
                </div>
              </div>
            </>
          ) : (
            <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-12 text-center text-[#6e6e73]">
              Select a customer to view their complete profile and measurements history.
            </div>
          )}
        </div>
      </div>
    </PolarisPage>
  );
};
