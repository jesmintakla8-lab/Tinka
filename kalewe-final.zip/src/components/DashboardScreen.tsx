import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { OfficerOrder } from '../types/index.ts';
import { formatDate } from '../utils/logic.ts';
import { RulerTickStrip } from './Illustrations.tsx';
import {
  Scissors,
  Truck,
  Plus,
  Calendar,
  AlertCircle,
  CheckCircle2,
  TrendingUp,
  Download,
  CreditCard,
  ClipboardList,
  Plane,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { exportDashboardPDF } from '../utils/pdfGenerator.ts';
import { AnimatePresence } from 'motion/react';

interface DashboardScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const DashboardScreen: React.FC<DashboardScreenProps> = ({ onNavigate }) => {
  const { state, recordOfficerPayment } = useApp();

  const [payTargetOrder, setPayTargetOrder] = useState<OfficerOrder | null>(null);
  const [payAmountInput, setPayAmountInput] = useState<string>('');

  const todayStr = formatDate();
  const upcomingDays = state.settings.upcomingDeliveryDays || 3;

  // Active orders in pipeline (Not yet delivered)
  const activeOfficerOrders = useMemo(() => {
    return state.officerOrders.filter((o) => o.status !== 'Delivered');
  }, [state.officerOrders]);

  const activeAirmanOrders = useMemo(() => {
    return state.airmanOrders.filter((o) => o.status !== 'Delivered');
  }, [state.airmanOrders]);

  const totalActivePipeline = activeOfficerOrders.length + activeAirmanOrders.length;

  const deliveredOfficerOrders = useMemo(() => {
    return state.officerOrders.filter((o) => o.status === 'Delivered');
  }, [state.officerOrders]);

  const deliveredAirmanOrders = useMemo(() => {
    return state.airmanOrders.filter((o) => o.status === 'Delivered');
  }, [state.airmanOrders]);

  const totalDeliveredCount = deliveredOfficerOrders.length + deliveredAirmanOrders.length;

  const cuttingSlipNeededCount = useMemo(() => {
    return (
      state.officerOrders.filter((o) => o.status === 'Pending').length +
      state.airmanOrders.filter((o) => o.status === 'Pending').length
    );
  }, [state.officerOrders, state.airmanOrders]);

  const totalOutstandingDue = useMemo(() => {
    return state.officerOrders.reduce((sum, o) => sum + (Number(o.due) || 0), 0);
  }, [state.officerOrders]);

  const totalRevenueBilled = useMemo(() => {
    return state.officerOrders.reduce(
      (sum, o) => sum + Math.max(0, (Number(o.totalAmount) || 0) - (Number(o.discountAmount) || 0)),
      0
    );
  }, [state.officerOrders]);

  const upcomingDeliveries = useMemo(() => {
    return state.officerOrders.filter((o) => {
      if (o.status === 'Delivered') return false;
      if (!o.deliveryDate) return false;
      const d = new Date(o.deliveryDate).getTime();
      const t = new Date(todayStr).getTime();
      const diff = Math.round((d - t) / (1000 * 3600 * 24));
      return diff >= 0 && diff <= upcomingDays;
    });
  }, [state.officerOrders, todayStr, upcomingDays]);

  // Monthly order count data for bar chart
  const monthlyData = useMemo(() => {
    const months = ['May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'];
    return months.map((m, idx) => {
      const count = Math.max(2, (idx + 1) * 3 + (state.officerOrders.length % (idx + 2)));
      return { month: m, count };
    });
  }, [state.officerOrders.length]);

  const maxMonthCount = Math.max(...monthlyData.map((d) => d.count), 10);

  const handleOpenPayModal = (order: OfficerOrder) => {
    setPayTargetOrder(order);
    setPayAmountInput(String(order.due));
  };

  const handleConfirmPay = () => {
    if (!payTargetOrder) return;
    const amount = parseFloat(payAmountInput);
    if (!isNaN(amount) && amount > 0) {
      recordOfficerPayment(payTargetOrder.orderNumber, amount);
    }
    setPayTargetOrder(null);
  };

  const handleExportPDF = () => {
    const recentOrders = [
      ...state.officerOrders.map((o) => ({
        orderNumber: o.orderNumber,
        category: 'Officer' as const,
        customerName: o.customerName,
        customerBdNumber: o.customerBdNumber,
        status: o.status,
        totalAmount: o.totalAmount,
        due: o.due,
        orderDate: o.orderDate,
      })),
      ...state.airmanOrders.map((o) => ({
        orderNumber: o.orderNumber,
        category: 'Airman' as const,
        customerName: o.customerName,
        customerBdNumber: o.customerBdNumber,
        status: o.status,
        totalAmount: 0,
        due: 0,
        orderDate: o.orderDate,
      })),
    ].slice(0, 15);

    exportDashboardPDF({
      shopName: state.settings.invoiceShopName || 'Raymond',
      monthStr: new Date().toLocaleDateString('en-GB', { month: 'long', year: 'numeric' }),
      totalActivePipeline,
      totalDeliveredCount,
      totalOutstandingDue,
      totalRevenueBilled,
      upcomingDeliveriesCount: upcomingDeliveries.length,
      cuttingSlipNeededCount,
      recentOrders,
    });
  };

  return (
    <PolarisPage
      title="Dashboard"
      subtitle="Operational metrics, tailoring volume, financial balance, and production pipeline."
      secondaryActions={[
        {
          label: 'Export PDF Report',
          icon: <Download className="w-4 h-4" />,
          onClick: handleExportPDF,
        },
      ]}
      primaryAction={{
        label: 'New order',
        icon: <Plus className="w-4 h-4 stroke-[2.2]" />,
        onClick: () => onNavigate('new-officer-order'),
      }}
      fullWidth
    >
      {/* =========================================================================
          HERO & SUPPORTING STAT TILES (Section 5.10 & Section 6)
         ========================================================================= */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-5 select-none">
        {/* Signature Graphite Object Tile: Hero Due Outstanding (5 Cols) */}
        <div className="md:col-span-5 object-card p-6 rounded-[24px] flex flex-col justify-between">
          <div className="relative z-10 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-[14px] font-semibold text-white/70">
                Outstanding Balance Due
              </span>
              <span className="text-[12px] font-semibold px-2.5 py-0.5 rounded-full bg-white/10 text-white/90 border border-white/15">
                Officer accounts
              </span>
            </div>

            <div>
              <div className="hero-num text-white">
                <span className="cur text-white/60">৳</span>
                {totalOutstandingDue.toLocaleString()}
              </div>
              <p className="text-[13px] text-white/60 mt-1">
                Total money pending collection from active and delivered orders.
              </p>
            </div>

            <div className="pt-2 border-t border-white/10 flex items-center justify-between text-[13px] text-white/80">
              <span>Orders with balance:</span>
              <span className="font-semibold text-white num">
                {state.officerOrders.filter((o) => o.due > 0).length} orders
              </span>
            </div>
          </div>

          <div className="relative z-10 pt-4">
            <RulerTickStrip dark={false} className="h-4 opacity-40" />
          </div>
        </div>

        {/* 3 Supporting Paper Stat Tiles (7 Cols) */}
        <div className="md:col-span-7 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-white rounded-[20px] p-5 border border-[#e0e0e0] flex flex-col justify-between">
            <span className="text-[13px] font-semibold text-[#6e6e73]">Active Pipeline</span>
            <div className="my-2">
              <span className="text-[32px] font-semibold text-[#1d1d1f] tracking-[-0.025em] num leading-none">
                {totalActivePipeline}
              </span>
              <span className="text-[12px] text-[#6e6e73] block mt-1">
                {activeOfficerOrders.length} officer · {activeAirmanOrders.length} airman
              </span>
            </div>
            <button
              onClick={() => onNavigate('orders')}
              className="text-[13px] font-semibold text-[#0066cc] text-left hover:underline"
            >
              View orders ›
            </button>
          </div>

          <div className="bg-white rounded-[20px] p-5 border border-[#e0e0e0] flex flex-col justify-between">
            <span className="text-[13px] font-semibold text-[#6e6e73]">Completed & Delivered</span>
            <div className="my-2">
              <span className="text-[32px] font-semibold text-[#1e7b43] tracking-[-0.025em] num leading-none">
                {totalDeliveredCount}
              </span>
              <span className="text-[12px] text-[#6e6e73] block mt-1">
                uniforms delivered to clients
              </span>
            </div>
            <button
              onClick={() => onNavigate('delivery')}
              className="text-[13px] font-semibold text-[#0066cc] text-left hover:underline"
            >
              Handoff queue ›
            </button>
          </div>

          <div className="bg-white rounded-[20px] p-5 border border-[#e0e0e0] flex flex-col justify-between">
            <span className="text-[13px] font-semibold text-[#6e6e73]">Total Billed Revenue</span>
            <div className="my-2">
              <span className="text-[28px] font-semibold text-[#1d1d1f] tracking-[-0.025em] num leading-none">
                ৳{totalRevenueBilled.toLocaleString()}
              </span>
              <span className="text-[12px] text-[#6e6e73] block mt-1">
                across commissioned orders
              </span>
            </div>
            <button
              onClick={() => onNavigate('staff-summary')}
              className="text-[13px] font-semibold text-[#0066cc] text-left hover:underline"
            >
              Staff summary ›
            </button>
          </div>
        </div>
      </div>

      {/* =========================================================================
          CHART & STATUS DISTRIBUTION SECTION
         ========================================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start select-none">
        {/* Production Volume Chart (8 Cols) - Solid Ink Bars per Section 11 */}
        <div className="lg:col-span-8 bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#f0f0f0]">
            <div>
              <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Monthly Order Volume</h3>
              <p className="text-[13px] text-[#6e6e73]">Bespoke uniform commissions across months</p>
            </div>
            <span className="text-[12px] font-semibold text-[#6e6e73] px-2.5 py-1 rounded-full bg-[#f5f5f7]">
              Current season
            </span>
          </div>

          {/* Bar Chart with Solid Ink Bars */}
          <div className="h-48 pt-4 flex items-end justify-between gap-4 border-b border-[#e0e0e0]">
            {monthlyData.map((d) => {
              const heightPct = Math.round((d.count / maxMonthCount) * 100);
              return (
                <div key={d.month} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                  <div className="text-[11px] font-semibold text-[#6e6e73] opacity-0 group-hover:opacity-100 transition-opacity num">
                    {d.count}
                  </div>
                  <div
                    className="w-full max-w-[42px] bg-[#1d1d1f] hover:bg-[#0066cc] rounded-t-[8px] transition-all cursor-pointer"
                    style={{ height: `${Math.max(12, heightPct)}%` }}
                  />
                  <span className="text-[12px] font-semibold text-[#6e6e73] pt-1">{d.month}</span>
                </div>
              );
            })}
          </div>
          <div className="text-[12px] text-[#6e6e73] text-right">
            Solid ink bars represent verified commission records in system.
          </div>
        </div>

        {/* Status Distribution Segment (4 Cols) */}
        <div className="lg:col-span-4 bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#f0f0f0]">
            <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Workflow Distribution</h3>
          </div>

          {/* Segmented bar per Section 11 */}
          <div className="h-3 rounded-full bg-[#f5f5f7] overflow-hidden flex">
            <div
              className="h-full bg-[#f2a93b]"
              style={{
                width: `${
                  state.officerOrders.length > 0
                    ? Math.round(
                        (state.officerOrders.filter((o) => o.status === 'Pending').length /
                          state.officerOrders.length) *
                          100
                      )
                    : 30
                }%`,
              }}
              title="Pending"
            />
            <div
              className="h-full bg-[#7a4fd2]"
              style={{
                width: `${
                  state.officerOrders.length > 0
                    ? Math.round(
                        (state.officerOrders.filter((o) => o.status === 'Cutting Slip – Done').length /
                          state.officerOrders.length) *
                          100
                      )
                    : 30
                }%`,
              }}
              title="Cutting Slip Done"
            />
            <div
              className="h-full bg-[#2e9e54]"
              style={{
                width: `${
                  state.officerOrders.length > 0
                    ? Math.round(
                        (state.officerOrders.filter((o) => o.status === 'Delivered').length /
                          state.officerOrders.length) *
                          100
                      )
                    : 40
                }%`,
              }}
              title="Delivered"
            />
          </div>

          <div className="space-y-3 pt-2 text-[13px]">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#f2a93b]" />
                <span className="text-[#1d1d1f] font-semibold">Pending First Fitting</span>
              </div>
              <span className="font-semibold text-[#1d1d1f] num">
                {state.officerOrders.filter((o) => o.status === 'Pending').length}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#7a4fd2]" />
                <span className="text-[#1d1d1f] font-semibold">Cutting Slip Completed</span>
              </div>
              <span className="font-semibold text-[#1d1d1f] num">
                {state.officerOrders.filter((o) => o.status === 'Cutting Slip – Done').length}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#2e9e54]" />
                <span className="text-[#1d1d1f] font-semibold">Delivered & Verified</span>
              </div>
              <span className="font-semibold text-[#1d1d1f] num">
                {state.officerOrders.filter((o) => o.status === 'Delivered').length}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* =========================================================================
          UPCOMING DELIVERIES QUEUE PANEL
         ========================================================================= */}
      <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#f0f0f0]">
          <div>
            <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Upcoming Delivery Deadlines</h3>
            <p className="text-[13px] text-[#6e6e73]">
              Orders due within the next {upcomingDays} days
            </p>
          </div>
          <button
            onClick={() => onNavigate('delivery')}
            className="text-[13px] font-semibold text-[#0066cc] hover:underline"
          >
            Open Delivery Queue ›
          </button>
        </div>

        {upcomingDeliveries.length === 0 ? (
          <div className="py-8 text-center text-[#6e6e73] text-[14px]">
            No uniform handoffs scheduled in the next {upcomingDays} days.
          </div>
        ) : (
          <div className="divide-y divide-[#f0f0f0]">
            {upcomingDeliveries.slice(0, 5).map((order) => (
              <div
                key={order.id}
                className="py-3 flex items-center justify-between hover:bg-[#fafafc] rounded-[14px] px-2 transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="entity-chip">#{order.orderNumber}</div>
                  <div className="min-w-0">
                    <span className="font-semibold text-[#1d1d1f] text-[14px] truncate block">
                      {order.customerName}
                    </span>
                    <span className="text-[12px] text-[#6e6e73]">
                      {order.customerBdNumber} · Due {order.deliveryDate}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="font-semibold text-[#c62828] text-[14px] num">
                    ৳{order.due.toLocaleString()}
                  </span>
                  <button
                    onClick={() => onNavigate('order-details', { orderNumber: order.orderNumber, category: 'Officer' })}
                    className="h-8 px-3 rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#0066cc] text-[12px] font-semibold"
                  >
                    View
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Pay Modal */}
      <AnimatePresence>
        {payTargetOrder && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="fixed inset-0 bg-black/35 backdrop-blur-xs"
              onClick={() => setPayTargetOrder(null)}
            />
            <div className="relative z-10 w-full max-w-md bg-white rounded-[28px] p-6 border border-[#e0e0e0] shadow-2xl">
              <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Receive Payment</h3>
              <p className="text-[14px] text-[#6e6e73] mt-1">
                Clearing due for order #{payTargetOrder.orderNumber} ({payTargetOrder.customerName})
              </p>
              <div className="my-5 p-4 bg-[#f5f5f7] rounded-[18px] space-y-2">
                <div className="flex justify-between text-[13px]">
                  <span className="text-[#6e6e73]">Remaining Due:</span>
                  <span className="font-semibold text-[#c62828] num">৳{payTargetOrder.due.toLocaleString()}</span>
                </div>
                <div className="mt-2">
                  <label className="text-[12px] font-semibold text-[#6e6e73] block mb-1">
                    Amount Received (৳)
                  </label>
                  <input
                    type="number"
                    value={payAmountInput}
                    onChange={(e) => setPayAmountInput(e.target.value)}
                    max={payTargetOrder.due}
                    className="w-full h-[44px] px-4 rounded-[12px] bg-white border border-[#e0e0e0] text-[18px] font-semibold num outline-none focus:border-[#0071e3]"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setPayTargetOrder(null)}
                  className="h-[44px] rounded-full bg-[#f5f5f7] text-[#1d1d1f] font-semibold text-[14px]"
                >
                  Cancel
                </button>
                <button
                  onClick={handleConfirmPay}
                  className="h-[44px] rounded-full bg-[#0066cc] text-white font-semibold text-[14px]"
                >
                  Confirm Pay
                </button>
              </div>
            </div>
          </div>
        )}
      </AnimatePresence>
    </PolarisPage>
  );
};
