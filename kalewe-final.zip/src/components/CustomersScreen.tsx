import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { Customer } from '../types/index.ts';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import {
  Plus,
  Search,
  History,
  Edit2,
  Trash2,
  X,
  AlertCircle,
  Users,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';
import { AnimatePresence } from 'motion/react';

interface CustomersScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const CustomersScreen: React.FC<CustomersScreenProps> = ({ onNavigate }) => {
  const { state, addCustomer, updateCustomer, deleteCustomer } = useApp();

  const [activeTab, setActiveTab] = useState<'Officer' | 'Airman'>('Officer');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState<'newest' | 'name' | 'mostDue'>('newest');

  // Modals
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [newBdNumber, setNewBdNumber] = useState('');
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [modalError, setModalError] = useState('');

  const [editTarget, setEditTarget] = useState<Customer | null>(null);
  const [editName, setEditName] = useState('');
  const [editPhone, setEditPhone] = useState('');

  const [deleteTarget, setDeleteTarget] = useState<Customer | null>(null);

  // Stats per customer
  const customerStats = useMemo(() => {
    const stats: Record<string, { ordersCount: number; spent: number; due: number }> = {};

    for (const c of state.customers) {
      const key = `${c.category}-${c.bdNumber.trim().toUpperCase()}`;
      stats[key] = { ordersCount: 0, spent: 0, due: 0 };
    }

    for (const o of state.officerOrders) {
      const bd = o.customerBdNumber || '';
      const key = `Officer-${bd.trim().toUpperCase()}`;
      if (!stats[key]) stats[key] = { ordersCount: 0, spent: 0, due: 0 };
      stats[key].ordersCount += 1;
      const spent = (Number(o.totalAmount) || 0) - (Number(o.discountAmount) || 0);
      stats[key].spent += spent;
      stats[key].due += Number(o.due) || 0;
    }

    for (const o of state.airmanOrders) {
      const bd = o.customerBdNumber || '';
      const key = `Airman-${bd.trim().toUpperCase()}`;
      if (!stats[key]) stats[key] = { ordersCount: 0, spent: 0, due: 0 };
      stats[key].ordersCount += 1;
    }

    return stats;
  }, [state.customers, state.officerOrders, state.airmanOrders]);

  const currentCategoryList = useMemo(() => {
    return state.customers.filter((c) => c.category === activeTab);
  }, [state.customers, activeTab]);

  const filteredCustomers = useMemo(() => {
    let list = [...currentCategoryList];

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter((c) => {
        return (
          c.name.toLowerCase().includes(q) ||
          c.bdNumber.toLowerCase().includes(q) ||
          (c.phone && c.phone.includes(q))
        );
      });
    }

    list.sort((a, b) => {
      const statA = customerStats[`${a.category}-${a.bdNumber.trim().toUpperCase()}`] || {
        ordersCount: 0,
        spent: 0,
        due: 0,
      };
      const statB = customerStats[`${b.category}-${b.bdNumber.trim().toUpperCase()}`] || {
        ordersCount: 0,
        spent: 0,
        due: 0,
      };

      if (sortOrder === 'name') return a.name.localeCompare(b.name);
      if (sortOrder === 'mostDue') return statB.due - statA.due;
      return 0;
    });

    return list;
  }, [currentCategoryList, searchQuery, sortOrder, customerStats]);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setModalError('');
    if (!newBdNumber.trim() || !newName.trim()) {
      setModalError('BD number and customer name are required.');
      return;
    }

    const res = addCustomer({
      category: activeTab,
      bdNumber: newBdNumber.trim(),
      name: newName.trim(),
      phone: newPhone.trim(),
    });

    if (!res.success) {
      setModalError(res.error || 'Failed to add customer.');
      return;
    }

    setAddModalOpen(false);
    setNewBdNumber('');
    setNewName('');
    setNewPhone('');
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editTarget) return;

    updateCustomer(editTarget.bdNumber, editTarget.category, {
      name: editName.trim(),
      phone: editPhone.trim(),
    });

    setEditTarget(null);
  };

  const handleDeleteConfirm = () => {
    if (!deleteTarget) return;
    deleteCustomer(deleteTarget.bdNumber, deleteTarget.category);
    setDeleteTarget(null);
  };

  return (
    <PolarisPage
      title="Customers Directory"
      subtitle="Complete register of Bangladesh Air Force commissioned officers and airmen clients."
      primaryAction={{
        label: 'Add customer',
        icon: <Plus className="w-4 h-4" />,
        onClick: () => {
          setModalError('');
          setAddModalOpen(true);
        },
      }}
      fullWidth
    >
      {/* Control Band: Category Chips & Search */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 select-none">
        <div className="flex items-center gap-2">
          <button
            aria-pressed={activeTab === 'Officer'}
            onClick={() => setActiveTab('Officer')}
            className={`h-[40px] px-5 rounded-full text-[14px] font-semibold transition-all cursor-pointer ${
              activeTab === 'Officer'
                ? 'bg-white border-2 border-[#0071e3] text-[#1d1d1f]'
                : 'bg-white border border-[#e0e0e0] text-[#6e6e73] hover:text-[#1d1d1f]'
            }`}
          >
            Commissioned Officers ({state.customers.filter((c) => c.category === 'Officer').length})
          </button>
          <button
            aria-pressed={activeTab === 'Airman'}
            onClick={() => setActiveTab('Airman')}
            className={`h-[40px] px-5 rounded-full text-[14px] font-semibold transition-all cursor-pointer ${
              activeTab === 'Airman'
                ? 'bg-white border-2 border-[#0071e3] text-[#1d1d1f]'
                : 'bg-white border border-[#e0e0e0] text-[#6e6e73] hover:text-[#1d1d1f]'
            }`}
          >
            Airmen ({state.customers.filter((c) => c.category === 'Airman').length})
          </button>
        </div>

        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-[#6e6e73] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search customer name, BD number, phone..."
            className="w-full h-[40px] pl-10 pr-8 rounded-full bg-white border border-[#e0e0e0] text-[14px] text-[#1d1d1f] placeholder-[#7a7a7a] outline-none focus:border-[#0071e3]"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6e6e73] hover:text-[#1d1d1f]"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Customers List Panel */}
      <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#f0f0f0]">
          <h2 className="text-[20px] font-semibold text-[#1d1d1f]">
            {activeTab} Directory
          </h2>
          <span className="text-[13px] text-[#6e6e73]">
            Showing {filteredCustomers.length} clients
          </span>
        </div>

        {filteredCustomers.length === 0 ? (
          <div className="py-12 text-center text-[#6e6e73]">
            <Users className="w-8 h-8 text-[#e0e0e0] mx-auto mb-2" />
            <p className="text-[15px] font-semibold text-[#1d1d1f]">No customers found</p>
            <p className="text-[13px] mt-1">Tap Add customer to register a new client.</p>
          </div>
        ) : (
          <div className="overflow-x-auto no-scrollbar">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="h-10 bg-[#f5f5f7] rounded-[12px] text-[12px] font-semibold text-[#6e6e73] select-none">
                  <th className="px-3.5 rounded-l-[12px]">Officer / Airman</th>
                  <th className="px-3">Phone</th>
                  <th className="px-3 text-center">Orders</th>
                  {activeTab === 'Officer' && <th className="px-3 text-right">Total Spent</th>}
                  {activeTab === 'Officer' && <th className="px-3 text-right">Balance Due</th>}
                  <th className="px-3.5 text-right rounded-r-[12px]">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f0f0f0]">
                {filteredCustomers.map((cust) => {
                  const key = `${cust.category}-${cust.bdNumber.trim().toUpperCase()}`;
                  const stats = customerStats[key] || { ordersCount: 0, spent: 0, due: 0 };

                  return (
                    <tr key={`${cust.category}-${cust.bdNumber}`} className="h-[64px] hover:bg-[#fafafc]">
                      <td className="px-3.5 py-2">
                        <div className="flex items-center gap-3">
                          <div className="entity-chip text-[12px]">
                            BD
                          </div>
                          <div className="min-w-0">
                            <span className="font-semibold text-[#1d1d1f] text-[15px] block truncate">
                              {cust.name}
                            </span>
                            <span className="text-[12px] text-[#6e6e73] num">
                              BD/{cust.bdNumber}
                            </span>
                          </div>
                        </div>
                      </td>

                      <td className="px-3 py-2 text-[14px] text-[#1d1d1f] num">
                        {cust.phone || 'Not set'}
                      </td>

                      <td className="px-3 py-2 text-center text-[14px] font-semibold text-[#1d1d1f] num">
                        {stats.ordersCount}
                      </td>

                      {activeTab === 'Officer' && (
                        <td className="px-3 py-2 text-right text-[14px] font-semibold text-[#1d1d1f] num">
                          ৳{stats.spent.toLocaleString()}
                        </td>
                      )}

                      {activeTab === 'Officer' && (
                        <td className="px-3 py-2 text-right">
                          <span
                            className={`text-[14px] font-semibold num ${
                              stats.due > 0 ? 'text-[#c62828]' : 'text-[#1e7b43]'
                            }`}
                          >
                            ৳{stats.due.toLocaleString()}
                          </span>
                        </td>
                      )}

                      <td className="px-3.5 py-2 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() =>
                              onNavigate('customer-history', {
                                bdNumber: cust.bdNumber,
                                category: cust.category,
                              })
                            }
                            className="h-8 px-3 rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#0066cc] text-[12px] font-semibold inline-flex items-center gap-1 cursor-pointer"
                          >
                            <History className="w-3.5 h-3.5" />
                            <span>History</span>
                          </button>

                          <button
                            onClick={() => {
                              setEditTarget(cust);
                              setEditName(cust.name);
                              setEditPhone(cust.phone || '');
                            }}
                            className="w-8 h-8 rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#6e6e73] flex items-center justify-center cursor-pointer"
                            title="Edit customer"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => setDeleteTarget(cust)}
                            className="w-8 h-8 rounded-full bg-[#fceaea] hover:bg-[#fbdcdc] text-[#c62828] flex items-center justify-center cursor-pointer"
                            title="Delete customer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add Customer Modal */}
      <AnimatePresence>
        {addModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="fixed inset-0 bg-black/35 backdrop-blur-xs"
              onClick={() => setAddModalOpen(false)}
            />
            <div className="relative z-10 w-full max-w-md bg-white rounded-[28px] p-6 border border-[#e0e0e0] shadow-2xl">
              <h3 className="text-[20px] font-semibold text-[#1d1d1f]">
                Add {activeTab} Customer
              </h3>
              <p className="text-[13px] text-[#6e6e73] mt-0.5">
                Register officer or airman in shop directory
              </p>

              {modalError && (
                <div className="my-3 p-3 rounded-[12px] bg-[#fceaea] text-[#c62828] text-[13px]">
                  {modalError}
                </div>
              )}

              <form onSubmit={handleAddSubmit} className="space-y-4 my-4">
                <div>
                  <label className="text-[12px] font-semibold text-[#6e6e73] block mb-1">
                    BD Number *
                  </label>
                  <input
                    type="text"
                    value={newBdNumber}
                    onChange={(e) => setNewBdNumber(e.target.value)}
                    placeholder="e.g. 12408"
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] num outline-none focus:border-[#0071e3]"
                  />
                </div>
                <div>
                  <label className="text-[12px] font-semibold text-[#6e6e73] block mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="e.g. F/L Tanvir Ahmed"
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] outline-none focus:border-[#0071e3]"
                  />
                </div>
                <div>
                  <label className="text-[12px] font-semibold text-[#6e6e73] block mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={newPhone}
                    onChange={(e) => setNewPhone(e.target.value)}
                    placeholder="Mobile contact"
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] num outline-none focus:border-[#0071e3]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setAddModalOpen(false)}
                    className="h-[44px] rounded-full bg-[#f5f5f7] font-semibold text-[14px]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="h-[44px] rounded-full bg-[#0066cc] text-white font-semibold text-[14px]"
                  >
                    Save Customer
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit Customer Modal */}
      <AnimatePresence>
        {editTarget && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="fixed inset-0 bg-black/35 backdrop-blur-xs"
              onClick={() => setEditTarget(null)}
            />
            <div className="relative z-10 w-full max-w-md bg-white rounded-[28px] p-6 border border-[#e0e0e0] shadow-2xl">
              <h3 className="text-[20px] font-semibold text-[#1d1d1f]">
                Edit Customer BD/{editTarget.bdNumber}
              </h3>

              <form onSubmit={handleEditSubmit} className="space-y-4 my-4">
                <div>
                  <label className="text-[12px] font-semibold text-[#6e6e73] block mb-1">
                    Customer Name
                  </label>
                  <input
                    type="text"
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] outline-none focus:border-[#0071e3]"
                  />
                </div>
                <div>
                  <label className="text-[12px] font-semibold text-[#6e6e73] block mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] num outline-none focus:border-[#0071e3]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setEditTarget(null)}
                    className="h-[44px] rounded-full bg-[#f5f5f7] font-semibold text-[14px]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="h-[44px] rounded-full bg-[#0066cc] text-white font-semibold text-[14px]"
                  >
                    Update
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </AnimatePresence>

      {/* Delete Confirmation */}
      <AnimatePresence>
        {deleteTarget && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="fixed inset-0 bg-black/35 backdrop-blur-xs"
              onClick={() => setDeleteTarget(null)}
            />
            <div className="relative z-10 w-full max-w-sm bg-white rounded-[28px] p-6 border border-[#e0e0e0] shadow-2xl">
              <h3 className="text-[20px] font-semibold text-[#1d1d1f]">
                Delete {deleteTarget.name}?
              </h3>
              <p className="text-[14px] text-[#6e6e73] mt-2">
                This will remove the customer record for BD/{deleteTarget.bdNumber}.
              </p>
              <div className="grid grid-cols-2 gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setDeleteTarget(null)}
                  className="h-[44px] rounded-full bg-[#f5f5f7] font-semibold text-[14px]"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleDeleteConfirm}
                  className="h-[44px] rounded-full bg-[#c62828] text-white font-semibold text-[14px]"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        )}
      </AnimatePresence>
    </PolarisPage>
  );
};
